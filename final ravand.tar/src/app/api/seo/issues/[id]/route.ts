import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { applyFix } from "@/lib/seo/autofix";

export const dynamic = "force-dynamic";

const PatchSchema = z.object({
  action: z.enum(["apply", "ignore", "reopen", "resolve"]),
  reason: z.string().max(300).optional(),
});

/* PATCH /api/seo/issues/[id] — apply / ignore / reopen / resolve. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-issue-patch:${clientIp(req)}`, 30, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  const { id } = await params;
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = PatchSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");

  try {
    await ensureDb();
    const issue = await db.seoIssue.findUnique({ where: { id } });
    if (!issue) return jsonError("NOT_FOUND", 404);

    switch (parsed.data.action) {
      case "apply": {
        const result = await applyFix(id, parsed.data.reason ?? `manual apply (${issue.code})`);
        if (!result.ok) return jsonError(result.error, 400);
        return NextResponse.json({ ...result, ok: true });
      }
      case "ignore":
        await db.seoIssue.update({ where: { id }, data: { status: "ignored" } });
        return NextResponse.json({ ok: true });
      case "reopen":
        await db.seoIssue.update({ where: { id }, data: { status: "open", resolvedAt: null } });
        return NextResponse.json({ ok: true });
      case "resolve":
        await db.seoIssue.update({
          where: { id },
          data: { status: "resolved", resolvedAt: new Date() },
        });
        return NextResponse.json({ ok: true });
    }
  } catch (error) {
    console.error("[seo/issues] patch failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
