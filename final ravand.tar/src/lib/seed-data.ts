/* ------------------------------------------------------------------
   Ravand Tech — seed content (single source of truth)

   Used by BOTH:
   - prisma/seed.ts  (local: bun prisma/seed.ts)
   - src/lib/db.ts   (production: auto-seeds an empty Turso database
     on first request, so a fresh deploy is never blank)

   Trilingual text is stored as JSON strings in the database:
   {"fa":"..","ps":"..","en":".."}
   ------------------------------------------------------------------ */

export type L10n = { fa: string; ps: string; en: string };
export const J = (o: L10n) => JSON.stringify(o);

export const SEED_SETTING = {
  id: "main",
  email: "hello@rawandtech.com",
  phone1: "+93777638600",
  phone2: "+93793268319",
  whatsapp: "93777638600",
  instagram: "https://instagram.com/rawandtech",
  tagline: J({
    fa: "آژانس طراحی وب و راهکارهای فناوری اطلاعات — از ایده تا بازار، با طراحی دقیق و مهندسی تمیز.",
    ps: "د وېب ډیزاین او IT حلونو اداره — له ایدې څخه بازار ته، په ډاګه ډیزاین او پاکه انجینري سره.",
    en: "Web design & IT solutions agency — from idea to market, with precise design and clean engineering.",
  }),
  address: J({
    fa: "بلخ، مزار شریف، افغانستان",
    ps: "بلخ، مزار شریف، افغانستان",
    en: "Balkh, Mazar-i-Sharif, Afghanistan",
  }),
  hours: J({
    fa: "شنبه تا پنج‌شنبه، ۹:۰۰ تا ۱۸:۰۰",
    ps: "شنبه تر پنجشنبه، ۹:۰۰ تر ۱۸:۰۰",
    en: "Saturday – Thursday, 9:00 AM – 6:00 PM",
  }),
} as const;

export const SEED_SERVICES = [
  {
    slug: "web",
    title: { fa: "طراحی و توسعه وب", ps: "وېب ډیزاین او پراختیا", en: "Web Design & Development" },
    desc: {
      fa: "وب‌سایت‌های شرکتی، شخصی و سازمانی — مدرن، واکنش‌گرا و بهینه برای موتورهای جستجو با کد تمیز و استاندارد.",
      ps: "شرکتي، شخصي او سازماني وېبسایټونه — عصري، ځواب‌ویونکي او د لټون انجنونو لپاره سمه شوې.",
      en: "Corporate, personal and organizational websites — modern, responsive and SEO-optimized with clean, standard code.",
    },
    sticker: "/stickers/st-services.svg",
    order: 1,
  },
  {
    slug: "software",
    title: { fa: "اتوماسیون و هوش مصنوعی", ps: "د AI اتوماسیون او ساوټوېر", en: "AI Automation & Software" },
    desc: {
      fa: "خودکارسازی کارهای تکراری، ایجنت‌های هوشمند و سیستم‌های نرم‌افزاری سفارشی برای کسب‌وکار شما.",
      ps: "د تکراري کارونو اتوماسیون، هوښیار ایجنتونه او ځانګړي سوداګریز ساوټوېر سیسټمونه.",
      en: "Automate repetitive work with intelligent agents and custom software systems built for your business.",
    },
    sticker: "/stickers/st-services.svg",
    order: 2,
  },
  {
    slug: "uiux",
    title: { fa: "طراحی رابط و تجربه کاربری", ps: "UI/UX ډیزاین", en: "UI/UX Design" },
    desc: {
      fa: "رابط‌های چشم‌نواز و تجربه‌های کاربری متناسب با مخاطبان شما — از تحقیق کاربر تا نمونه‌ی قابل‌آزمایش.",
      ps: "ښکلي انټرفیسونه او د کاروونکو تجربه ستاسو اورېدونکو ته برابره — له څیړنې تر ازمویل وړ نمونې.",
      en: "Beautiful interfaces and user experiences tailored to your audience — from user research to testable prototypes.",
    },
    sticker: "/stickers/st-services.svg",
    order: 3,
  },
  {
    slug: "shop",
    title: { fa: "فروشگاه آنلاین", ps: "آنلاین پلورنځی", en: "Online Store" },
    desc: {
      fa: "فروشگاه‌های اینترنتی امن و سریع با درگاه پرداخت، مدیریت موجودی و پنل فروشندگان.",
      ps: "خوندي او چټک آنلاین پلورنځي د تادیې دروازې، ګدام مدیریت او د پلورنکو پینل سره.",
      en: "Fast, secure e-commerce stores with payment gateways, inventory management and vendor panels.",
    },
    sticker: "/stickers/st-services.svg",
    order: 4,
  },
  {
    slug: "seo",
    title: { fa: "سئو و رشد دیجیتال", ps: "سټ او ډیجیټل وده", en: "SEO & Digital Growth" },
    desc: {
      fa: "دیده‌شدن در نتایج گوگل، تبلیغات هدفمند و قیف جذب مشتری با تصمیم‌گیری داده‌محور.",
      ps: "په ګوګل کې ښکاره کېدل، موخې اعلانونه او د پیرودونکو جلب په معلوماتو پر بنسټ.",
      en: "Visibility on Google, targeted advertising and acquisition funnels driven by real data.",
    },
    sticker: "/stickers/st-services.svg",
    order: 5,
  },
  {
    slug: "support",
    title: { fa: "پشتیبانی و نگهداری", ps: "ملاتړ او ساتنه", en: "Support & Maintenance" },
    desc: {
      fa: "به‌روزرسانی، پشتیبان‌گیری، مانیتورینگ امنیتی و پشتیبانی پیوسته تا وب‌سایت شما همیشه پایدار بماند.",
      ps: "تازه کول، بیک اپ، امنیتي څارنه او دوامداره ملاتړ ترڅو وېبسایټ مو تل ثابت وي.",
      en: "Updates, backups, security monitoring and continuous support so your website stays reliable.",
    },
    sticker: "/stickers/st-services.svg",
    order: 6,
  },
] as const;

export const SEED_PROJECTS = [
  {
    slug: "hamsafar-tours",
    title: { fa: "Hamsafar Tours", ps: "Hamsafar Tours", en: "Hamsafar Tours" },
    cat: { fa: "وب‌سایت شرکتی", ps: "شرکتي وېب‌سایټ", en: "Corporate Website" },
    desc: {
      fa: "وب‌سایت گردشگری و رزرو آنلاین هتل با درگاه پرداخت.",
      ps: "د ګرځندوی وېب‌سایټ او د هوټل آنلاین ریزرف د تادیې دروازې سره.",
      en: "Tourism website and online hotel booking with a payment gateway.",
    },
    sticker: "/stickers/hamsafar.svg",
    order: 1,
  },
  {
    slug: "omo-education",
    title: { fa: "OMO Education", ps: "OMO Education", en: "OMO Education" },
    cat: { fa: "پلتفرم آموزشی", ps: "د زده کړې پلټفارم", en: "Learning Platform" },
    desc: {
      fa: "پلتفرم دوره‌های آنلاین با سیستم گواهینامه.",
      ps: "آنلاین کورسونه د سندونو سیسټم سره.",
      en: "Online course platform with a certification system.",
    },
    sticker: "/stickers/omo.svg",
    order: 2,
  },
  {
    slug: "agentic-platform",
    title: { fa: "Agentic Platform", ps: "Agentic Platform", en: "Agentic Platform" },
    cat: { fa: "اتوماسیون هوش مصنوعی", ps: "د AI اتوماسیون", en: "AI Automation" },
    desc: {
      fa: "پلتفرم ایجنت‌های هوشمند برای اتوماسیون فرآیندها.",
      ps: "د هوښیارو ایجنتونو پلټفارم د پروسو اتوماسیون لپاره.",
      en: "Platform of intelligent agents for process automation.",
    },
    sticker: "/stickers/agentic-platform.svg",
    order: 3,
  },
  {
    slug: "ai-workspace",
    title: { fa: "AI Workspace", ps: "AI Workspace", en: "AI Workspace" },
    cat: { fa: "محصول نرم‌افزاری", ps: "ساوټوېر محصول", en: "Software Product" },
    desc: {
      fa: "فضای کاری هوشمند با دستیار مبتنی بر هوش مصنوعی.",
      ps: "هوښیار کاري چاپېریال د AI مرستندوی سره.",
      en: "Smart workspace with an AI-powered assistant.",
    },
    sticker: "/stickers/ai-workspace.svg",
    order: 4,
  },
  {
    slug: "business-integration",
    title: { fa: "Business Integration", ps: "Business Integration", en: "Business Integration" },
    cat: { fa: "سیستم سازمانی", ps: "سازماني سیسټم", en: "Enterprise System" },
    desc: {
      fa: "یکپارچه‌سازی داده و سیستم مدیریت ارتباط با مشتری (CRM).",
      ps: "د معلوماتو یوځای کول او د پیرودونکو اړیکو مدیریت (CRM).",
      en: "Data integration and customer relationship management (CRM).",
    },
    sticker: "/stickers/business-integration.svg",
    order: 5,
  },
  {
    slug: "mobile-app-suite",
    title: { fa: "Mobile App Suite", ps: "Mobile App Suite", en: "Mobile App Suite" },
    cat: { fa: "توسعه موبایل", ps: "موبایل پراختیا", en: "Mobile Development" },
    desc: {
      fa: "اپلیکیشن‌های موبایل با معماری مقیاس‌پذیر.",
      ps: "موبایل اپلیکیشنونه په مقیاس‌کېدونکي معمارۍ سره.",
      en: "Mobile applications with scalable architecture.",
    },
    sticker: "/stickers/mobile-app.svg",
    order: 6,
  },
] as const;

export const SEED_POSTS = [
  {
    slug: "web-design-trends-2025",
    title: {
      fa: "روندهای طراحی وب در ۲۰۲۵؛ چه چیزی استاندارد شد؟",
      ps: "په ۲۰۲۵ کې د وېب ډیزاین رونده؛ څه معیار شول؟",
      en: "Web design trends in 2025: what became the standard?",
    },
    cat: { fa: "طراحی وب", ps: "وېب ډیزاین", en: "Web Design" },
    excerpt: {
      fa: "از تایپوگرافی بزرگ تا انیمیشن‌های ظریف — نگاهی به روندهایی که امسال به استاندارد تبدیل شدند.",
      ps: "له لویې تایپوګرافۍ څخه تر ظریفو انیمیشنونو — هغه رونده ته کتنه چې سږ کال معیار شو.",
      en: "From oversized typography to subtle motion — a look at the trends that became standard this year.",
    },
    body: {
      fa: "طراحی وب در سال ۲۰۲۵ به بلوغ رسید؛ تایپوگرافی بزرگ و جسورانه دیگر یک انتخاب نیست، بلکه استاندارد است. کاربران امروز انتظار دارند پیام اصلی سایت در همان ثانیه‌ی اول دیده شود.\n\nانیمیشن‌های ظریف و هدفمند جای افکت‌های سنگین را گرفته‌اند. حرکت باید معنا داشته باشد: هدایت توجه، نمایش تغییر حالت و بازخورد فوری به کاربر.\n\nسرعت بارگذاری مهم‌ترین عامل تجربه است. تصاویر بهینه، فونت‌های سبک و کد تمیز مستقیماً روی رتبه‌ی گوگل و نرخ تبدیل اثر می‌گذارند.\n\nدر راوند تک، همه‌ی این استانداردها از روز اول در هر پروژه اجرا می‌شوند — نتیجه‌اش سایتی است که سریع بار می‌شود، زیبا دیده می‌شود و مشتری می‌آورد.",
      ps: "د وېب ډیزاین په ۲۰۲۵ کې پخېدلی شو؛ لویه او باخبره تایپوګرافي نور انتخاب نه، بلکې معیار دی. کاروونکي نن تمه لري چې د سایټ اصلي پیغام په لومړۍ ثانیه کې وویني.\n\nظریفو او موخه‌لرونکو انیمیشنونو د درنو افکتونو ځای نیولی دی. خوځښت باید مانا ولري: پام راګرځول، د حالت بدلون ښکاره کول او سمدستي ځواب.\n\nد بارېدو چټکتیا د تجربې تر ټولو مهم عامل دی. سمه شوې انځورنه، سپک فونټونه او پاک کوډ په مستقیم ډول پر ګوګل درجه او پر بدلون اغېز لري.\n\nپه راوند ټک کې ټول دا معیارونه له لومړي ورځ څخه په هره پروژه پلي کیږي — پایله یې هغه سایټ دی چې چټک بارېږي، ښکلی ښکاري او پیرودونکي راولي.",
      en: "Web design matured in 2025; bold, oversized typography is no longer an option — it is the standard. Users today expect the core message to land within the very first second.\n\nSubtle, purposeful motion has replaced heavy effects. Movement must carry meaning: guiding attention, expressing state changes and giving instant feedback.\n\nLoad speed is the single most important experience factor. Optimized images, light fonts and clean code directly affect Google rankings and conversion rates.\n\nAt Ravand Tech, every one of these standards is applied from day one in every project — the result is a site that loads fast, looks beautiful and brings customers.",
    },
    sticker: "/stickers/blog-web.svg",
    readMin: 6,
    dateLabel: { fa: "۱۰ نوامبر ۲۰۲۵", ps: "۱۰ نومبر ۲۰۲۵", en: "Nov 10, 2025" },
  },
  {
    slug: "ai-automation-small-business",
    title: {
      fa: "اتوماسیون هوش مصنوعی برای کسب‌وکارهای کوچک؛ از کجا شروع کنیم؟",
      ps: "د AI اتوماسیون د کوچنیو سوداګریو لپاره؛ له چېره پیل وکړو؟",
      en: "AI automation for small businesses: where to start?",
    },
    cat: { fa: "هوش مصنوعی", ps: "مصنوعي ځیرکتیا", en: "AI & Automation" },
    excerpt: {
      fa: "پنج کار تکراری که امروز می‌توانید به ایجنت‌های هوشمند بسپارید و هزینه‌ها را کاهش دهید.",
      ps: "پنځه تکراري دندې چې نن یې هوښیار ایجنتونو ته سپارل کولی شئ او لګښت کم کړئ.",
      en: "Five repetitive tasks you can hand to intelligent agents today to cut costs.",
    },
    body: {
      fa: "هوش مصنوعی دیگر مخصوص شرکت‌های بزرگ نیست. کسب‌وکارهای کوچک هم می‌توانند با اتوماسیون ساده، ساعات کاری زیادی را آزاد کنند.\n\nاز پاسخ‌گویی خودکار به مشتریان شروع کنید؛ یک چت‌بات که سوال‌های پرتکرار را جواب می‌دهد، فشار تیم شما را به‌شدت کم می‌کند.\n\nسپس سراغ گزارش‌گیری بروید: خواندن داده‌ها، خلاصه‌سازی و آماده‌سازی گزارش‌های هفتگی کارهای ایده‌آلی برای ایجنت‌های هوشمند هستند.\n\nمدیریت موجودی، دسته‌بندی سفارش‌ها و پیگیری فاکتورها نیز از مواردی است که اتوماسیون به‌سرعت بازدهی می‌دهد. ما در راوند تک این سیستم‌ها را متناسب با کسب‌وکار شما طراحی و پیاده‌سازی می‌کنیم.",
      ps: "مصنوعي ځیرکتیا نور یوازې د لویو شرکتونو ځانګړتیا نه ده. کوچنۍ سوداګرۍ هم په ساده اتوماسیون کولی شي ډېر کاري ساعتونه آزاد کړي.\n\nله اتومات ځواب‌ویونکي پیل وکړئ؛ یو چټ‌بټ چې تکراري پوښتنې ځوابوي، ستاسو ټیم فشار کلک کموي.\n\nبیا راپور اخیستلو ته ورشئ: د معلوماتو لوستل، لنډول او اونیز راپور برابرول د هوښیارو ایجنتونو مثالي دندې دي.\n\nد ګدام مدیریت، د فرمونو ډلبندي او بیل تعقیب هم هغه څه دي چې اتوماسیون ژر ګټه ورکوي. موږ په راوند ټک کې دا سیسټمونه ستاسو سوداګرې سره سمه ډیزاین او پلي کوو.",
      en: "AI is no longer reserved for big companies. Small businesses can free up significant working hours with simple automation.\n\nStart with automated customer replies; a chatbot that answers frequently asked questions takes enormous pressure off your team.\n\nThen move to reporting: reading data, summarizing and preparing weekly reports are ideal jobs for intelligent agents.\n\nInventory management, order sorting and invoice tracking also pay off quickly with automation. At Ravand Tech we design and implement these systems tailored to your business.",
    },
    sticker: "/stickers/blog-ai.svg",
    readMin: 8,
    dateLabel: { fa: "۲۸ اکتوبر ۲۰۲۵", ps: "۲۸ اکتوبر ۲۰۲۵", en: "Oct 28, 2025" },
  },
  {
    slug: "seo-afghan-market",
    title: {
      fa: "سئو برای بازار افغانستان؛ راهنمای عملی دیده‌شدن در گوگل",
      ps: "د افغان بازار لپاره سټ؛ د ګوګل ښکاره کېدو عملي لارښود",
      en: "SEO for the Afghan market: a practical guide to Google visibility",
    },
    cat: { fa: "سئو و رشد", ps: "سټ او وده", en: "SEO & Growth" },
    excerpt: {
      fa: "از تحقیق کلمات کلیدی دری و پشتو تا سرعت سایت — چک‌لیستی که واقعاً کار می‌کند.",
      ps: "له پښتو او دري کیورډونو څېړنې تر د سایټ چټکتیا — چیک‌لیست چې ریښتیا کار کوي.",
      en: "From Dari & Pashto keyword research to site speed — a checklist that actually works.",
    },
    body: {
      fa: "سئو در بازار افغانستان یک فرصت بزرگ است؛ رقابت هنوز سنگین نیست و سایت‌های استاندارد به‌سرعت بالا می‌آیند.\n\nبا تحقیق کلمات کلیدی به زبان دری و پشتو شروع کنید. کاربران به زبان خودشان جستجو می‌کنند و سایتی که به آن زبان‌ها پاسخ دهد، برنده است.\n\nسرعت سایت را جدی بگیرید: بسیاری از کاربران با اینترنت موبایل و شبکه‌های متغیر وارد می‌شوند، پس صفحه‌ها باید زیر دو ثانیه بار شوند.\n\nمحتوای مفید و محلی بسازید، اطلاعات تماس و موقعیت را دقیق ثبت کنید و از پروفایل گوگل بیزینس استفاده کنید. همین چک‌لیست ساده، تفاوت بین دیده‌شدن و گم‌شدن است.",
      ps: "سټ په افغان بازار کې یو لوی فرصت دی؛ سیالي لا تر اوسه درنه نه ده او معیاري وېبسایټونه ژر پورته کیږي.\n\nپه دري او پښتو ژبو د کیورډونو له څېړنې پیل وکړئ. کاروونکي په خپله ژبه لټون کوي او هغه سایټ چې دې ژبو ځواب ورکړ، ګټونکی دی.\n\nد سایټ چټکتیا جدي ونیسئ: ډېری کاروونکي په موبایل انټرنټ او بدلېدونکو شبکو راتله، نو پاڼې باید له دوو ثانیو کم بارېشي.\n\nګټور او سیمه‌ایز منځپانګه جوړه کړئ، د اړیکې او موقعیت معلومات سم ثبت کړئ او له ګوګل بیزنس پروفایل څخه کار واخلئ. همدا ساده چیک‌لیست د ښکاره کېدو او ورکېدو تر منځ توپیر دی.",
      en: "SEO in the Afghan market is a big opportunity; competition is not heavy yet and standard sites rise fast.\n\nStart with keyword research in Dari and Pashto. Users search in their own language — the site that answers in those languages wins.\n\nTake site speed seriously: most users arrive on mobile internet with unstable networks, so pages must load under two seconds.\n\nBuild useful, local content, register accurate contact and location details, and use your Google Business profile. This simple checklist is the difference between being found and being lost.",
    },
    sticker: "/stickers/blog-seo.svg",
    readMin: 7,
    dateLabel: { fa: "۱۵ اکتوبر ۲۰۲۵", ps: "۱۵ اکتوبر ۲۰۲۵", en: "Oct 15, 2025" },
  },
] as const;

export const SEED_TESTIMONIALS = [
  {
    name: "احمد رحیمی",
    role: {
      fa: "مدیر شرکت بازرگانی، مزار شریف",
      ps: "د سوداګرۍ شرکت مدیر، مزار شریف",
      en: "Trading Company Manager, Mazar-i-Sharif",
    },
    quote: {
      fa: "تیم راوند تک وب‌سایت ما را دقیقاً همان‌طور ساخت که تصور می‌کردیم — حتی بهتر. سرعت و ظاهر سایت از انتظارمان بالاتر بود.",
      ps: "راوند ټک ټیم زموږ وېبسایټ همداسې جوړ کړ لکه څنګه یې تصور کوو — حتی ښه. د سایټ سرعت او بڼه له تمه ډېره وه.",
      en: "The Ravand Tech team built our website exactly as we imagined — even better. The speed and look exceeded our expectations.",
    },
    order: 1,
  },
  {
    name: "سمیرا نوری",
    role: {
      fa: "بنیان‌گذار فروشگاه آنلاین، کابل",
      ps: "د آنلاین پلورنځي بنسټګره، کابل",
      en: "Online Store Founder, Kabul",
    },
    quote: {
      fa: "سیستم مدیریت فروشگاهی که برایمان ساختند، کار انبارداری ما را نصف کرد. گزارش‌گیری حالا چند دقیقه طول می‌کشد، نه چند ساعت.",
      ps: "د پلورنځي مدیریت سیسټم چې موږ لپاره یې جوړ کړ، د ګدام کار مو نیم کړ. راپور اخیستل اوس څو دقیقې نیسي، نه څو ساعته.",
      en: "The store management system they built cut our warehouse work in half. Reporting now takes minutes, not hours.",
    },
    order: 2,
  },
  {
    name: "David Miller",
    role: {
      fa: "مدیر محصول، مشتری بین‌المللی",
      ps: "د محصول مدیر، لرې پیرودونکی",
      en: "Product Manager, Remote Client",
    },
    quote: {
      fa: "حرفه‌ای، خوش‌قول و پاسخ‌گو. در هر مرحله‌ی پروژه در جریان پیشرفت بودیم و همه‌چیز سر وقت تحویل شد.",
      ps: "مسلکي، د خپل وړاندې کوونکي او ځواب‌ویونکی. په هر پړاو کې مو د پرمختګ خبرې کولې او هر څه په وخت سپارل شول.",
      en: "Professional, on-time and responsive. We were informed at every stage and everything was delivered on schedule.",
    },
    order: 3,
  },
] as const;

export const SEED_STATS = [
  {
    value: 40,
    suffix: "+",
    label: { fa: "پروژه‌ی موفق", ps: "بریالي پروژې", en: "Successful Projects" },
    sub: { fa: "در حوزه‌ی وب و نرم‌افزار", ps: "په وېب او ساوټوېر کې", en: "Across web & software" },
    order: 1,
  },
  {
    value: 25,
    suffix: "+",
    label: { fa: "مشتری خوشحال", ps: "خوښ پیرودونکي", en: "Happy Clients" },
    sub: { fa: "در افغانستان و خارج از آن", ps: "په افغانستان او بهر", en: "In Afghanistan & beyond" },
    order: 2,
  },
  {
    value: 24,
    suffix: "h",
    label: { fa: "حداکثر زمان پاسخ", ps: "تر ټولو وروستی ځواب", en: "Max Response Time" },
    sub: { fa: "در روزهای کاری", ps: "په کاري ورځو کې", en: "On business days" },
    order: 3,
  },
  {
    value: 3,
    suffix: "",
    label: { fa: "زبان کاری", ps: "کاري ژبې", en: "Working Languages" },
    sub: { fa: "دری، پشتو، انگلیسی", ps: "پښتو، فارسی، انګلیسي", en: "Dari, Pashto, English" },
    order: 4,
  },
] as const;
