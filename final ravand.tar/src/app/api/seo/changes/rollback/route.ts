import { NextResponse } from "next/server";
import { z } from "zod";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { rollbackChange } from "@/lib/seo/autofix";

export const dynamic = "force-dynamic";

const RollbackSchema = z.object({ changeId: z.string().min(5).max(60) });

/* POST /api/seo/changes/rollback — restore the old value of an applied
   change (metadata override or resource field). Admin only. */
export async function POST(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-rollback:${clientIp(req)}`, 20, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = RollbackSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");

  try {
    const result = await rollbackChange(parsed.data.changeId);
    if (!result.ok) return jsonError(result.error, 400);
    return NextResponse.json({ ...result, ok: true });
  } catch (error) {
    console.error("[seo/changes/rollback] failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
