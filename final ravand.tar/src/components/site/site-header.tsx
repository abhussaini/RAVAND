"use client";

import { useT } from "@/lib/i18n";
import { navigate } from "@/lib/router";
import { useUi } from "@/store/use-ui";
import { BrandLockup } from "./ui-v2";

/**
 * Transparent header sitting inside the hero (over the photo).
 * Desktop links jump straight to the dedicated pages.
 */
export function SiteHeader() {
  const { t } = useT();
  const setMenuOpen = useUi((s) => s.setMenuOpen);
  const openContact = useUi((s) => s.openContact);

  const links = [
    { label: t("nav.services"), to: "/services" },
    { label: t("nav.portfolio"), to: "/portfolio" },
  ];

  return (
    <header className="relative z-30 flex items-center px-6 pt-5 text-white sm:px-10 sm:pt-7">
      {/* left nav */}
      <nav aria-label="Primary" className="hidden flex-1 items-center gap-8 lg:flex">
        {links.map((l) => (
          <button
            key={l.to}
            type="button"
            onClick={() => navigate(l.to)}
            className="cursor-pointer text-sm font-medium text-white/90 transition-colors duration-300 hover:text-white"
          >
            {l.label}
          </button>
        ))}
      </nav>

      {/* brand — big lockup, 3 quick taps open the admin panel */}
      <div className="flex flex-1 items-center gap-2.5 lg:justify-center">
        <BrandLockup
          markClassName="size-11 sm:size-12"
          wordClassName="text-xl sm:text-[1.6rem]"
          onSingle={() => navigate("/")}
        />
      </div>

      {/* right cluster */}
      <div className="flex flex-1 items-center justify-end gap-4">
        <button
          type="button"
          onClick={() => openContact()}
          className="display-caps hidden cursor-pointer text-sm font-medium uppercase tracking-wide text-white underline-offset-4 transition-colors hover:underline sm:block"
        >
          {t("nav.cta")}
        </button>

        <button
          type="button"
          onClick={() => setMenuOpen(true)}
          aria-label={t("nav.menu")}
          aria-haspopup="dialog"
          className="grid size-10 cursor-pointer place-items-center rounded-pill bg-white/15 backdrop-blur transition-colors duration-300 hover:bg-white/25"
        >
          <span aria-hidden className="flex w-4 flex-col gap-[5px]">
            <span className="h-px w-full bg-white" />
            <span className="h-px w-full bg-white" />
          </span>
        </button>
      </div>
    </header>
  );
}
