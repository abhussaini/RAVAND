import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { createReport } from "@/lib/seo/reports";

export const dynamic = "force-dynamic";

const CreateSchema = z.object({ period: z.enum(["weekly", "monthly"]) });

/* GET /api/seo/reports — report history (admin only). */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    await ensureDb();
    const reports = await db.seoReport.findMany({ orderBy: { createdAt: "desc" }, take: 30 });
    return NextResponse.json({ ok: true, reports });
  } catch (error) {
    console.error("[seo/reports] list failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}

/* POST /api/seo/reports — generate a weekly/monthly report now. */
export async function POST(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-report-create:${clientIp(req)}`, 6, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");

  try {
    const id = await createReport(parsed.data.period);
    return NextResponse.json({ ok: true, id }, { status: 201 });
  } catch (error) {
    console.error("[seo/reports] create failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
