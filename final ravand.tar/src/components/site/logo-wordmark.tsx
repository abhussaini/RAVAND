"use client";

import Image from "next/image";
import { cn } from "@/lib/utils";

/** Ravand Tech logo mark (transparent SVG, blue/purple/cyan) */
export function LogoMark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex size-9 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-border dark:bg-transparent dark:ring-white/15",
        className
      )}
      aria-hidden
    >
      <Image
        src="/images/logo-mark.svg"
        alt=""
        width={36}
        height={36}
        className="size-full"
        priority
      />
    </span>
  );
}

/**
 * Brand wordmark — Peyda ExtraBold, leading glyph enlarged & gradient-filled
 * (brand directive from DESIGN_SYSTEM.md).
 */
export function LogoWordmark({
  className,
  size = "md",
}: {
  className?: string;
  size?: "md" | "lg";
}) {
  return (
    <span
      dir="ltr"
      className={cn(
        "font-peyda inline-flex items-baseline tracking-tight",
        size === "lg" ? "text-2xl sm:text-3xl" : "text-lg sm:text-xl",
        className
      )}
    >
      <span className="text-gradient-brand text-[1.3em] leading-none" aria-hidden>
        R
      </span>
      <span>avand&nbsp;Tech</span>
    </span>
  );
}
