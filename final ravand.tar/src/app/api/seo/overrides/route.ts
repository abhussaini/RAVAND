import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

const PostSchema = z.object({
  field: z.enum(["title", "description", "ogTitle", "ogDescription"]),
  value: z.string().trim().min(3).max(320),
  reason: z.string().max(300).optional(),
});

/* POST /api/seo/overrides — apply a metadata override directly (used by
   the Content Optimizer "save as title/description" action). Logged in
   SeoChange with the old value so it can be rolled back. Admin only —
   this is a MEDIUM-risk action the UI confirms first. */
export async function POST(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-override:${clientIp(req)}`, 15, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = PostSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");
  const { field, value, reason } = parsed.data;

  try {
    await ensureDb();
    const existing = await db.seoOverride.findUnique({
      where: { path_field: { path: "/", field } },
    });
    const oldValue = existing?.value ?? "";

    await db.seoOverride.upsert({
      where: { path_field: { path: "/", field } },
      update: { value, active: true },
      create: { path: "/", field, value },
    });
    const change = await db.seoChange.create({
      data: {
        targetType: "override",
        targetRef: `/#${field}`,
        oldValue,
        newValue: value,
        reason: reason || "content optimizer apply",
      },
    });
    return NextResponse.json({ ok: true, changeId: change.id, oldValue }, { status: 201 });
  } catch (error) {
    console.error("[seo/overrides] failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}

/* GET /api/seo/overrides — active overrides (admin only). */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    await ensureDb();
    const overrides = await db.seoOverride.findMany({ where: { active: true } });
    return NextResponse.json({ ok: true, overrides });
  } catch (error) {
    console.error("[seo/overrides] list failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
