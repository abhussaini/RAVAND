"use client";

import { useRef, useState, type FormEvent } from "react";
import { useT } from "@/lib/i18n";
import {
  SERVICE_VALUES,
  validateContact,
  parseContactFailure,
  type ContactField,
  type ContactFieldErrors,
} from "./contact-validate";

type Status = "idle" | "sending" | "ok" | "error";

const FIELD_CLS =
  "w-full rounded-xl border border-hairline bg-background px-4 py-3 text-sm text-ink placeholder:text-ink-soft/60 focus:border-brand-light focus:outline-none focus:ring-2 focus:ring-brand-light/40";
const FIELD_ERROR_CLS = "border-destructive focus:border-destructive focus:ring-destructive/30";
const LABEL_CLS =
  "display-caps block text-xs font-medium uppercase tracking-[0.18em] text-ink-soft";
const ERROR_CLS = "mt-1.5 text-xs font-medium text-destructive";

/**
 * Reusable consultation form — posts to /api/contact and shows the
 * success state inline. Used on the contact page (and reusable
 * anywhere else) with an optional preset service.
 */
export function ContactForm({ preset = "" }: { preset?: string }) {
  const { t, isRtl } = useT();
  const [status, setStatus] = useState<Status>("idle");
  const [topMessage, setTopMessage] = useState("");
  const [fieldErrors, setFieldErrors] = useState<ContactFieldErrors>({});
  const [service, setService] = useState<string>(
    SERVICE_VALUES.includes(preset as (typeof SERVICE_VALUES)[number]) ? preset : ""
  );
  const formRef = useRef<HTMLFormElement>(null);

  const clearField = (field: ContactField) =>
    setFieldErrors((prev) => {
      if (!(field in prev)) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const values = {
      name: String(fd.get("name") || ""),
      email: String(fd.get("email") || ""),
      phone: String(fd.get("phone") || ""),
      service,
      message: String(fd.get("message") || ""),
    };

    /* pre-validate in the browser — same rules as the server */
    const errors = validateContact(values, t);
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setTopMessage(t("contact.err_fix"));
      setStatus("error");
      return;
    }

    setStatus("sending");
    setTopMessage("");
    setFieldErrors({});
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const body = (await res.json().catch(() => null)) as {
        error?: string;
        issues?: Record<string, string[]>;
      } | null;
      if (!res.ok) {
        const parsed = parseContactFailure(res.status, body, t);
        setFieldErrors(parsed.fieldErrors);
        setTopMessage(parsed.topMessage);
        setStatus("error");
        return;
      }
      setStatus("ok");
      form.reset();
    } catch {
      setTopMessage(t("contact.err_d"));
      setStatus("error");
    }
  }

  if (status === "ok") {
    return (
      <div
        className="anim-pop rounded-card bg-surface p-8 text-center"
        role="status"
      >
        <span className="mx-auto grid size-12 place-items-center rounded-pill bg-brand text-white">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden className="size-6">
            <path d="M5 13l4 4L19 7" />
          </svg>
        </span>
        <p className="mt-4 text-lg font-medium">{t("contact.ok_t")}</p>
        <p className="mt-1 text-sm text-ink-soft">{t("contact.ok_d")}</p>
        <button
          type="button"
          onClick={() => setStatus("idle")}
          className="display-caps mt-6 cursor-pointer rounded-pill bg-ink px-7 py-3 text-sm font-medium uppercase tracking-wide text-white transition-colors hover:bg-brand-deep"
        >
          {isRtl ? "پیام جدید" : "New message"}
        </button>
      </div>
    );
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="flex flex-col gap-4">
      <div>
        <label className={LABEL_CLS} htmlFor="cf-name">
          {t("contact.name")}
        </label>
        <input
          id="cf-name"
          name="name"
          type="text"
          required
          placeholder={t("contact.name_ph")}
          aria-invalid={Boolean(fieldErrors.name)}
          className={`mt-2 ${FIELD_CLS} ${fieldErrors.name ? FIELD_ERROR_CLS : ""}`}
          onChange={() => clearField("name")}
        />
        {fieldErrors.name && (
          <p role="alert" className={ERROR_CLS}>{fieldErrors.name}</p>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className={LABEL_CLS} htmlFor="cf-email">
            {t("contact.email")}
          </label>
          <input
            id="cf-email"
            name="email"
            type="email"
            required
            dir="ltr"
            placeholder={t("contact.email_ph")}
            aria-invalid={Boolean(fieldErrors.email)}
            className={`mt-2 ${FIELD_CLS} ${fieldErrors.email ? FIELD_ERROR_CLS : ""}`}
            onChange={() => clearField("email")}
          />
          {fieldErrors.email && (
            <p role="alert" className={ERROR_CLS}>{fieldErrors.email}</p>
          )}
        </div>
        <div>
          <label className={LABEL_CLS} htmlFor="cf-phone">
            {t("contact.phone")}
          </label>
          <input
            id="cf-phone"
            name="phone"
            type="tel"
            dir="ltr"
            placeholder={t("contact.phone_ph")}
            aria-invalid={Boolean(fieldErrors.phone)}
            className={`mt-2 ${FIELD_CLS} ${fieldErrors.phone ? FIELD_ERROR_CLS : ""}`}
            onChange={() => clearField("phone")}
          />
          {fieldErrors.phone && (
            <p role="alert" className={ERROR_CLS}>{fieldErrors.phone}</p>
          )}
        </div>
      </div>

      <div>
        <label className={LABEL_CLS} htmlFor="cf-service">
          {t("contact.service")}
        </label>
        <select
          id="cf-service"
          name="service"
          value={service}
          onChange={(e) => setService(e.target.value)}
          className={`mt-2 cursor-pointer appearance-none ${FIELD_CLS}`}
        >
          <option value="">{t("contact.service_ph")}</option>
          {SERVICE_VALUES.map((v) => (
            <option key={v} value={v}>
              {t(`contact.svc_${v === "software" ? "soft" : v === "uiux" ? "ui" : v}`)}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className={LABEL_CLS} htmlFor="cf-message">
          {t("contact.message")}
        </label>
        <textarea
          id="cf-message"
          name="message"
          rows={5}
          required
          placeholder={t("contact.message_ph")}
          aria-invalid={Boolean(fieldErrors.message)}
          className={`mt-2 resize-none ${FIELD_CLS} ${fieldErrors.message ? FIELD_ERROR_CLS : ""}`}
          onChange={() => clearField("message")}
        />
        {fieldErrors.message && (
          <p role="alert" className={ERROR_CLS}>{fieldErrors.message}</p>
        )}
      </div>

      {status === "error" && topMessage && (
        <p role="alert" className="text-sm font-medium text-destructive">
          {topMessage}
        </p>
      )}

      <button
        type="submit"
        disabled={status === "sending"}
        className="display-caps mt-1 cursor-pointer self-start rounded-pill bg-ink px-8 py-3.5 text-sm font-medium uppercase tracking-wide text-white transition-colors hover:bg-brand-deep disabled:cursor-not-allowed disabled:opacity-60"
      >
        {status === "sending" ? t("contact.sending") : t("contact.send")}
      </button>
    </form>
  );
}
