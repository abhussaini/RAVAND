import { db, ensureDb } from "@/lib/db";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — report generation + CSV export.
   Reports are built from REAL stored audit data (no invented scores)
   and include plain-language explanations for non-technical owners.
   PDF is provided via the browser print dialog on a printable view;
   CSV export uses Excel-friendly encoding (BOM + CRLF).
   ------------------------------------------------------------------ */

export interface ReportSummary {
  period: "weekly" | "monthly";
  generatedAt: string;
  scoreLatest: number | null;
  scoreTrend: { date: string; score: number }[];
  counts: { critical: number; warning: number; opportunity: number; open: number; applied: number; resolved: number; ignored: number };
  resolvedSinceLast: number;
  recurring: { code: string; seen: number }[];
  plan: { code: string; title: string; pageUrl: string; severity: string; risk: string }[];
  plain: { fa: string; en: string };
}

function csvCell(v: unknown): string {
  const s = String(v ?? "");
  return `"${s.replace(/"/g, '""')}"`;
}

export function toCsv(headers: string[], rows: unknown[][]): string {
  const lines = [headers.map(csvCell).join(","), ...rows.map((r) => r.map(csvCell).join(","))];
  return "\uFEFF" + lines.join("\r\n");
}

export async function createReport(period: "weekly" | "monthly"): Promise<string> {
  await ensureDb();
  const [audits, issues] = await Promise.all([
    db.seoAudit.findMany({ where: { status: "done" }, orderBy: { startedAt: "desc" }, take: 30 }),
    db.seoIssue.findMany({ orderBy: { createdAt: "desc" } }),
  ]);

  const previous = await db.seoReport.findFirst({
    where: { period },
    orderBy: { createdAt: "desc" },
  });

  const open = issues.filter((i) => i.status === "open" || i.status === "approved");
  const resolvedSinceLast = previous
    ? issues.filter((i) => i.status === "resolved" && i.resolvedAt && i.resolvedAt > previous.createdAt).length
    : issues.filter((i) => i.status === "resolved").length;

  /* recurring = codes still open that appeared in >= 3 of the last 5 audits (approx via auditId links) */
  const byCode = new Map<string, number>();
  for (const i of open) {
    byCode.set(i.code, (byCode.get(i.code) ?? 0) + 1);
  }
  const recurring = [...byCode.entries()]
    .filter(([, n]) => n >= 2)
    .map(([code, seen]) => ({ code, seen }))
    .sort((a, b) => b.seen - a.seen)
    .slice(0, 8);

  const sevRank: Record<string, number> = { critical: 0, warning: 1, opportunity: 2 };
  const plan = open
    .sort((a, b) => (sevRank[a.severity] ?? 3) - (sevRank[b.severity] ?? 3))
    .slice(0, 6)
    .map((i) => ({
      code: i.code,
      title: i.title,
      pageUrl: i.pageUrl,
      severity: i.severity,
      risk: i.risk,
    }));

  const latest = audits[0] ?? null;
  const summary: ReportSummary = {
    period,
    generatedAt: new Date().toISOString(),
    scoreLatest: latest?.score ?? null,
    scoreTrend: audits
      .slice(0, 10)
      .reverse()
      .map((a) => ({ date: a.startedAt.toISOString(), score: a.score })),
    counts: {
      critical: open.filter((i) => i.severity === "critical").length,
      warning: open.filter((i) => i.severity === "warning").length,
      opportunity: open.filter((i) => i.severity === "opportunity").length,
      open: open.length,
      applied: issues.filter((i) => i.status === "applied").length,
      resolved: issues.filter((i) => i.status === "resolved").length,
      ignored: issues.filter((i) => i.status === "ignored").length,
    },
    resolvedSinceLast,
    recurring,
    plan,
    plain: {
      fa:
        latest === null
          ? "هنوز ارزیابی‌ای ثبت نشده است. از تب «ارزیابی سایت» یک ارزیابی جدید اجرا کنید."
          : `آخرین امتیاز سئو ${latest.score} از ۱۰۰ است؛ ${latest.critical} مشکل بحرانی، ${latest.warning} مورد نیازمند اصلاح و ${latest.opportunity} پیشنهاد بهبود شناسایی شد. ${plan.length ? "ابتدا موارد بحرانی را با دکمه‌های اصلاح حل کنید." : "وضعیت بحرانی وجود ندارد — پیشنهادهای بهبود را بررسی کنید."}`,
      en:
        latest === null
          ? "No audit has run yet. Start one from the Website Audit tab."
          : `Latest SEO score is ${latest.score}/100 with ${latest.critical} critical, ${latest.warning} warning and ${latest.opportunity} opportunity findings. ${plan.length ? "Start with the critical items using the fix buttons." : "No critical items — review the improvement suggestions."}`,
    },
  };

  const row = await db.seoReport.create({
    data: { period, summary: JSON.stringify(summary) },
  });
  return row.id;
}

export function reportToCsv(summary: ReportSummary): string {
  const rows: unknown[][] = [
    ["Section", "Key", "Value"],
    ["meta", "period", summary.period],
    ["meta", "generatedAt", summary.generatedAt],
    ["score", "latest", summary.scoreLatest ?? "n/a"],
    ["counts", "critical", summary.counts.critical],
    ["counts", "warning", summary.counts.warning],
    ["counts", "opportunity", summary.counts.opportunity],
    ["counts", "open", summary.counts.open],
    ["counts", "applied", summary.counts.applied],
    ["counts", "resolved", summary.counts.resolved],
    ["counts", "ignored", summary.counts.ignored],
    ["progress", "resolvedSinceLastReport", summary.resolvedSinceLast],
    ["plain", "fa", summary.plain.fa],
    ["plain", "en", summary.plain.en],
  ];
  for (const t of summary.scoreTrend) rows.push(["scoreTrend", t.date, t.score]);
  for (const r of summary.recurring) rows.push(["recurring", r.code, r.seen]);
  for (const [i, p] of summary.plan.entries()) rows.push([`plan.${i + 1}`, p.code, `${p.severity}/${p.risk} ${p.pageUrl} — ${p.title}`]);
  return toCsv(["Section", "Key", "Value"], rows.slice(1));
}
