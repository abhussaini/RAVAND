"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { createPortal } from "react-dom";
import { useT } from "@/lib/i18n";
import { useUi } from "@/store/use-ui";
import { StackedLines, useMounted } from "./reveal";
import { Eyebrow } from "./ui-v2";
import {
  SERVICE_VALUES,
  validateContact,
  parseContactFailure,
  type ContactField,
  type ContactFieldErrors,
} from "./contact-validate";

type Status = "idle" | "sending" | "ok" | "error";

const FIELD_CLS =
  "w-full rounded-xl border border-hairline bg-background px-4 py-3 text-sm text-ink placeholder:text-ink-soft/60 focus:border-brand-light focus:outline-none focus:ring-2 focus:ring-brand-light/40";
const FIELD_ERROR_CLS = "border-destructive focus:border-destructive focus:ring-destructive/30";
const LABEL_CLS =
  "display-caps block text-xs font-medium uppercase tracking-[0.18em] text-ink-soft";
const ERROR_CLS = "mt-1.5 text-xs font-medium text-destructive";

/** Portaled contact modal — sticky header/footer, softly scrolling body. */
export function ContactModal() {
  const { t, isRtl } = useT();
  const open = useUi((s) => s.contactOpen);
  const closeContact = useUi((s) => s.closeContact);
  const preset = useUi((s) => s.contactPreset);

  const [status, setStatus] = useState<Status>("idle");
  const [topMessage, setTopMessage] = useState("");
  const [fieldErrors, setFieldErrors] = useState<ContactFieldErrors>({});
  const [service, setService] = useState<string>("");
  const nameRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  const clearField = (field: ContactField) =>
    setFieldErrors((prev) => {
      if (!(field in prev)) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });

  /* reset state + apply preset when the modal opens — adjusted during
     render (previous-state pattern) rather than in an effect so the
     reset never cascades an extra render pass */
  const [lastOpen, setLastOpen] = useState(false);
  if (open !== lastOpen) {
    setLastOpen(open);
    if (open) {
      setStatus("idle");
      setTopMessage("");
      setFieldErrors({});
      setService(SERVICE_VALUES.includes(preset as (typeof SERVICE_VALUES)[number]) ? preset : "");
    }
  }
  const focusTimerRef = useRef<number | undefined>(undefined);
  useEffect(() => {
    if (!open) return;
    focusTimerRef.current = window.setTimeout(() => nameRef.current?.focus(), 120);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeContact();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(focusTimerRef.current);
      window.removeEventListener("keydown", onKey);
    };
  }, [open, closeContact]);

  /* reset the form a beat after closing */
  useEffect(() => {
    if (open) return;
    const timer = window.setTimeout(() => formRef.current?.reset(), 350);
    return () => window.clearTimeout(timer);
  }, [open]);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const values = {
      name: String(fd.get("name") || ""),
      email: String(fd.get("email") || ""),
      phone: String(fd.get("phone") || ""),
      service,
      message: String(fd.get("message") || ""),
    };

    /* pre-validate in the browser — same rules as the server */
    const errors = validateContact(values, t);
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setTopMessage(t("contact.err_fix"));
      setStatus("error");
      return;
    }

    setStatus("sending");
    setTopMessage("");
    setFieldErrors({});
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const body = (await res.json().catch(() => null)) as {
        error?: string;
        issues?: Record<string, string[]>;
      } | null;
      if (!res.ok) {
        const parsed = parseContactFailure(res.status, body, t);
        setFieldErrors(parsed.fieldErrors);
        setTopMessage(parsed.topMessage);
        setStatus("error");
        return;
      }
      setStatus("ok");
      form.reset();
    } catch {
      setTopMessage(t("contact.err_d"));
      setStatus("error");
    }
  }

  /* portals must wait for mount — server and the hydration render
     both return null so the trees match exactly */
  const mounted = useMounted();
  if (typeof document === "undefined" || !mounted) return null;

  /* always mounted — CSS visibility/transform toggle gives real
     enter/exit transitions with zero unmount cost */
  return createPortal(
    <div
      className={`fixed inset-0 z-[90] flex items-end justify-center p-3 transition-[visibility] duration-300 sm:items-center sm:p-6 ${open ? "visible" : "invisible"}`}
      aria-hidden={!open}
    >
      <div
        className={`absolute inset-0 bg-brand-deep/40 backdrop-blur-sm transition-[opacity,visibility] duration-300 ${
          open ? "visible opacity-100" : "invisible opacity-0"
        }`}
        onClick={closeContact}
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-label={t("contact.title")}
        aria-hidden={!open}
        className={`relative flex max-h-[92svh] w-full flex-col overflow-hidden rounded-card-lg bg-white text-ink shadow-[0_40px_90px_-20px_rgba(15,47,99,0.45)] transition-[opacity,transform,visibility] duration-300 sm:max-w-[34rem] ${
          open ? "visible translate-y-0 scale-100 opacity-100" : "invisible translate-y-7 scale-[0.96] opacity-0"
        }`}
      >
            {/* ── sticky header ── */}
            <div className="flex shrink-0 items-start justify-between gap-4 border-b border-hairline px-6 py-5 sm:px-8">
              <div>
                <Eyebrow>{t("contact.eyebrow")}</Eyebrow>
                <h2 className="font-display mt-2.5 text-3xl font-medium leading-[1.02] tracking-tight sm:text-4xl">
                  <StackedLines
                    lines={[t("v2.modal.l1"), t("v2.modal.l2")]}
                    stagger={90}
                    duration={0.8}
                    gated
                    open={open}
                  />
                </h2>
              </div>
              <button
                type="button"
                onClick={closeContact}
                aria-label="Close"
                className="group grid size-10 shrink-0 cursor-pointer place-items-center rounded-pill bg-surface transition-colors hover:bg-hairline"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1.8}
                  strokeLinecap="round"
                  aria-hidden
                  className="size-4 transition-transform duration-300 group-hover:rotate-90"
                >
                  <path d="M6 6l12 12M18 6L6 18" />
                </svg>
              </button>
            </div>

            {/* ── scrolling body ── */}
            <div
              className="nice-scroll min-h-0 flex-1 overscroll-contain px-6 py-6 sm:px-8"
              data-lenis-prevent
            >
              {status === "ok" ? (
                <div className="rounded-card bg-surface p-6 text-center" role="status">
                  <span className="mx-auto grid size-12 place-items-center rounded-pill bg-brand text-white">
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={2}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden
                      className="size-6"
                    >
                      <path d="M5 13l4 4L19 7" />
                    </svg>
                  </span>
                  <p className="mt-4 text-lg font-medium">{t("contact.ok_t")}</p>
                  <p className="mt-1 text-sm text-ink-soft">{t("contact.ok_d")}</p>
                  <button
                    type="button"
                    onClick={closeContact}
                    className="display-caps mt-6 cursor-pointer rounded-pill bg-ink px-7 py-3 text-sm font-medium uppercase tracking-wide text-white transition-colors hover:bg-brand-deep"
                  >
                    {isRtl ? "تمام" : "Done"}
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  id="cm-form"
                  onSubmit={onSubmit}
                  noValidate
                  className="flex flex-col gap-4.5"
                >
                  <div>
                    <label className={LABEL_CLS} htmlFor="cm-name">
                      {t("contact.name")}
                    </label>
                    <input
                      ref={nameRef}
                      id="cm-name"
                      name="name"
                      type="text"
                      required
                      placeholder={t("contact.name_ph")}
                      aria-invalid={Boolean(fieldErrors.name)}
                      className={`mt-2 ${FIELD_CLS} ${fieldErrors.name ? FIELD_ERROR_CLS : ""}`}
                      onChange={() => clearField("name")}
                    />
                    {fieldErrors.name && (
                      <p role="alert" className={ERROR_CLS}>{fieldErrors.name}</p>
                    )}
                  </div>

                  <div className="grid gap-4.5 sm:grid-cols-2">
                    <div>
                      <label className={LABEL_CLS} htmlFor="cm-email">
                        {t("contact.email")}
                      </label>
                      <input
                        id="cm-email"
                        name="email"
                        type="email"
                        required
                        dir="ltr"
                        placeholder={t("contact.email_ph")}
                        aria-invalid={Boolean(fieldErrors.email)}
                        className={`mt-2 ${FIELD_CLS} ${fieldErrors.email ? FIELD_ERROR_CLS : ""}`}
                        onChange={() => clearField("email")}
                      />
                      {fieldErrors.email && (
                        <p role="alert" className={ERROR_CLS}>{fieldErrors.email}</p>
                      )}
                    </div>
                    <div>
                      <label className={LABEL_CLS} htmlFor="cm-phone">
                        {t("contact.phone")}
                      </label>
                      <input
                        id="cm-phone"
                        name="phone"
                        type="tel"
                        dir="ltr"
                        placeholder={t("contact.phone_ph")}
                        aria-invalid={Boolean(fieldErrors.phone)}
                        className={`mt-2 ${FIELD_CLS} ${fieldErrors.phone ? FIELD_ERROR_CLS : ""}`}
                        onChange={() => clearField("phone")}
                      />
                      {fieldErrors.phone && (
                        <p role="alert" className={ERROR_CLS}>{fieldErrors.phone}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className={LABEL_CLS} htmlFor="cm-service">
                      {t("contact.service")}
                    </label>
                    <select
                      id="cm-service"
                      name="service"
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className={`mt-2 cursor-pointer appearance-none ${FIELD_CLS}`}
                    >
                      <option value="">{t("contact.service_ph")}</option>
                      {SERVICE_VALUES.map((v) => (
                        <option key={v} value={v}>
                          {t(`contact.svc_${v === "software" ? "soft" : v === "uiux" ? "ui" : v}`)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className={LABEL_CLS} htmlFor="cm-message">
                      {t("contact.message")}
                    </label>
                    <textarea
                      id="cm-message"
                      name="message"
                      rows={4}
                      required
                      placeholder={t("contact.message_ph")}
                      aria-invalid={Boolean(fieldErrors.message)}
                      className={`mt-2 resize-none ${FIELD_CLS} ${fieldErrors.message ? FIELD_ERROR_CLS : ""}`}
                      onChange={() => clearField("message")}
                    />
                    {fieldErrors.message && (
                      <p role="alert" className={ERROR_CLS}>{fieldErrors.message}</p>
                    )}
                  </div>
                </form>
              )}
            </div>

            {/* ── sticky footer with the submit action ── */}
            {status !== "ok" && (
              <div className="shrink-0 border-t border-hairline bg-white px-6 py-4 sm:px-8">
                {status === "error" && topMessage && (
                  <p role="alert" className="mb-3 text-sm font-medium text-destructive">
                    {topMessage}
                  </p>
                )}
                <button
                  type="submit"
                  form="cm-form"
                  disabled={status === "sending"}
                  className="display-caps flex w-full cursor-pointer items-center justify-center rounded-pill bg-ink px-7 py-3.5 text-sm font-medium uppercase tracking-wide text-white transition-colors hover:bg-brand-deep disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {status === "sending" ? t("contact.sending") : t("contact.send")}
                </button>
              </div>
            )}
          </div>
    </div>,
    document.body
  );
}
