import type { Metadata, Viewport } from "next";
import { Vazirmatn, Poppins } from "next/font/google";
import localFont from "next/font/local";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { db, ensureDb } from "@/lib/db";

/* Body font — Vazirmatn (arabic + latin), used for fa/ps and everywhere */
const vazirmatn = Vazirmatn({
  variable: "--font-vazirmatn",
  subsets: ["arabic", "latin"],
  display: "swap",
});

/* Latin display accents */
const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  display: "swap",
  weight: ["600", "700", "800"],
});

/* Brand wordmark — Peyda ExtraBold, bundled locally (never depends on a CDN) */
const peyda = localFont({
  src: "../fonts/PeydaWebFaNum-ExtraBold.woff2",
  weight: "800",
  variable: "--font-peyda",
  display: "swap",
});

/* Force SSR so approved SEO metadata overrides (Ravand AI SEO
   Assistant → auto-fix) are merged into <head> on every request.
   DB failures fall back to the static defaults below. */
export const dynamic = "force-dynamic";

const STATIC_METADATA: Metadata = {
  metadataBase: new URL("https://rawandtech.com"),
  title: {
    default: "Ravand Tech — Web Design & IT Solutions Agency",
    template: "%s | Ravand Tech",
  },
  description:
    "Ravand Tech (راوند تک) builds modern websites and IT solutions for growing businesses — web design & development, custom software, e-commerce, SEO and reliable support. From idea to market.",
  keywords: [
    "Ravand Tech",
    "راوند تک",
    "web design Afghanistan",
    "طراحی وب سایت",
    "آی تی سلوشن",
    "IT solutions",
    "web development Mazar-i-Sharif",
    "فروشگاه آنلاین",
    "سئو",
  ],
  authors: [{ name: "Ravand Tech" }],
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "16x16 32x32 48x48", type: "image/x-icon" },
      { url: "/favicon.svg", type: "image/svg+xml" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    title: "Ravand Tech — Web Design & IT Solutions",
    description:
      "Modern websites, custom software and IT solutions — engineered for your growth. Dari, Pashto & English.",
    siteName: "Ravand Tech",
    type: "website",
    locale: "en_US",
    alternateLocale: ["fa_AF", "ps_AF"],
    url: "https://rawandtech.com",
  },
  twitter: {
    card: "summary",
    title: "Ravand Tech — Web Design & IT Solutions",
    description: "Modern websites & IT solutions, engineered for your growth.",
  },
};

/** generateMetadata — merges admin-approved SEO overrides for the
    homepage (title / description / OG) from the SeoOverride table. */
export async function generateMetadata(): Promise<Metadata> {
  try {
    await ensureDb();
    const overrides = await db.seoOverride.findMany({ where: { path: "/", active: true } });
    const map = new Map(overrides.map((o) => [o.field, o.value] as const));
    const title = map.get("title");
    const description = map.get("description");
    const ogTitle = map.get("ogTitle");
    const ogDescription = map.get("ogDescription");
    if (!title && !description && !ogTitle && !ogDescription) return STATIC_METADATA;
    return {
      ...STATIC_METADATA,
      ...(title ? { title } : {}),
      ...(description ? { description } : {}),
      openGraph: {
        ...STATIC_METADATA.openGraph,
        ...(ogTitle ? { title: ogTitle } : title ? { title } : {}),
        ...(ogDescription ? { description: ogDescription } : description ? { description } : {}),
      },
      twitter: {
        ...STATIC_METADATA.twitter,
        ...(ogTitle ? { title: ogTitle } : title ? { title } : {}),
        ...(ogDescription ? { description: ogDescription } : description ? { description } : {}),
      },
    };
  } catch {
    return STATIC_METADATA;
  }
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  interactiveWidget: "resizes-content",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0b0f1e" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <body
        className={`${vazirmatn.variable} ${poppins.variable} ${peyda.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />

        {/* Structured data — Organization + WebSite (technical SEO) */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Organization",
                  "@id": "https://rawandtech.com/#org",
                  name: "Ravand Tech",
                  alternateName: "راوند تک",
                  url: "https://rawandtech.com",
                  logo: "https://rawandtech.com/images/logo-r.webp",
                  description:
                    "Web design & IT solutions agency — modern websites, custom software, e-commerce, SEO and reliable support.",
                  email: "hello@rawandtech.com",
                  telephone: "+93777638600",
                  address: {
                    "@type": "PostalAddress",
                    addressLocality: "Mazar-i-Sharif",
                    addressRegion: "Balkh",
                    addressCountry: "AF",
                  },
                  sameAs: ["https://wa.me/93777638600"],
                },
                {
                  "@type": "WebSite",
                  "@id": "https://rawandtech.com/#site",
                  url: "https://rawandtech.com",
                  name: "Ravand Tech",
                  publisher: { "@id": "https://rawandtech.com/#org" },
                  inLanguage: ["en", "fa", "ps"],
                },
              ],
            }),
          }}
        />
      </body>
    </html>
  );
}
