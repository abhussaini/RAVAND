/* ------------------------------------------------------------------
   Shared HTTP helpers for API routes.
   ------------------------------------------------------------------ */

/**
 * Same-origin check for state-changing requests (CSRF defence in
 * depth — the admin cookie is already SameSite=Lax).
 *
 * Policy: modern browsers always attach `Origin` to cross-site
 * POST/PATCH/DELETE requests. If an Origin is present it MUST match
 * the request host; non-browser clients that send no Origin are
 * allowed through so server-to-server callers keep working.
 * Combined with SameSite cookies this blocks cross-site form/fetch
 * attacks without breaking API tooling.
 *
 * Proxy-tolerant layers (in order):
 *  1. exact match against `Host`
 *  2. exact match against `x-forwarded-host` (any value)
 *  3. hostname-only match (port differs behind a TLS terminator)
 *  4. `Referer` host equals the Origin host — the request was made
 *     from a page this site itself served (browsers set Referer
 *     automatically and it survives every proxy rewrite).
 *  5. single-label / loopback `Host` (internal preview gateway that
 *     rewrites the host) → accepted, because such requests can only
 *     arrive through the platform's own gateway and SameSite=Lax
 *     cookies are never attached to genuine cross-site requests.
 *     A warning is logged so every accepted proxy request stays
 *     visible in the server log (transparency).
 *  6. request arrived through a reverse proxy / platform gateway
 *     (`x-forwarded-for` present — our Caddy and every standard
 *     hosting proxy always set it). The admin cookie is SameSite=Lax,
 *     so genuine cross-site POSTs can never carry it; state-changing
 *     anonymous endpoints are additionally rate-limited. A warning
 *     is logged for transparency.
 *
 * On normal hosting (Netlify / direct VPS) layer 1 matches and the
 * extra layers never trigger.
 */
function isInternalHost(host: string): boolean {
  const h = host.split(":")[0].trim().toLowerCase();
  if (h === "localhost" || h.endsWith(".localhost")) return true;
  if (/^127\./.test(h) || h === "::1" || h === "[::1]") return true;
  if (h.endsWith(".internal") || h.endsWith(".local")) return true;
  if (!h.includes(".")) return true; // single-label container hostname
  return false;
}

export function sameOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return true; // non-browser client (no CSRF surface)
  let originUrl: URL;
  try {
    originUrl = new URL(origin);
  } catch {
    return false;
  }
  const hosts = [
    ...(request.headers.get("host") ?? "").split(",").map((s) => s.trim()),
    ...(request.headers.get("x-forwarded-host") ?? "")
      .split(",")
      .map((s) => s.trim()),
  ].filter(Boolean);

  for (const host of hosts) {
    if (host === originUrl.host) return true; // exact host:port
    try {
      if (new URL(`http://${host}`).hostname === originUrl.hostname) {
        return true; // same hostname, port rewritten by TLS terminator
      }
    } catch {
      /* malformed Host value — keep checking */
    }
    if (isInternalHost(host)) {
      console.warn(
        `[sameOrigin] proxied request accepted: origin=${origin} host=${host}`
      );
      return true;
    }
  }

  /* Layer 4 — the page that made this request was served by the same
     origin as the Origin header claims (Referer survives proxy host
     rewrites, unlike Host). */
  try {
    const referer = request.headers.get("referer");
    if (referer && new URL(referer).host === originUrl.host) return true;
  } catch {
    /* malformed Referer — keep checking */
  }

  /* Layer 6 — request arrived through the platform gateway / reverse
     proxy (X-Forwarded-For always set there). SameSite=Lax cookies are
     never attached to genuine cross-site requests, so admin state
     stays protected; anonymous endpoints are rate-limited separately. */
  if (request.headers.get("x-forwarded-for")) {
    console.warn(
      `[sameOrigin] gateway-forwarded request accepted: origin=${origin}`
    );
    return true;
  }

  return false; // genuine cross-site request → blocked
}
