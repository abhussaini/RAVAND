import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { parseL10n } from "@/app/api/content/route";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { optimizeContent } from "@/lib/seo/ai";
import { KNOWN_ROUTES } from "@/lib/seo/config";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const OptimizeSchema = z.object({
  pageUrl: z.string().trim().min(1).max(200),
  keyword: z.string().trim().min(2).max(60),
  lang: z.enum(["fa", "en"]).default("en"),
});

/* POST /api/seo/optimize — content optimizer.
   Pulls REAL page content (latest audit snapshot for "/" or the live
   post body) and returns suggestions. Approval + apply happens through
   the issue auto-fix workflow — nothing is published automatically. */
export async function POST(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-optimize:${clientIp(req)}`, 8, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = OptimizeSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");
  const { pageUrl, keyword, lang } = parsed.data;

  try {
    await ensureDb();

    let title = "";
    let description = "";
    let text = "";
    const posts = await db.post.findMany({ where: { published: true } });
    const internalPages = [
      ...KNOWN_ROUTES.map((r) => ({
        path: r,
        label: r === "/" ? "Home" : `#${r} section`,
      })),
      ...posts.map((p) => ({ path: `/blog/${p.slug}`, label: `Post: ${parseL10n(p.title).en || p.slug}` })),
    ];

    if (pageUrl === "/") {
      const latest = await db.seoPageResult.findFirst({ orderBy: { id: "desc" } });
      title = latest?.title ?? "";
      description = latest?.description ?? "";
      text = latest?.contentText ?? "";
      if (!text) return jsonError("NO_DATA", 400, { detail: "Run a website audit first" });
    } else {
      const slug = /^#?\/?blog\/([a-z0-9-]+)$/i.exec(pageUrl)?.[1];
      if (!slug) return jsonError("VALIDATION", 400, { detail: "pageUrl must be / or #/blog/<slug>" });
      const post = posts.find((p) => p.slug === slug);
      if (!post) return jsonError("NOT_FOUND", 404);
      const t = parseL10n(post.title);
      const b = parseL10n(post.body);
      const e = parseL10n(post.excerpt);
      title = t.en || t.fa;
      description = e.en || e.fa;
      text = (b.en || b.fa || b.ps).slice(0, 4000);
    }

    /* real keyword usage stats from the actual content */
    const lower = `${title} ${description} ${text}`.toLowerCase();
    const kw = keyword.toLowerCase();
    const occurrences = lower.split(kw).length - 1;
    const words = lower.split(/\s+/).filter(Boolean).length;

    const result = await optimizeContent({
      url: pageUrl,
      keyword,
      lang,
      title,
      description,
      text,
      internalPages,
    });

    return NextResponse.json({
      ok: true,
      result,
      page: { title, description, wordCount: words },
      keywordUsage: {
        occurrences,
        densityPct: words ? +((occurrences / words) * 100).toFixed(2) : 0,
        inTitle: title.toLowerCase().includes(kw),
        inDescription: description.toLowerCase().includes(kw),
      },
    });
  } catch (error) {
    console.error("[seo/optimize] failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
