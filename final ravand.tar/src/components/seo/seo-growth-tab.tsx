"use client";

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { KeyRound, Lightbulb, Plus, Sparkles, Trash2, Type, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fmtDate, seoApi, type KeywordRow, type OptimizerResponse } from "./seo-api";
import {
  ApplyDialog,
  Badge,
  EmptyState,
  Loading,
  SeoCard,
  type SeoTabProps,
} from "./seo-ui";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — Keywords + Content Optimizer tab
   (dashboard sections D + E). All applies require explicit approval.
   ------------------------------------------------------------------ */

const PAGE_OPTIONS = ["/", "/#/services", "/#/portfolio", "/#/blog", "/#/about", "/#/contact"];

export function GrowthTab({
  lang,
  t,
  initialTab,
}: Omit<SeoTabProps, "dir"> & { initialTab: "keywords" | "optimizer" }) {
  const qc = useQueryClient();
  const [subTab, setSubTab] = useState<"keywords" | "optimizer">(initialTab);

  /* ---------- keywords state ---------- */
  const [kwText, setKwText] = useState("");
  const [kwPage, setKwPage] = useState("/");
  const [kwLang, setKwLang] = useState("en");
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const keywords = useQuery({
    queryKey: ["seo-keywords"],
    queryFn: () => seoApi<{ ok: true; keywords: KeywordRow[] }>("/api/seo/keywords"),
    refetchOnMount: "always",
  });

  const addKeyword = useMutation({
    mutationFn: () =>
      seoApi<{ ok: true }>("/api/seo/keywords", {
        method: "POST",
        body: JSON.stringify({ keyword: kwText, pageUrl: kwPage, lang: kwLang }),
      }),
    onSuccess: () => {
      toast.success(t("s.kw_add_btn"));
      setKwText("");
      qc.invalidateQueries({ queryKey: ["seo-keywords"] });
    },
    onError: (e: Error) => {
      if (e.message === "DUPLICATE") toast.error(lang === "fa" ? "این کلمه قبلاً ثبت شده است." : "Keyword already exists.");
      else toast.error(t("s.error"));
    },
  });

  const deleteKeyword = useMutation({
    mutationFn: (id: string) => seoApi<{ ok: true }>(`/api/seo/keywords/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["seo-keywords"] }),
    onError: () => toast.error(t("s.error")),
  });

  const suggest = useMutation({
    mutationFn: () =>
      seoApi<{ ok: true; suggestions: string[] }>("/api/seo/keywords/suggest", {
        method: "POST",
        body: JSON.stringify({ seed: kwText || "web design Afghanistan", lang }),
      }),
    onSuccess: (d) => {
      setSuggestions(d.suggestions);
      if (!d.suggestions.length) toast.info(t("s.kw_suggestions_off"));
    },
    onError: () => toast.error(t("s.error")),
  });

  /* ---------- optimizer state ---------- */
  const [optPage, setOptPage] = useState("/");
  const [optKeyword, setOptKeyword] = useState("");
  const [optResult, setOptResult] = useState<OptimizerResponse | null>(null);
  const [applyField, setApplyField] = useState<{ field: "title" | "description"; value: string } | null>(null);

  const posts = useQuery({
    queryKey: ["seo-posts"],
    queryFn: () =>
      seoApi<{ ok: true; items: { id: string; slug: string; title: string }[] }>("/api/admin/posts"),
  });

  const analyze = useMutation({
    mutationFn: () =>
      seoApi<OptimizerResponse>("/api/seo/optimize", {
        method: "POST",
        body: JSON.stringify({ pageUrl: optPage, keyword: optKeyword, lang }),
      }),
    onSuccess: (d) => setOptResult(d),
    onError: (e: Error) => {
      if (e.message === "NO_DATA") toast.error(t("s.opt_first_audit"));
      else toast.error(t("s.error"));
    },
  });

  const applyOverride = useMutation({
    mutationFn: (f: { field: string; value: string }) =>
      seoApi<{ ok: true }>("/api/seo/overrides", {
        method: "POST",
        body: JSON.stringify({ ...f, reason: "content optimizer" }),
      }),
    onSuccess: () => {
      toast.success(t("s.set_saved"));
      setApplyField(null);
      qc.invalidateQueries({ queryKey: ["seo-changes"] });
    },
    onError: () => toast.error(t("s.error")),
  });

  return (
    <div className="grid grid-cols-1 gap-4 lg:gap-6">
      <div className="flex gap-1.5">
        {(
          [
            { key: "keywords", label: t("s.tab_keywords"), icon: KeyRound },
            { key: "optimizer", label: t("s.tab_optimizer"), icon: Type },
          ] as const
        ).map((x) => (
          <button
            key={x.key}
            type="button"
            onClick={() => setSubTab(x.key)}
            className={`inline-flex cursor-pointer items-center gap-1.5 rounded-pill px-3.5 py-2 text-sm font-medium transition-colors ${
              subTab === x.key ? "bg-brand-deep text-white" : "bg-white text-ink-soft hover:bg-surface"
            }`}
          >
            <x.icon className="size-4" aria-hidden />
            {x.label}
          </button>
        ))}
      </div>

      {subTab === "keywords" ? (
        <>
          <SeoCard title={t("s.kw_add")} icon={Plus}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (kwText.trim().length >= 2) addKeyword.mutate();
              }}
              className="grid gap-3 sm:grid-cols-[2fr_1.2fr_0.8fr_auto]"
            >
              <div className="grid gap-1">
                <Label htmlFor="kw-input">{t("s.tab_keywords")}</Label>
                <Input
                  id="kw-input"
                  value={kwText}
                  onChange={(e) => setKwText(e.target.value)}
                  placeholder={t("s.kw_placeholder")}
                  minLength={2}
                  maxLength={60}
                  required
                />
              </div>
              <div className="grid gap-1">
                <Label htmlFor="kw-page">{t("s.kw_page")}</Label>
                <select
                  id="kw-page"
                  value={kwPage}
                  onChange={(e) => setKwPage(e.target.value)}
                  className="h-9 rounded-pill border border-hairline bg-white px-3 text-sm"
                >
                  {PAGE_OPTIONS.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid gap-1">
                <Label htmlFor="kw-lang">{t("s.kw_lang")}</Label>
                <select
                  id="kw-lang"
                  value={kwLang}
                  onChange={(e) => setKwLang(e.target.value)}
                  className="h-9 rounded-pill border border-hairline bg-white px-3 text-sm"
                >
                  <option value="en">EN</option>
                  <option value="fa">دری</option>
                  <option value="ps">پشتو</option>
                </select>
              </div>
              <div className="flex items-end gap-1.5">
                <Button
                  type="submit"
                  disabled={addKeyword.isPending}
                  className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
                >
                  <Plus className="size-4" aria-hidden />
                  {t("s.kw_add_btn")}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => suggest.mutate()}
                  disabled={suggest.isPending}
                  className="cursor-pointer rounded-pill"
                >
                  <Lightbulb className="size-4" aria-hidden />
                  {suggest.isPending ? t("s.kw_suggesting") : t("s.kw_suggest")}
                </Button>
              </div>
            </form>
            {suggestions.length > 0 ? (
              <div className="mt-3 flex flex-wrap items-center gap-1.5">
                <span className="text-xs font-medium text-ink-soft">{t("s.kw_suggestions")}:</span>
                {suggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setKwText(s);
                      addKeyword.mutate();
                    }}
                    className="cursor-pointer rounded-pill border border-hairline bg-surface px-2.5 py-1 text-xs transition-colors hover:bg-brand hover:text-white"
                  >
                    <Sparkles className="me-1 inline size-3" aria-hidden />
                    {s}
                  </button>
                ))}
              </div>
            ) : null}
          </SeoCard>

          {keywords.isLoading ? (
            <Loading label={t("s.loading")} />
          ) : !keywords.data?.keywords?.length ? (
            <EmptyState icon={KeyRound} text={t("s.kw_empty")} />
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {keywords.data.keywords.map((k) => (
                <article key={k.id} className="rounded-card border border-hairline bg-white p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h4 className="truncate font-medium text-ink" dir="auto">
                        {k.keyword}
                      </h4>
                      <p className="mt-0.5 text-xs text-ink-soft" dir="ltr">
                        {k.pageUrl} · {k.lang}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteKeyword.mutate(k.id)}
                      className="cursor-pointer rounded-pill text-red-600 hover:bg-red-50 hover:text-red-700"
                      aria-label={t("s.kw_delete")}
                    >
                      <Trash2 className="size-4" aria-hidden />
                    </Button>
                  </div>
                  {k.usage ? (
                    <dl className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
                      <div className="rounded-card bg-surface p-2">
                        <dt className="text-ink-soft">{t("s.kw_homepage")}</dt>
                        <dd className="font-display text-base font-bold text-ink">{k.usage.homepage}</dd>
                      </div>
                      <div className="rounded-card bg-surface p-2">
                        <dt className="text-ink-soft">{t("s.kw_posts")}</dt>
                        <dd className="font-display text-base font-bold text-ink">{k.usage.posts.length}</dd>
                      </div>
                      <div className="rounded-card bg-surface p-2">
                        <dt className="text-ink-soft">{t("s.kw_density")}</dt>
                        <dd className="font-display text-base font-bold text-ink">{k.usage.density}%</dd>
                      </div>
                    </dl>
                  ) : null}
                  {k.cannibalization && k.cannibalization.length > 0 ? (
                    <p className="mt-2 rounded-card bg-amber-50 p-2 text-xs text-amber-800">{t("s.kw_cannibalization")}</p>
                  ) : null}
                </article>
              ))}
            </div>
          )}
        </>
      ) : (
        <>
          <SeoCard title={t("s.opt_analyze")} icon={Wand2}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (optKeyword.trim().length >= 2) analyze.mutate();
              }}
              className="grid gap-3 sm:grid-cols-[1.4fr_1.4fr_auto]"
            >
              <div className="grid gap-1">
                <Label htmlFor="opt-page">{t("s.opt_page")}</Label>
                <select
                  id="opt-page"
                  value={optPage}
                  onChange={(e) => setOptPage(e.target.value)}
                  className="h-9 rounded-pill border border-hairline bg-white px-3 text-sm"
                >
                  <option value="/">/ ({t("s.kw_homepage")})</option>
                  {(posts.data?.items ?? []).map((p) => (
                    <option key={p.id} value={`#/blog/${p.slug}`}>
                      #/blog/{p.slug}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid gap-1">
                <Label htmlFor="opt-kw">{t("s.opt_keyword")}</Label>
                <Input
                  id="opt-kw"
                  value={optKeyword}
                  onChange={(e) => setOptKeyword(e.target.value)}
                  placeholder={t("s.kw_placeholder")}
                  minLength={2}
                  maxLength={60}
                  required
                />
              </div>
              <div className="flex items-end">
                <Button
                  type="submit"
                  disabled={analyze.isPending}
                  className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
                >
                  {analyze.isPending ? <span className="flex items-center gap-1.5"><span className="size-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />{t("s.opt_analyzing")}</span> : t("s.opt_analyze")}
                </Button>
              </div>
            </form>
            <p className="mt-2 text-xs text-ink-soft">{t("s.opt_need_approval")}</p>
          </SeoCard>

          {analyze.isPending ? <Loading label={t("s.opt_analyzing")} /> : null}

          {optResult ? (
            <>
              <div className="grid gap-4 sm:grid-cols-4">
                <div className="rounded-card border border-hairline bg-white p-4 text-center">
                  <p className="text-xs text-ink-soft">{t("s.opt_usage")}</p>
                  <p className="mt-1 font-display text-2xl font-bold text-brand-deep">{optResult.keywordUsage.occurrences}</p>
                  <p className="text-xs text-ink-soft">{optResult.keywordUsage.densityPct}%</p>
                </div>
                <div className="rounded-card border border-hairline bg-white p-4 text-center">
                  <p className="text-xs text-ink-soft">{t("s.opt_in_title")}</p>
                  <p className="mt-1 font-display text-2xl font-bold">{optResult.keywordUsage.inTitle ? "✓" : "✗"}</p>
                </div>
                <div className="rounded-card border border-hairline bg-white p-4 text-center">
                  <p className="text-xs text-ink-soft">{t("s.opt_in_desc")}</p>
                  <p className="mt-1 font-display text-2xl font-bold">{optResult.keywordUsage.inDescription ? "✓" : "✗"}</p>
                </div>
                <div className="rounded-card border border-hairline bg-white p-4 text-center">
                  <p className="text-xs text-ink-soft">{t("s.score")}</p>
                  <p className="mt-1 font-display text-sm font-bold text-ink-soft">{t("s.rules_source")}</p>
                </div>
              </div>

              <SeoCard title={t("s.opt_titles")} icon={Type}>
                <ul className="grid gap-2">
                  {optResult.result.titles.map((title) => (
                    <li key={title} className="flex flex-wrap items-center justify-between gap-2 rounded-card border border-hairline p-3 text-sm">
                      <span dir="auto">{title}</span>
                      <span className="flex items-center gap-1.5">
                        <Badge kind={title.length > 25 && title.length <= 65 ? "ok" : "warning"}>
                          {title.length} {t("s.char")}
                        </Badge>
                        {optPage === "/" ? (
                          <Button variant="outline" size="sm" onClick={() => setApplyField({ field: "title", value: title })} className="cursor-pointer rounded-pill">
                            {t("s.opt_apply_title")}
                          </Button>
                        ) : null}
                      </span>
                    </li>
                  ))}
                </ul>
              </SeoCard>

              <SeoCard title={t("s.opt_descs")} icon={Type}>
                <ul className="grid gap-2">
                  {optResult.result.descriptions.map((d) => (
                    <li key={d} className="flex flex-wrap items-center justify-between gap-2 rounded-card border border-hairline p-3 text-sm">
                      <span dir="auto" className="min-w-0 flex-1">
                        {d}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Badge kind={d.length >= 50 && d.length <= 160 ? "ok" : "warning"}>
                          {d.length} {t("s.char")}
                        </Badge>
                        {optPage === "/" ? (
                          <Button variant="outline" size="sm" onClick={() => setApplyField({ field: "description", value: d })} className="cursor-pointer rounded-pill">
                            {t("s.opt_apply_desc")}
                          </Button>
                        ) : null}
                      </span>
                    </li>
                  ))}
                </ul>
              </SeoCard>

              <div className="grid gap-4 md:grid-cols-2">
                <SeoCard title={t("s.opt_headings")} icon={Lightbulb}>
                  <ul className="grid list-inside list-disc gap-1.5 text-sm text-ink">
                    {optResult.result.headings.map((h) => (
                      <li key={h} dir="auto">
                        {h}
                      </li>
                    ))}
                  </ul>
                </SeoCard>
                <SeoCard title={t("s.opt_sections")} icon={Lightbulb}>
                  <ul className="grid list-inside list-disc gap-1.5 text-sm text-ink">
                    {optResult.result.sections.map((h) => (
                      <li key={h} dir="auto">
                        {h}
                      </li>
                    ))}
                  </ul>
                </SeoCard>
                <SeoCard title={t("s.opt_links")} icon={Lightbulb}>
                  <ul className="grid gap-1.5 text-sm">
                    {optResult.result.internalLinks.map((h) => (
                      <li key={h} dir="auto" className="text-brand">
                        {h}
                      </li>
                    ))}
                  </ul>
                </SeoCard>
                <SeoCard title={t("s.opt_notes")} icon={Sparkles}>
                  <p className="text-sm text-ink" dir="auto">
                    {optResult.result.notes}
                  </p>
                  <p className="mt-2 text-xs text-ink-soft">
                    {t("s.opt_page")}: {optResult.page.wordCount} w · {fmtDate(new Date().toISOString(), lang)}
                  </p>
                </SeoCard>
              </div>
            </>
          ) : null}
        </>
      )}

      <ApplyDialog
        open={Boolean(applyField)}
        onClose={() => setApplyField(null)}
        onConfirm={() => {
          if (applyField) applyOverride.mutate(applyField);
        }}
        title={t("s.apply_confirm_t")}
        desc={t("s.apply_confirm_d")}
        oldValue={optResult?.page.title ?? ""}
        newValue={applyField?.value ?? ""}
        labels={{ old: t("s.old_value"), new: t("s.new_value"), confirm: t("s.confirm"), cancel: t("s.cancel") }}
      />
    </div>
  );
}
