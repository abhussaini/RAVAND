import { randomUUID } from "crypto";
import { db, ensureDb } from "@/lib/db";
import { sbTable, supabaseEnabled } from "@/lib/supabase";

/* ------------------------------------------------------------------
   Ravand Tech — content store with Supabase mirroring.

   The local database (SQLite / Turso via Prisma) stays the
   authoritative, always-available store so the site and the admin
   panel never depend on network availability.

   Every content change AND every new lead is mirrored into the
   project's Supabase instance (best-effort, fail-safe). On startup
   the whole dataset is synced once into empty Supabase tables, so
   the remote copy is always complete and browsable.

   Tables mirrored:  Service, Project, Post, Testimonial, Stat,
                     Setting, ContactMessage, Subscriber
   ------------------------------------------------------------------ */

export const SB_SYNC_TABLES = [
  "Service",
  "Project",
  "Post",
  "Testimonial",
  "Stat",
  "Setting",
  "ContactMessage",
  "Subscriber",
] as const;

export type SyncTable = (typeof SB_SYNC_TABLES)[number];

/** Admin resource key → Supabase table name (null = not mirrored). */
export function resourceTable(resource: string): SyncTable | null {
  switch (resource) {
    case "services":
      return "Service";
    case "projects":
      return "Project";
    case "posts":
      return "Post";
    case "testimonials":
      return "Testimonial";
    case "stats":
      return "Stat";
    case "settings":
      return "Setting";
    case "messages":
      return "ContactMessage";
    case "subscribers":
      return "Subscriber";
    default:
      return null;
  }
}

/* ---------- best-effort mirroring (fire & forget) ---------- */

/** Append-only tables: the public key may create rows but never update
 *  them (by design), so mirroring uses plain INSERT — ids are unique,
 *  and a rare duplicate is simply a row that was already mirrored. */
const INSERT_ONLY: ReadonlySet<string> = new Set(["ContactMessage", "Subscriber"]);

export function mirrorUpsert(table: SyncTable, row: Record<string, unknown>): void {
  if (!supabaseEnabled) return;
  if (INSERT_ONLY.has(table)) {
    void sbTable
      .insert(table, row, { returning: false, silentConflict: true })
      .catch(() => undefined);
    return;
  }
  void sbTable.upsert(table, row).catch(() => undefined);
}

export function mirrorUpdate(
  table: SyncTable,
  id: string,
  patch: Record<string, unknown>
): void {
  if (!supabaseEnabled) return;
  void sbTable.update(table, id, patch).catch(() => undefined);
}

export function mirrorDelete(table: SyncTable, id: string): void {
  if (!supabaseEnabled) return;
  void sbTable.remove(table, id).catch(() => undefined);
}

/* ---------- one-time full sync (retried with cooldown) ---------- */

const RETRY_COOLDOWN_MS = 90_000;

const syncState = globalThis as unknown as {
  rvSyncDone: boolean | undefined;
  rvSyncLastAttempt: number | undefined;
  rvSyncPromise: Promise<boolean> | undefined;
};

async function readLocalRows(table: SyncTable): Promise<Record<string, unknown>[]> {
  switch (table) {
    case "Service":
      return db.service.findMany({ orderBy: { order: "asc" } });
    case "Project":
      return db.project.findMany({ orderBy: { order: "asc" } });
    case "Post":
      return db.post.findMany({ orderBy: { createdAt: "desc" } });
    case "Testimonial":
      return db.testimonial.findMany({ orderBy: { order: "asc" } });
    case "Stat":
      return db.stat.findMany({ orderBy: { order: "asc" } });
    case "Setting":
      return db.setting.findMany();
    case "ContactMessage":
      return db.contactMessage.findMany({ orderBy: { createdAt: "desc" } });
    case "Subscriber":
      return db.subscriber.findMany({ orderBy: { createdAt: "desc" } });
  }
}

async function runSync(): Promise<boolean> {
  if (!supabaseEnabled) return true;
  await ensureDb();
  let complete = true;

  for (const table of SB_SYNC_TABLES) {
    const remoteCount = await sbTable.count(table);
    if (remoteCount === null) {
      complete = false; // table not created yet — retry later
      continue;
    }
    if (remoteCount > 0) continue; // remote already has data — never overwrite

    const rows = await readLocalRows(table);
    if (rows.length === 0) continue;

    if (INSERT_ONLY.has(table)) {
      /* leads backfill: row-by-row plain inserts (no RETURNING — the
         rows are not readable by the public key). Duplicates mean the
         row was already mirrored — expected and harmless, so failures
         never block sync completeness. */
      for (const row of rows) {
        void sbTable
          .insert(table, row, { returning: false, silentConflict: true })
          .catch(() => undefined);
      }
      continue;
    }

    const ok = await sbTable.upsertMany(table, rows);
    if (!ok) complete = false;
  }

  /* settings singleton — keep the remote copy aligned */
  const setting = await db.setting.findUnique({ where: { id: "main" } });
  if (setting) await sbTable.upsert("Setting", setting);

  return complete;
}

/**
 * Push the full local dataset into empty Supabase tables.
 * Safe to call from any request path: runs at most once per process,
 * retries with a cooldown while remote tables do not exist yet, and
 * never throws. Once the owner runs supabase/schema.sql in their
 * Supabase SQL editor, the next request cycle completes the sync.
 */
export function ensureSupabaseSync(): void {
  if (!supabaseEnabled || syncState.rvSyncDone) return;
  const now = Date.now();
  if (
    syncState.rvSyncPromise &&
    now - (syncState.rvSyncLastAttempt ?? 0) < RETRY_COOLDOWN_MS
  ) {
    return;
  }
  syncState.rvSyncLastAttempt = now;
  syncState.rvSyncPromise = runSync()
    .then((ok) => {
      if (ok) syncState.rvSyncDone = true;
      return ok;
    })
    .catch(() => false);
}

/* ---------- leads: local write first, then mirror ---------- */

export interface NewMessage {
  name: string;
  email: string;
  phone: string | null;
  service: string | null;
  message: string;
}

export async function saveMessage(input: NewMessage) {
  try {
    const saved = await db.contactMessage.create({ data: input });
    mirrorUpsert("ContactMessage", saved as unknown as Record<string, unknown>);
    return saved;
  } catch (localError) {
    /* Hosted deployments without a reachable database (wrong/missing
       DATABASE_URL) must still accept leads — Supabase is the durable
       fallback store. */
    if (!supabaseEnabled) throw localError;
    console.error(
      "[store] local write failed — storing contact lead in Supabase:",
      String(localError).slice(0, 160)
    );
    const row = {
      id: randomUUID(),
      ...input,
      read: false,
      createdAt: new Date().toISOString(),
    };
    const result = await sbTable.insertLead("ContactMessage", row);
    if (result === "failed") throw localError; // both stores unavailable
    return { ...row, remote: true };
  }
}

export async function saveSubscriber(email: string) {
  try {
    const local = await db.subscriber.upsert({
      where: { email },
      update: {},
      create: { email },
    });
    mirrorUpsert("Subscriber", local as unknown as Record<string, unknown>);
    return local;
  } catch (localError) {
    if (!supabaseEnabled) throw localError;
    console.error(
      "[store] local write failed — storing subscriber in Supabase:",
      String(localError).slice(0, 160)
    );
    const row = {
      id: randomUUID(),
      email,
      createdAt: new Date().toISOString(),
    };
    const result = await sbTable.insertLead("Subscriber", row);
    /* duplicate = the email was already subscribed — idempotent success */
    if (result === "failed") throw localError;
    return { ...row, remote: true };
  }
}
