"use client"

import { Toaster as Sonner, ToasterProps } from "sonner"

/* The site ships a single (light) theme — next-themes was removed,
   so the toaster styling is fixed here. */
const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      theme="light"
      className="toaster group"
      style={
        {
          "--normal-bg": "var(--popover)",
          "--normal-text": "var(--popover-foreground)",
          "--normal-border": "var(--border)",
        } as React.CSSProperties
      }
      {...props}
    />
  )
}

export { Toaster }
