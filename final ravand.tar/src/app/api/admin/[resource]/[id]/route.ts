import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { isAdmin } from "@/lib/admin-auth";
import { sameOrigin } from "@/lib/http";
import { mirrorDelete, mirrorUpdate, mirrorUpsert, resourceTable } from "@/lib/store";
import { isResource, resourceSchemas, settingsSchema } from "@/lib/admin-resources";

export const dynamic = "force-dynamic";

const deny = () =>
  NextResponse.json({ ok: false, error: "UNAUTHORIZED" }, { status: 401 });

type AnyModel = {
  findUnique: (a: Record<string, unknown>) => Promise<Record<string, unknown> | null>;
  update: (a: Record<string, unknown>) => Promise<Record<string, unknown>>;
  delete: (a: Record<string, unknown>) => Promise<Record<string, unknown>>;
};

function model(resource: string): AnyModel {
  switch (resource) {
    case "services":
      return db.service as unknown as AnyModel;
    case "projects":
      return db.project as unknown as AnyModel;
    case "posts":
      return db.post as unknown as AnyModel;
    case "testimonials":
      return db.testimonial as unknown as AnyModel;
    case "stats":
      return db.stat as unknown as AnyModel;
    case "subscribers":
      return db.subscriber as unknown as AnyModel;
    case "messages":
      return db.contactMessage as unknown as AnyModel;
    default:
      throw new Error("unknown resource");
  }
}

const IdSchema = z.string().trim().min(1).max(64);

/** Validated id or null — keeps malformed ids at 400, not 500. */
function safeId(raw: string): string | null {
  const parsed = IdSchema.safeParse(raw);
  return parsed.success ? parsed.data : null;
}

/** Prisma "record not found" → 404; anything else → 500. */
function errorStatus(error: unknown): number {
  return String(error).includes("P2025") ? 404 : 500;
}

/** PUT /api/admin/[resource]/[id] — update (editable resources + settings singleton). */
export async function PUT(
  req: Request,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  if (!(await isAdmin()) || !sameOrigin(req)) return deny();
  const { resource, id } = await params;

  /* settings singleton — PUT /api/admin/settings/main */
  if (resource === "settings") {
    if (id !== "main")
      return NextResponse.json({ ok: false, error: "NOT_FOUND" }, { status: 404 });
    try {
      await ensureDb();
      const body = await req.json();
      const parsed = settingsSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json(
          { ok: false, error: "VALIDATION", issues: parsed.error.flatten().fieldErrors },
          { status: 400 }
        );
      }
      const item = await db.setting.upsert({
        where: { id: "main" },
        update: parsed.data,
        create: { id: "main", ...parsed.data },
      });
      mirrorUpsert("Setting", item as unknown as Record<string, unknown>);
      return NextResponse.json({ ok: true, item });
    } catch (error) {
      console.error("[admin/settings] put failed:", error);
      return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
    }
  }

  if (!isResource(resource))
    return NextResponse.json({ ok: false, error: "NOT_FOUND" }, { status: 404 });
  const rowId = safeId(id);
  if (!rowId)
    return NextResponse.json({ ok: false, error: "INVALID_ID" }, { status: 400 });

  try {
    await ensureDb();
    const body = await req.json();
    const parsed = resourceSchemas[resource].safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: "VALIDATION", issues: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }
    const updated = await model(resource).update({
      where: { id: rowId },
      data: parsed.data as Record<string, unknown>,
    });
    /* mirror the change into Supabase (best-effort) */
    const table = resourceTable(resource);
    if (table) mirrorUpsert(table, updated);
    return NextResponse.json({ ok: true, item: updated });
  } catch (error) {
    const msg = String(error);
    if (msg.includes("Unique")) {
      return NextResponse.json({ ok: false, error: "DUPLICATE_SLUG" }, { status: 409 });
    }
    console.error(`[admin/${resource}] update failed:`, error);
    return NextResponse.json(
      { ok: false, error: "SERVER_ERROR" },
      { status: errorStatus(error) }
    );
  }
}

/** PATCH /api/admin/[resource]/[id] — light updates (e.g. message read flag). */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  if (!(await isAdmin()) || !sameOrigin(req)) return deny();
  const { resource, id } = await params;
  if (resource !== "messages")
    return NextResponse.json({ ok: false, error: "NOT_FOUND" }, { status: 404 });
  const rowId = safeId(id);
  if (!rowId)
    return NextResponse.json({ ok: false, error: "INVALID_ID" }, { status: 400 });

  try {
    await ensureDb();
    const body = (await req.json()) as { read?: boolean };
    const updated = await db.contactMessage.update({
      where: { id: rowId },
      data: { read: Boolean(body.read) },
    });
    mirrorUpdate("ContactMessage", updated.id, { read: updated.read });
    return NextResponse.json({ ok: true, item: updated });
  } catch (error) {
    console.error(`[admin/${resource}] patch failed:`, error);
    return NextResponse.json(
      { ok: false, error: "SERVER_ERROR" },
      { status: errorStatus(error) }
    );
  }
}

/** DELETE /api/admin/[resource]/[id] — remove (admin only). */
export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  if (!(await isAdmin()) || !sameOrigin(_req)) return deny();
  const { resource, id } = await params;
  if (!isResource(resource) && resource !== "subscribers" && resource !== "messages")
    return NextResponse.json({ ok: false, error: "NOT_FOUND" }, { status: 404 });
  const rowId = safeId(id);
  if (!rowId)
    return NextResponse.json({ ok: false, error: "INVALID_ID" }, { status: 400 });

  try {
    await ensureDb();
    await model(resource).delete({ where: { id: rowId } });
    /* mirror the removal into Supabase (best-effort) */
    const table = resourceTable(resource);
    if (table) mirrorDelete(table, id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`[admin/${resource}] delete failed:`, error);
    return NextResponse.json(
      { ok: false, error: "SERVER_ERROR" },
      { status: errorStatus(error) }
    );
  }
}
