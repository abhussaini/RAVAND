"use client";

import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { ContactForm } from "../contact-form";
import { PageHero } from "../page-hero";
import { SiteFooter } from "../site-footer";
import { Reveal } from "../reveal";
import { WhatsAppIcon } from "../icons";
import { cn } from "@/lib/utils";

const FALLBACK = {
  email: "hello@rawandtech.com",
  phone1: "0777 638 600",
  phone2: "0793 268 319",
  whatsapp: "93777638600",
};

/** Contact page — info cards + inline consultation form. */
export function ContactPage() {
  const { t } = useT();
  const { content, pick } = useContent();
  const s = content?.settings;

  const email = s?.email || FALLBACK.email;
  const phone1 = s?.phone1 ? s.phone1.replace("+93", "0") : FALLBACK.phone1;
  const phone2 = s?.phone2 ? s.phone2.replace("+93", "0") : FALLBACK.phone2;
  const whatsapp = s?.whatsapp || FALLBACK.whatsapp;

  const cards = [
    {
      icon: Mail,
      label: t("contact.email_l"),
      value: email,
      href: `mailto:${email}`,
      ltr: true,
      wa: false,
    },
    {
      icon: Phone,
      label: t("contact.phone_l"),
      value: `${phone1} — ${phone2}`,
      href: s?.phone1 ? `tel:${s.phone1}` : "tel:+93777638600",
      ltr: true,
      wa: false,
    },
    {
      icon: WhatsAppIcon,
      label: t("contact.whatsapp"),
      value: phone1,
      href: `https://wa.me/${whatsapp}`,
      ltr: true,
      wa: true,
    },
    {
      icon: MapPin,
      label: t("contact.address_l"),
      value: pick(s?.address) || t("contact.address"),
      href: undefined,
      ltr: false,
    },
    {
      icon: Clock,
      label: t("contact.hours_l"),
      value: pick(s?.hours) || t("contact.hours"),
      href: undefined,
      ltr: false,
    },
  ];

  return (
    <>
      <main className="flex-1">
        <PageHero
          title={t("contact.title")}
          desc={t("contact.desc")}
          sticker="/stickers/st-contact.svg"
          backTo="/"
          backLabel={t("nav.home")}
        />

        <section className="bg-white px-6 py-16 sm:px-10 sm:py-20">
          <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:gap-14">
            {/* info cards */}
            <div>
              <Reveal from={{ opacity: 0, y: 22 }}>
                <h2 className="font-display text-xl font-medium sm:text-2xl">{t("contact.info_t")}</h2>
              </Reveal>
              <ul className="mt-6 flex flex-col gap-3">
                {cards.map((c, i) => {
                  const inner = (
                    <>
                      <span
                        aria-hidden
                        className={cn(
                          "grid size-11 shrink-0 place-items-center rounded-xl transition-colors duration-300",
                          c.wa
                            ? "bg-[#25D366]/12 text-[#128C7E] group-hover:bg-[#25D366] group-hover:text-white"
                            : "bg-surface text-brand group-hover:bg-brand group-hover:text-white"
                        )}
                      >
                        <c.icon className="size-5" strokeWidth={1.7} />
                      </span>
                      <span className="min-w-0">
                        <span className="display-caps block text-[0.7rem] font-medium uppercase tracking-[0.16em] text-ink-soft">
                          {c.label}
                        </span>
                        <span dir={c.ltr ? "ltr" : undefined} className="mt-0.5 block truncate text-sm font-medium text-ink">
                          {c.value}
                        </span>
                      </span>
                    </>
                  );
                  return (
                    <li key={c.label}>
                      <Reveal from={{ opacity: 0, y: 16 }} delayIn={i * 0.06}>
                        {c.href ? (
                          <a
                            href={c.href}
                            target={c.href.startsWith("http") ? "_blank" : undefined}
                            rel="noreferrer"
                            className="group flex items-center gap-4 rounded-card border border-hairline p-4 transition-colors duration-300 hover:border-brand/40"
                          >
                            {inner}
                          </a>
                        ) : (
                          <div className="group flex items-center gap-4 rounded-card border border-hairline p-4">
                            {inner}
                          </div>
                        )}
                      </Reveal>
                    </li>
                  );
                })}
              </ul>
              <Reveal from={{ opacity: 0, y: 14 }} delayIn={0.3}>
                <p className="mt-6 text-sm text-ink-soft">{t("contact.hours_note")}</p>
              </Reveal>
            </div>

            {/* form */}
            <Reveal from={{ opacity: 0, y: 28 }} delayIn={0.15}>
              <div className="rounded-card-lg border border-hairline bg-surface p-6 sm:p-8">
                <h2 className="font-display text-xl font-medium sm:text-2xl">{t("contact.send")}</h2>
                <div className="mt-6">
                  <ContactForm />
                </div>
              </div>
            </Reveal>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
