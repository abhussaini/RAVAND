import { NextResponse } from "next/server";
import { db, ensureDb } from "@/lib/db";
import { deny, guard } from "@/lib/seo/guard";

export const dynamic = "force-dynamic";

/* GET /api/seo/changes — audit trail of applied/rolled-back fixes. */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    await ensureDb();
    const changes = await db.seoChange.findMany({ orderBy: { createdAt: "desc" }, take: 60 });
    return NextResponse.json({ ok: true, changes });
  } catch (error) {
    console.error("[seo/changes] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
