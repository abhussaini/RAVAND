"use client";

import { useEffect } from "react";
import { useLang, langMeta } from "@/store/use-lang";

/**
 * Keeps <html lang/dir> in sync with the selected UI language.
 * Rehydrates the persisted language store after mount (no SSR mismatch).
 */
export function LangSync() {
  const lang = useLang((s) => s.lang);
  const setLang = useLang((s) => s.setLang);

  // hydrate persisted language once, after mount (sessionStorage —
  // every new visit intentionally starts in English)
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem("ravand-lang");
      if (raw) {
        const parsed = JSON.parse(raw) as { state?: { lang?: string } };
        const stored = parsed?.state?.lang;
        if (stored === "fa" || stored === "ps" || stored === "en") {
          if (stored !== useLang.getState().lang) setLang(stored);
        }
      }
    } catch {
      /* ignore corrupt storage */
    }
  }, []);

  useEffect(() => {
    const meta = langMeta[lang];
    document.documentElement.lang = lang;
    document.documentElement.dir = meta.dir;
  }, [lang]);

  return null;
}
