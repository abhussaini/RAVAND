"use client";

import { useEffect } from "react";
import { createPortal } from "react-dom";
import { useT, langMeta, type Lang } from "@/lib/i18n";
import { navigate } from "@/lib/router";
import { useLang } from "@/store/use-lang";
import { useUi } from "@/store/use-ui";
import { useMounted } from "./reveal";
import { BrandLockup, PillButton } from "./ui-v2";

const NAV = [
  { key: "nav.home", to: "/" },
  { key: "nav.services", to: "/services" },
  { key: "nav.portfolio", to: "/portfolio" },
  { key: "nav.blog", to: "/blog" },
  { key: "nav.about", to: "/about" },
  { key: "nav.contact", to: "/contact" },
] as const;

/** Fullscreen navy menu overlay (from the header burger). */
export function MenuOverlay() {
  const { t } = useT();
  const open = useUi((s) => s.menuOpen);
  const setMenuOpen = useUi((s) => s.setMenuOpen);
  const openContact = useUi((s) => s.openContact);
  const lang = useLang((s) => s.lang);
  const setLang = useLang((s) => s.setLang);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setMenuOpen]);

  /* portals must wait for mount — server and the hydration render
     both return null so the trees match exactly */
  const mounted = useMounted();
  if (typeof document === "undefined" || !mounted) return null;

  /* always mounted — CSS visibility/transform toggle gives real
     enter/exit transitions with zero unmount cost */
  return createPortal(
    <div
      className={`fixed inset-0 z-[70] flex flex-col transition-[visibility] duration-300 ${open ? "visible" : "invisible"}`}
      role="dialog"
      aria-modal="true"
      aria-label={t("nav.menu")}
      aria-hidden={!open}
    >
      {/* backdrop */}
      <div
        className={`absolute inset-0 bg-brand-deep transition-[opacity,visibility] duration-300 ${
          open ? "visible opacity-100" : "invisible opacity-0"
        }`}
        onClick={() => setMenuOpen(false)}
      />
      {/* panel */}
      <div
        className={`relative flex h-full flex-col p-2 transition-[opacity,transform,visibility] duration-300 sm:p-3 ${
          open ? "visible translate-y-0 opacity-100" : "invisible -translate-y-6 opacity-0"
        }`}
      >
        <div className="flex h-full flex-col rounded-card-lg px-6 py-6 text-white sm:px-10">
          {/* top row */}
          <div className="flex items-center justify-between">
            <BrandLockup
              markClassName="size-[1.75rem]"
              wordClassName="text-base"
              onSingle={() => {
                setMenuOpen(false);
                navigate("/");
              }}
            />
            <button
              type="button"
              onClick={() => setMenuOpen(false)}
              aria-label="Close menu"
              className="group grid size-10 cursor-pointer place-items-center rounded-pill bg-white/15 transition-colors hover:bg-white/25"
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.8}
                strokeLinecap="round"
                aria-hidden
                className="size-4 transition-transform duration-300 group-hover:rotate-90"
              >
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>

          {/* center nav — staggered rise on open */}
          <nav
            aria-label="Menu"
            className="flex flex-1 flex-col justify-center gap-1.5 py-8"
          >
            {NAV.map((item, i) => (
              <button
                key={item.to}
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  window.setTimeout(() => navigate(item.to), 220);
                }}
                className="display-caps cursor-pointer text-start text-4xl font-medium leading-none tracking-tight transition-colors duration-300 hover:text-brand-light sm:text-6xl"
                style={{
                  opacity: open ? 1 : 0,
                  transform: open ? "translate3d(0,0,0)" : "translate3d(0,28px,0)",
                  transition:
                    "opacity 0.55s ease, transform 0.7s cubic-bezier(0.16, 1, 0.3, 1)",
                  transitionDelay: open ? `${0.1 + i * 0.06}s` : "0s",
                }}
              >
                {t(item.key)}
              </button>
            ))}
          </nav>

          {/* language switcher */}
          <div className="flex items-center gap-2 pb-8" role="group" aria-label={t("nav.language")}>
            {(Object.keys(langMeta) as Lang[]).map((l) => (
              <button
                key={l}
                type="button"
                onClick={() => setLang(l)}
                aria-pressed={lang === l}
                className={
                  "display-caps cursor-pointer rounded-pill px-4 py-2 text-xs font-medium uppercase tracking-wide transition-colors " +
                  (lang === l
                    ? "bg-white text-brand-deep"
                    : "bg-white/10 text-white/80 hover:bg-white/20")
                }
              >
                {langMeta[l].english}
              </button>
            ))}
          </div>

          {/* bottom row */}
          <div className="flex flex-col gap-4 border-t border-white/15 pt-8 sm:flex-row sm:items-center sm:justify-between">
            <PillButton variant="light" onClick={() => openContact()}>
              {t("nav.cta")}
            </PillButton>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[0.8rem] text-white/70">
              <a className="transition-colors hover:text-white" href="https://instagram.com/rawandtech" target="_blank" rel="noreferrer">
                Instagram
              </a>
              <a className="transition-colors hover:text-white" href="https://wa.me/93777638600" target="_blank" rel="noreferrer">
                WhatsApp
              </a>
              <a className="transition-colors hover:text-white" href="mailto:hello@rawandtech.com">
                hello@rawandtech.com
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
