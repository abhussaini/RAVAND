import { z } from "zod";

/**
 * Admin CRUD registry — one typed schema per manageable resource.
 * L10n fields arrive as objects {fa, ps, en} from the admin panel and
 * are stringified before persisting (SQLite has no JSON columns).
 */

/* accepts {fa,ps,en} object or already-stringified JSON, stores as string */
const l10n = z.preprocess(
  (v) => (v !== null && v !== undefined && typeof v === "object" ? JSON.stringify(v) : String(v ?? "{}")),
  z.string().max(8000)
);

const baseSlug = z
  .string()
  .trim()
  .min(1)
  .max(80)
  .regex(/^[a-z0-9-]+$/, "slug: lowercase letters, numbers, dashes only");

export const resourceSchemas = {
  services: z.object({
    slug: baseSlug,
    title: l10n,
    desc: l10n,
    sticker: z.string().trim().max(300).default("/stickers/st-services.svg"),
    order: z.coerce.number().int().min(0).max(999).default(0),
    active: z.coerce.boolean().default(true),
  }),
  projects: z.object({
    slug: baseSlug,
    title: l10n,
    cat: l10n,
    desc: l10n.default("{}"),
    sticker: z.string().trim().max(300).default("/stickers/st-portfolio.svg"),
    order: z.coerce.number().int().min(0).max(999).default(0),
    active: z.coerce.boolean().default(true),
  }),
  posts: z.object({
    slug: baseSlug,
    title: l10n,
    cat: l10n.default("{}"),
    excerpt: l10n.default("{}"),
    body: l10n.default("{}"),
    sticker: z.string().trim().max(300).default("/stickers/st-blog.svg"),
    readMin: z.coerce.number().int().min(1).max(120).default(6),
    dateLabel: l10n.default("{}"),
    published: z.coerce.boolean().default(true),
  }),
  testimonials: z.object({
    name: z.string().trim().min(1).max(120),
    role: l10n,
    quote: l10n,
    order: z.coerce.number().int().min(0).max(999).default(0),
    active: z.coerce.boolean().default(true),
  }),
  stats: z.object({
    value: z.coerce.number().int().min(0).max(100000).default(0),
    suffix: z.string().trim().max(8).default(""),
    label: l10n,
    sub: l10n.default("{}"),
    order: z.coerce.number().int().min(0).max(999).default(0),
    active: z.coerce.boolean().default(true),
  }),
} as const;

/** Singleton settings schema (PUT /api/admin/settings/main) */
export const settingsSchema = z.object({
  logoUrl: z.string().trim().max(300).default("/images/logo-r.webp"),
  email: z.string().trim().max(160).default("hello@rawandtech.com"),
  phone1: z.string().trim().max(40).default(""),
  phone2: z.string().trim().max(40).default(""),
  whatsapp: z.string().trim().max(40).default(""),
  instagram: z.string().trim().max(300).default(""),
  tagline: l10n.default("{}"),
  address: l10n.default("{}"),
  hours: l10n.default("{}"),
});

export type ResourceKey = keyof typeof resourceSchemas;

export const isResource = (k: string): k is ResourceKey =>
  Object.prototype.hasOwnProperty.call(resourceSchemas, k);

/** read-only resources handled with the same route but no create/update */
export const readOnly = new Set(["subscribers", "messages"]);

export function resourceTable(key: ResourceKey) {
  switch (key) {
    case "services":
      return "service" as const;
    case "projects":
      return "project" as const;
    case "posts":
      return "post" as const;
    case "testimonials":
      return "testimonial" as const;
    case "stats":
      return "stat" as const;
  }
}
