import { NextResponse } from "next/server";
import { z } from "zod";
import { ensureDb } from "@/lib/db";
import { saveMessage } from "@/lib/store";
import { supabaseEnabled } from "@/lib/supabase";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { sameOrigin } from "@/lib/http";

const ContactSchema = z.object({
  name: z.string().trim().min(2, "name too short").max(120),
  email: z.string().trim().email("invalid email").max(160),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  service: z
    .enum(["web", "software", "uiux", "shop", "seo", "support"])
    .optional()
    .or(z.literal("")),
  message: z.string().trim().min(5, "message too short").max(4000),
});

export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return NextResponse.json({ ok: false, error: "BAD_ORIGIN" }, { status: 403 });
  }
  /* spam protection — 5 messages per 10 minutes per IP */
  const rl = rateLimit(`contact:${clientIp(request)}`, 5, 10 * 60_000);
  if (!rl.ok) {
    return NextResponse.json(
      { ok: false, error: "RATE_LIMITED", retryAfter: rl.retryAfter },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } }
    );
  }

  /* parse the body first — needs no database */
  let body: unknown;
  try {
    body = await request.json();
  } catch (error) {
    /* malformed JSON body — client error, not a server fault */
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { ok: false, error: "VALIDATION", issues: { body: ["invalid JSON"] } },
        { status: 400 }
      );
    }
    console.error("[/api/contact] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }

  /* bootstrap the local database — on hosted platforms without a
     writable filesystem this fails, and that is fine: saveMessage()
     falls back to Supabase, so the lead is never lost */
  try {
    await ensureDb();
  } catch (error) {
    if (!supabaseEnabled) {
      console.error("[/api/contact] database unavailable:", error);
      return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
    }
    console.error(
      "[/api/contact] local db unavailable — Supabase fallback active:",
      String(error).slice(0, 160)
    );
  }

  try {
    const parsed = ContactSchema.safeParse(body);

    if (!parsed.success) {
      /* log field-level issues (never the values) so failed submissions
         are diagnosable from the server log alone */
      const issues = parsed.error.flatten().fieldErrors;
      console.warn("[/api/contact] validation failed:", JSON.stringify(issues));
      return NextResponse.json(
        { ok: false, error: "VALIDATION", issues },
        { status: 400 }
      );
    }

    const { name, email, phone, service, message } = parsed.data;

    const saved = await saveMessage({
      name,
      email,
      phone: phone || null,
      service: service || null,
      message,
    });

    return NextResponse.json({ ok: true, id: saved.id }, { status: 201 });
  } catch (error) {
    console.error("[/api/contact] failed:", error);
    return NextResponse.json(
      { ok: false, error: "SERVER_ERROR" },
      { status: 500 }
    );
  }
}
