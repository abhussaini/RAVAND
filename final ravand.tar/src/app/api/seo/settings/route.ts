import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { normalizeBase } from "@/lib/seo/config";

export const dynamic = "force-dynamic";

const PutSchema = z.object({ baseUrl: z.string().trim().max(200).default("") });

/* GET /api/seo/settings — current SEO settings + env config flags. */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    await ensureDb();
    const setting = await db.seoSetting.findUnique({ where: { id: "main" } });
    return NextResponse.json({
      ok: true,
      settings: {
        baseUrl: setting?.baseUrl ?? "",
        psiKey: Boolean(process.env.PAGESPEED_API_KEY),
        cronSecret: Boolean(process.env.CRON_SECRET),
        adminDefaultPassword: !process.env.ADMIN_PASSWORD,
      },
    });
  } catch (error) {
    console.error("[seo/settings] get failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}

/* PUT /api/seo/settings — set the production base URL.
   Validation: absolute http(s) URL; the value is used for crawling,
   sitemap/canonical checks and never silently replaces the domain in
   code (canonical stays "pending" until this is set on purpose). */
export async function PUT(req: Request) {
  if (!(await guard(req))) return deny();
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = PutSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");

  const raw = parsed.data.baseUrl;
  if (raw) {
    const normalized = normalizeBase(raw);
    if (!normalized) return jsonError("INVALID_URL");
    await ensureDb();
    await db.seoSetting.upsert({
      where: { id: "main" },
      update: { baseUrl: normalized },
      create: { baseUrl: normalized },
    });
    return NextResponse.json({ ok: true, baseUrl: normalized });
  }

  await ensureDb();
  await db.seoSetting.upsert({
    where: { id: "main" },
    update: { baseUrl: "" },
    create: { baseUrl: "" },
  });
  return NextResponse.json({ ok: true, baseUrl: "" });
}
