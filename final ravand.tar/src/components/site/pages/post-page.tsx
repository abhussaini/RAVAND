"use client";

import Image from "next/image";
import { ArrowLeft, ArrowRight, Clock } from "lucide-react";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { navigate } from "@/lib/router";
import { Reveal } from "../reveal";
import { SiteFooter } from "../site-footer";
import { BrandMark, BrandWordmark } from "../ui-v2";

const FALLBACK: Record<string, { title: string; cat: string; excerpt: string; date: string; read: number; img: string }> = {
  "web-design-trends-2025": { title: "b1_title", cat: "b1_cat", excerpt: "b1_d", date: "b1_date", read: 6, img: "/stickers/blog-web.svg" },
  "ai-automation-small-business": { title: "b2_title", cat: "b2_cat", excerpt: "b2_d", date: "b2_date", read: 8, img: "/stickers/blog-ai.svg" },
  "seo-afghan-market": { title: "b3_title", cat: "b3_cat", excerpt: "b3_d", date: "b3_date", read: 7, img: "/stickers/blog-seo.svg" },
};

/**
 * Post detail (#/blog/:slug) — sticker cover, trilingual title/body
 * from the DB (admin panel), with dictionary fallback.
 */
export function PostPage({ slug }: { slug: string }) {
  const { t, isRtl } = useT();
  const { content, pick } = useContent();

  const post = content?.posts?.find((p) => p.slug === slug);
  const fb = FALLBACK[slug];

  /* content loaded but the slug matches nothing (and no fallback) →
     proper not-found state instead of a hollow page */
  const resolved = !post && !fb && content; // content IS loaded, slug unknown

  const title = post ? pick(post.title) : fb ? t(fb.title) : slug;
  const cat = post ? pick(post.cat) : fb ? t(fb.cat) : "";
  const excerpt = post ? pick(post.excerpt) : fb ? t(fb.excerpt) : "";
  const date = post ? pick(post.dateLabel) : fb ? t(fb.date) : "";
  const readMin = post?.readMin ?? fb?.read ?? 6;
  const img = post?.sticker ?? fb?.img ?? "/stickers/st-blog.svg";

  const bodySrc = post ? pick(post.body) : "";
  const paragraphs = bodySrc
    ? bodySrc.split(/\n+/).filter(Boolean)
    : excerpt
      ? [excerpt, t("blog.p1"), t("blog.p2")]
      : [];

  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  if (resolved) {
    return (
      <>
        <main className="flex-1">
          <section className="relative isolate overflow-hidden rounded-card-lg bg-brand-deep text-white">
            <div
              aria-hidden
              className="absolute inset-0"
              style={{ background: "linear-gradient(160deg,#0f2f63 0%,#123a79 48%,#0b2a58 100%)" }}
            />
            <div className="relative z-10 px-6 pb-14 pt-16 text-center sm:px-10 sm:pb-20 sm:pt-20">
              <p className="display-caps text-xs font-medium uppercase tracking-[0.2em] text-white/50">404</p>
              <h1 className="font-display mx-auto mt-4 max-w-xl text-3xl font-medium sm:text-4xl">{t("blog.nf_t")}</h1>
              <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-white/70">{t("blog.nf_d")}</p>
              <button
                type="button"
                onClick={() => navigate("/blog")}
                className="display-caps mt-8 inline-flex cursor-pointer items-center gap-2 rounded-pill bg-white px-7 py-3 text-sm font-medium uppercase tracking-wide text-brand-deep transition-colors hover:bg-brand-light hover:text-white"
              >
                <BackIcon className="size-4 rtl:-scale-x-100" aria-hidden />
                {t("blog.back")}
              </button>
            </div>
          </section>
        </main>
        <SiteFooter />
      </>
    );
  }

  return (
    <>
      <main className="flex-1">
        {/* slim navy band with header + title */}
        <section className="relative isolate overflow-hidden rounded-card-lg bg-brand-deep text-white">
          <div
            aria-hidden
            className="absolute inset-0"
            style={{ background: "linear-gradient(160deg,#0f2f63 0%,#123a79 48%,#0b2a58 100%)" }}
          />
          <div className="relative z-10">
            {/* brand header (single back button — no full SiteHeader) */}
            <div className="flex items-center justify-between px-6 pt-6 sm:px-10 sm:pt-8">
              <button
                type="button"
                onClick={() => navigate("/blog")}
                className="inline-flex cursor-pointer items-center gap-2 text-xs font-medium text-white/75 transition-colors hover:text-white"
              >
                <BackIcon className="size-3.5 rtl:-scale-x-100" aria-hidden />
                {t("blog.back")}
              </button>
              <button type="button" onClick={() => navigate("/")} className="flex cursor-pointer items-center gap-2" aria-label={t("nav.home")}>
                <BrandMark />
                <BrandWordmark className="text-base" />
              </button>
              <span className="w-16" aria-hidden />
            </div>

            <div className="px-6 pb-12 pt-10 sm:px-10 sm:pb-16">
              {cat && (
                <span className="display-caps inline-flex rounded-pill bg-white/10 px-4 py-1.5 text-[0.7rem] font-medium uppercase tracking-wide text-white/85">
                  {cat}
                </span>
              )}
              <h1 className="font-display t-section mt-5 max-w-3xl font-medium">
                <span className="block overflow-hidden pb-[0.12em] mb-[-0.12em]">
                  <span
                    className="anim-rise block"
                    style={{ animationDuration: "0.8s" }}
                  >
                    {title}
                  </span>
                </span>
              </h1>
              <p className="mt-4 flex items-center gap-2.5 text-xs text-white/65">
                <span>{date}</span>
                <span aria-hidden className="size-1 rounded-pill bg-white/40" />
                <span className="inline-flex items-center gap-1">
                  <Clock aria-hidden className="size-3" />
                  {readMin} {t("blog.min")}
                </span>
              </p>
            </div>
          </div>
        </section>

        {/* body */}
        <article className="bg-white px-6 py-14 sm:px-10 sm:py-16">
          <div className="mx-auto max-w-3xl">
            <Reveal from={{ opacity: 0, y: 30 }}>
              <div className="grid place-items-center rounded-card bg-surface py-12">
                <Image src={img} alt={title} width={280} height={280} className="size-60 object-contain" sizes="280px" />
              </div>
            </Reveal>

            <div className="mt-10 flex flex-col gap-5">
              {paragraphs.map((p, i) => (
                <Reveal key={i} from={{ opacity: 0, y: 18 }} delayIn={i * 0.05}>
                  <p className="text-[0.95rem] leading-[1.9] text-ink sm:text-base">{p}</p>
                </Reveal>
              ))}
            </div>

            <Reveal from={{ opacity: 0, y: 18 }} delayIn={0.1}>
              <button
                type="button"
                onClick={() => navigate("/blog")}
                className="mt-12 inline-flex cursor-pointer items-center gap-2 rounded-pill border border-hairline px-6 py-3 text-sm font-medium text-ink transition-colors hover:border-ink"
              >
                <BackIcon className="size-4 rtl:-scale-x-100" aria-hidden />
                {t("blog.back")}
              </button>
            </Reveal>
          </div>
        </article>
      </main>
      <SiteFooter />
    </>
  );
}
