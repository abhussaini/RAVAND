/* ------------------------------------------------------------------
   Ravand AI SEO Assistant — Netlify Scheduled Function.

   Runs once per day after deployment. It calls the site's own
   /api/seo/tasks/run endpoint with the shared CRON_SECRET; the task
   runner inside the app decides which of the daily / weekly / monthly
   jobs are actually due (self-healing: missed schedules catch up,
   duplicates are impossible).

   Required Netlify environment variables:
     • CRON_SECRET  — shared secret, must match the app's CRON_SECRET
     • (Netlify injects `URL` automatically = the site's primary URL)

   Local dev: scheduled functions do NOT run under `next dev` — use the
   dashboard's "Run due tasks now" button or:
     curl -X POST https://SITE/api/seo/tasks/run \
       -H "x-cron-secret: $CRON_SECRET" -H "Content-Type: application/json" \
       -d '{"task":"due"}'
   ------------------------------------------------------------------ */

const handler = async (req, context) => {
  const siteUrl = process.env.URL;
  const secret = process.env.CRON_SECRET;

  if (!siteUrl || !secret) {
    return new Response(
      JSON.stringify({ ok: false, error: "MISSING_URL_OR_CRON_SECRET" }),
      { status: 500, headers: { "content-type": "application/json" } }
    );
  }

  try {
    const res = await fetch(`${siteUrl}/api/seo/tasks/run`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-cron-secret": secret,
      },
      body: JSON.stringify({ task: "due", trigger: "schedule" }),
      signal: AbortSignal.timeout(250_000),
    });
    const body = await res.text().catch(() => "");
    console.log(`[seo-scheduler] tasks/run → ${res.status} ${body.slice(0, 300)}`);
    return new Response(JSON.stringify({ ok: res.ok, status: res.status }), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  } catch (error) {
    console.error("[seo-scheduler] failed:", error);
    return new Response(JSON.stringify({ ok: false, error: "SCHEDULER_FAILED" }), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  }
};

export const config = {
  /* every day ~03:00 UTC — due-ness of daily/weekly/monthly is decided
     inside the app by the last successful run */
  schedule: "@daily",
};

export default handler;
