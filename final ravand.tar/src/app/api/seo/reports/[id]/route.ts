import { NextResponse } from "next/server";
import { db, ensureDb } from "@/lib/db";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { reportToCsv, type ReportSummary } from "@/lib/seo/reports";

export const dynamic = "force-dynamic";

/* GET /api/seo/reports/[id][?format=csv] — one report (JSON or CSV). */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await guard(req))) return deny();
  const { id } = await params;
  try {
    await ensureDb();
    const report = await db.seoReport.findUnique({ where: { id } });
    if (!report) return jsonError("NOT_FOUND", 404);

    const format = new URL(req.url).searchParams.get("format");
    if (format === "csv") {
      const summary = JSON.parse(report.summary) as ReportSummary;
      return new NextResponse(reportToCsv(summary), {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="ravand-seo-report-${report.period}-${report.createdAt.toISOString().slice(0, 10)}.csv"`,
        },
      });
    }

    return NextResponse.json({ ok: true, report });
  } catch (error) {
    console.error("[seo/reports] detail failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
