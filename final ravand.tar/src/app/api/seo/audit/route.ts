import { NextResponse } from "next/server";
import { db, ensureDb } from "@/lib/db";
import { deny, guard } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { runAudit } from "@/lib/seo/audit";
import type { TextLang } from "@/lib/seo/audit-texts";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/* GET /api/seo/audit            → audit history (20 latest)
   GET /api/seo/audit?id=…      → one audit + per-page results       */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();

  try {
    await ensureDb();
    const id = new URL(req.url).searchParams.get("id");
    if (id) {
      const audit = await db.seoAudit.findUnique({ where: { id } });
      if (!audit) return NextResponse.json({ ok: false, error: "NOT_FOUND" }, { status: 404 });
      const pages = await db.seoPageResult.findMany({ where: { auditId: id } });
      return NextResponse.json({ ok: true, audit, pages });
    }
    const audits = await db.seoAudit.findMany({ orderBy: { startedAt: "desc" }, take: 20 });
    return NextResponse.json({ ok: true, audits });
  } catch (error) {
    console.error("[seo/audit] list failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}

/* POST /api/seo/audit — run a fresh audit (admin only, rate-limited). */
export async function POST(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-audit:${clientIp(req)}`, 1, 60_000);
  if (!rl.ok) {
    return NextResponse.json(
      { ok: false, error: "RATE_LIMITED", retryAfter: rl.retryAfter },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } }
    );
  }

  let lang: TextLang = "en";
  try {
    const body = (await req.json()) as { lang?: string };
    if (body?.lang === "fa" || body?.lang === "en") lang = body.lang;
  } catch {
    /* empty body allowed */
  }

  try {
    const outcome = await runAudit("manual", lang);
    return NextResponse.json({ ok: outcome.status === "done", outcome });
  } catch (error) {
    console.error("[seo/audit] run failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
