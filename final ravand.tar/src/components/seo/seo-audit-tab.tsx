"use client";

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FileText, Loader2, Radar } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { fmtDate, seoApi, type AuditRow, type PageResultRow } from "./seo-api";
import { Badge, CheckRow, EmptyState, Loading, SeoCard, type SeoTabProps } from "./seo-ui";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — Website Audit tab (dashboard section B/F).
   Shows the real technical checks from the latest audit run.
   ------------------------------------------------------------------ */

interface SiteSummary {
  baseUrl?: string;
  https?: boolean;
  robots?: { status: number; ok: boolean; hasSitemap?: boolean; agentCount?: number };
  sitemap?: { status: number; count: number; hostMismatch?: boolean };
  site?: { status: number; ms: number; title?: string; titleLength?: number; descriptionLength?: number; h1Count?: number; images?: number; imagesNoAlt?: number; wordCount?: number; lang?: string; viewport?: boolean; og?: boolean; twitter?: boolean; jsonLdTypes?: string[]; externalLinks?: number; internalLinks?: number };
  spa?: { serverRenderedRoutes?: string[]; hashRoutesInSitemap?: number };
  linkChecks?: { assetsChecked?: number; brokenAssets?: string[]; externalChecked?: number; brokenExternal?: string[] };
  content?: { posts?: number };
  error?: string;
}

function parseSummary(raw: string): SiteSummary {
  try {
    return JSON.parse(raw) as SiteSummary;
  } catch {
    return {};
  }
}

function parsePageIssues(raw: string): { code: string; message: string; severity: string }[] {
  try {
    return JSON.parse(raw) as { code: string; message: string; severity: string }[];
  } catch {
    return [];
  }
}

export function AuditTab({ lang, t }: Omit<SeoTabProps, "dir">) {
  const qc = useQueryClient();
  const [selected, setSelected] = useState<string | null>(null);

  const audits = useQuery({
    queryKey: ["seo-audits"],
    queryFn: () => seoApi<{ ok: true; audits: AuditRow[] }>("/api/seo/audit"),
    refetchOnMount: "always",
  });

  const latest = audits.data?.audits?.[0] ?? null;
  const activeId = selected ?? latest?.id ?? null;

  const detail = useQuery({
    queryKey: ["seo-audit", activeId],
    queryFn: () => seoApi<{ ok: true; audit: AuditRow; pages: PageResultRow[] }>(`/api/seo/audit?id=${activeId}`),
    enabled: Boolean(activeId),
  });

  const runAudit = useMutation({
    mutationFn: () => seoApi<{ ok: boolean }>("/api/seo/audit", { method: "POST", body: JSON.stringify({ lang }) }),
    onSuccess: () => {
      toast.success(lang === "fa" ? "ارزیابی کامل شد." : "Audit finished.");
      qc.invalidateQueries({ queryKey: ["seo-audits"] });
      qc.invalidateQueries({ queryKey: ["seo-overview"] });
      qc.invalidateQueries({ queryKey: ["seo-issues"] });
    },
    onError: (e: Error) => {
      if (e.message === "RATE_LIMITED")
        toast.error(lang === "fa" ? "هر دقیقه یک بار امکان اجرا است." : "One run per minute — try again shortly.");
      else toast.error(t("s.error"));
    },
  });

  const audit = detail.data?.audit;
  const pages = detail.data?.pages ?? [];
  const s = audit ? parseSummary(audit.summary) : {};

  return (
    <div className="grid grid-cols-1 gap-4 lg:gap-6">
      <SeoCard
        title={t("s.run_audit")}
        icon={Radar}
        action={
          <Button
            onClick={() => runAudit.mutate()}
            disabled={runAudit.isPending}
            className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
          >
            {runAudit.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Radar className="size-4" aria-hidden />}
            {t("s.run_audit")}
          </Button>
        }
      >
        {runAudit.isPending ? (
          <div className="flex items-center gap-2 text-sm text-ink-soft">
            <Loader2 className="size-4 animate-spin" aria-hidden />
            {t("s.running_audit")}
          </div>
        ) : (
          <p className="text-sm text-ink-soft">
            {lang === "fa"
              ? "بررسی واقعی: وضعیت سایت، robots.txt، نقشه سایت، HTTPS، عنوان/توضیحات، سرفصل‌ها، تصاویر، لینک‌ها، محتوای دیتابیس و ایندکس‌پذیری مسیرهای هش."
              : "Real checks: site status, robots.txt, sitemap, HTTPS, title/description, headings, images, links, database content and hash-route indexability."}
          </p>
        )}
      </SeoCard>

      {audits.isLoading ? (
        <Loading label={t("s.loading")} />
      ) : !audits.data?.audits?.length ? (
        <EmptyState icon={Radar} text={t("s.no_audit")} hint={t("s.no_audit_d")} />
      ) : (
        <>
          {audit && audit.status === "failed" ? (
            <SeoCard title={t("s.bad")} icon={Radar}>
              <p className="text-sm text-red-700">{audit.error || t("s.error")}</p>
            </SeoCard>
          ) : null}

          {audit && audit.status === "done" ? (
            <SeoCard title={t("s.site_checks")} icon={FileText}>
              <div className="grid gap-x-8 sm:grid-cols-2">
                <CheckRow
                  label={t("s.https")}
                  ok={s.https ?? null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={s.baseUrl}
                />
                <CheckRow
                  label={t("s.robots")}
                  ok={s.robots ? s.robots.ok && s.robots.status === 200 : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={s.robots ? `HTTP ${s.robots.status}${s.robots.hasSitemap ? " · Sitemap ✓" : ""}` : undefined}
                />
                <CheckRow
                  label={t("s.sitemap")}
                  ok={s.sitemap ? s.sitemap.status === 200 && s.sitemap.count > 0 : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={s.sitemap ? `HTTP ${s.sitemap.status} · ${s.sitemap.count} URL` : undefined}
                />
                <CheckRow
                  label={t("s.metadata")}
                  ok={s.site ? Boolean(s.site.titleLength) && Boolean(s.site.descriptionLength) : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={s.site ? `${s.site.titleLength ?? 0}/${s.site.descriptionLength ?? 0} ${t("s.char")}` : undefined}
                />
                <CheckRow
                  label={t("s.headings")}
                  ok={s.site ? s.site.h1Count === 1 : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={s.site ? `H1 × ${s.site.h1Count ?? 0}` : undefined}
                />
                <CheckRow
                  label={t("s.images")}
                  ok={s.site ? (s.site.imagesNoAlt ?? 0) === 0 : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={s.site ? `${s.site.images ?? 0} × ${t("s.images")}` : undefined}
                />
                <CheckRow
                  label={t("s.social")}
                  ok={s.site ? Boolean(s.site.og && s.site.twitter) : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                />
                <CheckRow
                  label={t("s.jsonld")}
                  ok={s.site ? (s.site.jsonLdTypes?.length ?? 0) > 0 : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={s.site?.jsonLdTypes?.join(", ")}
                />
                <CheckRow
                  label={t("s.mobile")}
                  ok={s.site ? Boolean(s.site.viewport) : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                />
                <CheckRow
                  label={t("s.links")}
                  ok={s.linkChecks ? (s.linkChecks.brokenAssets?.length ?? 0) === 0 : null}
                  okLabel={t("s.ok")}
                  badLabel={t("s.bad")}
                  naLabel={t("s.na")}
                  detail={
                    s.linkChecks
                      ? `${s.linkChecks.assetsChecked ?? 0} + ${s.linkChecks.externalChecked ?? 0} → ${(s.linkChecks.brokenAssets?.length ?? 0) + (s.linkChecks.brokenExternal?.length ?? 0)} ${t("s.bad")}`
                      : undefined
                  }
                />
              </div>
            </SeoCard>
          ) : null}

          {pages.length > 0 ? (
            <SeoCard title={t("s.page_results")} icon={FileText}>
              <div className="grid gap-3">
                {pages.map((p) => {
                  const issues = parsePageIssues(p.issues);
                  return (
                    <div key={p.id} className="rounded-card border border-hairline p-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-medium text-ink" dir="ltr">
                          {p.url}
                        </span>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <Badge kind={p.status === 200 ? "ok" : "critical"}>HTTP {p.status}</Badge>
                          <Badge kind="info">{p.loadMs} ms</Badge>
                          <Badge kind="info">{p.wordCount} w</Badge>
                        </div>
                      </div>
                      <div className="mt-2 grid gap-x-6 gap-y-1 text-xs text-ink-soft sm:grid-cols-2">
                        <span className="truncate">
                          title: <span dir="auto">{p.title || "—"}</span>
                        </span>
                        <span>
                          H1: <span dir="auto">{p.h1 || "—"}</span>
                        </span>
                        <span>
                          {t("s.images")}: {p.images} (alt✗ {p.imagesNoAlt})
                        </span>
                        <span>
                          {t("s.links")}: ↑{p.internalLinks} ↗{p.externalLinks}
                        </span>
                      </div>
                      {issues.length > 0 ? (
                        <ul className="mt-2 flex flex-wrap gap-1.5">
                          {issues.map((i) => (
                            <li key={i.code}>
                              <Badge kind={i.severity}>{i.message}</Badge>
                            </li>
                          ))}
                        </ul>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            </SeoCard>
          ) : null}

          <SeoCard title={t("s.history")} icon={Radar}>
            <ul className="grid max-h-96 gap-2 overflow-y-auto">
              {audits.data.audits.map((a) => (
                <li key={a.id}>
                  <button
                    type="button"
                    onClick={() => setSelected(a.id)}
                    className={`flex w-full cursor-pointer flex-wrap items-center justify-between gap-2 rounded-card border p-3 text-sm transition-colors ${
                      activeId === a.id ? "border-brand bg-brand/5" : "border-hairline hover:bg-surface"
                    }`}
                  >
                    <span className="font-medium">{fmtDate(a.startedAt, lang)}</span>
                    <span className="flex flex-wrap items-center gap-1.5">
                      <Badge kind="info">{a.trigger === "manual" ? t("s.manual_trigger") : t("s.schedule_trigger")}</Badge>
                      {a.status === "done" ? (
                        <>
                          <Badge kind="info">
                            {t("s.score")} {a.score}
                          </Badge>
                          {a.critical > 0 ? <Badge kind="critical">{a.critical}</Badge> : null}
                          {a.warning > 0 ? <Badge kind="warning">{a.warning}</Badge> : null}
                          {a.opportunity > 0 ? <Badge kind="opportunity">{a.opportunity}</Badge> : null}
                        </>
                      ) : a.status === "failed" ? (
                        <Badge kind="critical">{t("s.bad")}</Badge>
                      ) : (
                        <Loader2 className="size-4 animate-spin text-ink-soft" aria-hidden />
                      )}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </SeoCard>
        </>
      )}
    </div>
  );
}
