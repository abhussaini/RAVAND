"use client";

import { create } from "zustand";
import type { SeoLang } from "./seo-strings";

/* Dashboard language — Dari (fa) RTL by default (owner request),
   English one tap away. Persisted separately from the public site
   language so the two never interfere. */
interface SeoLangState {
  lang: SeoLang;
  setLang: (lang: SeoLang) => void;
}

export const useSeoLang = create<SeoLangState>()((set) => ({
  lang: "fa",
  setLang: (lang) => {
    try {
      localStorage.setItem("ravand-seo-lang", lang);
    } catch {
      /* private mode */
    }
    set({ lang });
  },
}));

export function loadSeoLang(): void {
  try {
    const v = localStorage.getItem("ravand-seo-lang");
    if (v === "fa" || v === "en") useSeoLang.setState({ lang: v });
  } catch {
    /* ignore */
  }
}
