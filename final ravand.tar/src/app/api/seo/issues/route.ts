import { NextResponse } from "next/server";
import { db, ensureDb } from "@/lib/db";
import { deny, guard } from "@/lib/seo/guard";
import { toCsv } from "@/lib/seo/reports";

export const dynamic = "force-dynamic";

/* GET /api/seo/issues?status=open|applied|…|all[&format=csv] */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    await ensureDb();
    const url = new URL(req.url);
    const status = url.searchParams.get("status") ?? "all";
    const format = url.searchParams.get("format");

    const issues = await db.seoIssue.findMany({
      where: status === "all" ? undefined : { status },
      orderBy: [{ status: "asc" }, { createdAt: "desc" }],
      take: 300,
    });

    if (format === "csv") {
      const csv = toCsv(
        ["id", "code", "severity", "risk", "status", "pageUrl", "title", "why", "fix", "createdAt"],
        issues.map((i) => [
          i.id,
          i.code,
          i.severity,
          i.risk,
          i.status,
          i.pageUrl,
          i.title,
          i.why,
          i.fix,
          i.createdAt.toISOString(),
        ])
      );
      return new NextResponse(csv, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="ravand-seo-issues-${new Date().toISOString().slice(0, 10)}.csv"`,
        },
      });
    }

    return NextResponse.json({ ok: true, issues });
  } catch (error) {
    console.error("[seo/issues] list failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
