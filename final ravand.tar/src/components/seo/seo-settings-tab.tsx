"use client";

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlarmClock, AlertTriangle, CheckCircle2, ExternalLink, PlugZap, Play, Save, Settings as SettingsIcon, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fmtDate, seoApi, type IntegrationRow, type TaskStatus } from "./seo-api";
import { Badge, EmptyState, Loading, SeoCard, type SeoTabProps } from "./seo-ui";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — Integrations (4) + Settings (10) tabs,
   including the automation schedule controls.
   ------------------------------------------------------------------ */

interface SettingsData {
  settings: {
    baseUrl: string;
    psiKey: boolean;
    cronSecret: boolean;
    adminDefaultPassword: boolean;
  };
}

interface TasksData {
  statuses: TaskStatus[];
  history: { id: string; task: string; status: string; trigger: string; log: string; startedAt: string; finishedAt: string | null }[];
}

export function SettingsTab({
  lang,
  t,
  initialTab,
}: Omit<SeoTabProps, "dir"> & { initialTab: "integrations" | "settings" }) {
  const qc = useQueryClient();
  const [subTab, setSubTab] = useState<"integrations" | "settings">(initialTab);

  const settings = useQuery({
    queryKey: ["seo-settings"],
    queryFn: () => seoApi<SettingsData>("/api/seo/settings"),
    refetchOnMount: "always",
  });

  const integrations = useQuery({
    queryKey: ["seo-integrations"],
    queryFn: () => seoApi<{ ok: true; integrations: IntegrationRow[] }>("/api/seo/integrations"),
    refetchOnMount: "always",
    enabled: subTab === "integrations",
  });

  const tasks = useQuery({
    queryKey: ["seo-tasks"],
    queryFn: () => seoApi<TasksData>("/api/seo/tasks"),
    refetchOnMount: "always",
    enabled: subTab === "settings",
  });

  const savedBaseUrl = settings.data?.settings.baseUrl ?? "";
  const [baseUrlDraft, setBaseUrlDraft] = useState<string | null>(null);
  const baseUrl = baseUrlDraft ?? savedBaseUrl;

  const saveBaseUrl = useMutation({
    mutationFn: () =>
      seoApi<{ ok: true; baseUrl: string }>("/api/seo/settings", {
        method: "PUT",
        body: JSON.stringify({ baseUrl }),
      }),
    onSuccess: () => {
      toast.success(t("s.set_saved"));
      qc.invalidateQueries({ queryKey: ["seo-settings"] });
      qc.invalidateQueries({ queryKey: ["seo-overview"] });
    },
    onError: (e: Error) => {
      if (e.message === "INVALID_URL")
        toast.error(lang === "fa" ? "آدرس نامعتبر است — باید با https:// شروع شود." : "Invalid URL — must start with https://");
      else toast.error(t("s.error"));
    },
  });

  const runTask = useMutation({
    mutationFn: (task: "daily" | "weekly" | "monthly" | "due") =>
      seoApi<{ ok: true }>("/api/seo/tasks", { method: "POST", body: JSON.stringify({ task, lang }) }),
    onSuccess: () => {
      toast.success(lang === "fa" ? "اجرا شد — تاریخچه را ببینید." : "Executed — see run history.");
      qc.invalidateQueries({ queryKey: ["seo-tasks"] });
      qc.invalidateQueries({ queryKey: ["seo-overview"] });
      qc.invalidateQueries({ queryKey: ["seo-issues"] });
    },
    onError: (e: Error) => {
      if (e.message === "RATE_LIMITED")
        toast.error(lang === "fa" ? "کمی بعد تلاش کنید." : "Please retry shortly.");
      else toast.error(t("s.error"));
    },
  });

  const statusBadge = (s: IntegrationRow["status"]) =>
    s === "connected" ? (
      <Badge kind="ok">
        <CheckCircle2 className="size-3" aria-hidden />
        {t("s.int_status_connected")}
      </Badge>
    ) : s === "available" ? (
      <Badge kind="opportunity">{t("s.int_status_available")}</Badge>
    ) : (
      <Badge kind="critical">
        <XCircle className="size-3" aria-hidden />
        {t("s.int_status_not_connected")}
      </Badge>
    );

  return (
    <div className="grid grid-cols-1 gap-4 lg:gap-6">
      <div className="flex gap-1.5">
        {(
          [
            { key: "integrations", label: t("s.tab_integrations"), icon: PlugZap },
            { key: "settings", label: t("s.tab_settings"), icon: SettingsIcon },
          ] as const
        ).map((x) => (
          <button
            key={x.key}
            type="button"
            onClick={() => setSubTab(x.key)}
            className={`inline-flex cursor-pointer items-center gap-1.5 rounded-pill px-3.5 py-2 text-sm font-medium transition-colors ${
              subTab === x.key ? "bg-brand-deep text-white" : "bg-white text-ink-soft hover:bg-surface"
            }`}
          >
            <x.icon className="size-4" aria-hidden />
            {x.label}
          </button>
        ))}
      </div>

      {subTab === "integrations" ? (
        <>
          <p className="text-sm text-ink-soft">{t("s.int_note")}</p>
          {integrations.isLoading ? (
            <Loading label={t("s.loading")} />
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {(integrations.data?.integrations ?? []).map((i) => (
                <article key={i.key} className="rounded-card border border-hairline bg-white p-4 sm:p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h4 className="font-medium text-ink" dir="auto">
                      {i.name}
                    </h4>
                    {statusBadge(i.status)}
                  </div>
                  <p className="mt-2 text-xs text-ink-soft" dir="auto">
                    {i.detail}
                  </p>
                  <details className="mt-3">
                    <summary className="cursor-pointer text-xs font-semibold text-brand">{t("s.int_setup")}</summary>
                    <ol className="mt-2 grid list-inside list-decimal gap-1 text-xs text-ink">
                      {(lang === "fa" ? i.steps.fa : i.steps.en).map((step, idx) => (
                        <li key={idx} dir="auto">
                          {step}
                        </li>
                      ))}
                    </ol>
                    <a
                      href={i.docsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-brand hover:underline"
                    >
                      <ExternalLink className="size-3" aria-hidden />
                      docs
                    </a>
                  </details>
                </article>
              ))}
            </div>
          )}
        </>
      ) : (
        <>
          <SeoCard title={t("s.set_baseurl")} icon={SettingsIcon}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                saveBaseUrl.mutate();
              }}
              className="flex flex-wrap items-end gap-2"
            >
              <div className="grid min-w-0 flex-1 gap-1">
                <Label htmlFor="base-url">{t("s.set_baseurl")}</Label>
                <Input
                  id="base-url"
                  dir="ltr"
                  value={baseUrl}
                  onChange={(e) => setBaseUrlDraft(e.target.value)}
                  placeholder="https://rawandtech.com"
                  inputMode="url"
                />
              </div>
              <Button
                type="submit"
                disabled={saveBaseUrl.isPending}
                className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
              >
                <Save className="size-4" aria-hidden />
                {t("s.set_save")}
              </Button>
            </form>
            <p className="mt-2 text-xs text-ink-soft">{t("s.set_baseurl_d")}</p>
          </SeoCard>

          {settings.data?.settings.adminDefaultPassword ? (
            <div className="flex items-start gap-2.5 rounded-card border border-red-200 bg-red-50 p-4 text-sm text-red-800">
              <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
              <p>{t("s.set_env_admin")}</p>
            </div>
          ) : null}

          <SeoCard title={t("s.set_env")} icon={PlugZap}>
            <ul className="grid gap-2 text-sm">
              {(
                [
                  { label: t("s.set_env_psi"), ok: settings.data?.settings.psiKey },
                  { label: t("s.set_env_cron"), ok: settings.data?.settings.cronSecret },
                ] as const
              ).map((x) => (
                <li key={x.label} className="flex items-center justify-between gap-2 rounded-card border border-hairline p-3">
                  <span className="font-medium text-ink" dir="auto">
                    {x.label}
                  </span>
                  {x.ok ? (
                    <Badge kind="ok">
                      <CheckCircle2 className="size-3" aria-hidden />
                      {t("s.int_status_connected")}
                    </Badge>
                  ) : (
                    <Badge kind="info">{t("s.not_set")}</Badge>
                  )}
                </li>
              ))}
            </ul>
          </SeoCard>

          <SeoCard
            title={t("s.set_schedule")}
            icon={AlarmClock}
            action={
              <Button
                variant="outline"
                onClick={() => runTask.mutate("due")}
                disabled={runTask.isPending}
                className="cursor-pointer rounded-pill"
              >
                <Play className="size-4" aria-hidden />
                {t("s.set_run_due")}
              </Button>
            }
          >
            <p className="text-sm text-ink-soft">{t("s.set_schedule_d")}</p>
            {tasks.isLoading ? (
              <Loading label={t("s.loading")} />
            ) : (
              <ul className="mt-3 grid gap-2 sm:grid-cols-3">
                {(tasks.data?.statuses ?? []).map((s) => (
                  <li key={s.task} className="rounded-card border border-hairline p-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium text-ink">
                        {s.task === "daily" ? t("s.task_daily") : s.task === "weekly" ? t("s.task_weekly") : t("s.task_monthly")}
                      </span>
                      {s.lastStatus ? (
                        <Badge kind={s.lastStatus === "done" ? "ok" : s.lastStatus === "failed" ? "critical" : "warning"}>
                          {s.lastStatus}
                        </Badge>
                      ) : (
                        <Badge kind="info">{t("s.task_never")}</Badge>
                      )}
                    </div>
                    <dl className="mt-2 grid gap-1 text-xs text-ink-soft">
                      <div className="flex justify-between gap-2">
                        <dt>{t("s.task_last")}</dt>
                        <dd>{s.lastDone ? fmtDate(s.lastDone, lang) : t("s.task_never")}</dd>
                      </div>
                      <div className="flex justify-between gap-2">
                        <dt>{t("s.task_next")}</dt>
                        <dd>{s.nextDue ? fmtDate(s.nextDue, lang) : "—"}</dd>
                      </div>
                    </dl>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => runTask.mutate(s.task as "daily" | "weekly" | "monthly")}
                      disabled={runTask.isPending}
                      className="mt-2 w-full cursor-pointer rounded-pill"
                    >
                      <Play className="size-3.5" aria-hidden />
                      {t("s.task_run")}
                    </Button>
                  </li>
                ))}
              </ul>
            )}

            {(tasks.data?.history?.length ?? 0) > 0 ? (
              <details className="mt-3">
                <summary className="cursor-pointer text-xs font-semibold text-brand">{t("s.task_history")}</summary>
                <ul className="mt-2 grid max-h-64 gap-1.5 overflow-y-auto text-xs">
                  {tasks.data?.history.map((h) => (
                    <li key={h.id} className="flex items-center justify-between gap-2 rounded-card border border-hairline p-2">
                      <span className="font-medium text-ink">
                        {h.task} · {fmtDate(h.startedAt, lang)}
                      </span>
                      <Badge kind={h.status === "done" ? "ok" : h.status === "failed" ? "critical" : "warning"}>{h.status}</Badge>
                    </li>
                  ))}
                </ul>
              </details>
            ) : null}
          </SeoCard>

          {!settings.data ? <EmptyState icon={SettingsIcon} text={t("s.loading")} /> : null}
        </>
      )}
    </div>
  );
}
