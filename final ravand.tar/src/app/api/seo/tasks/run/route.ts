import { NextResponse } from "next/server";
import { z } from "zod";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { runDueTasks } from "@/lib/seo/tasks";
import type { TextLang } from "@/lib/seo/audit-texts";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const RunSchema = z.object({
  task: z.string().optional(), // accepted for compatibility; only "due" behaviour exists
  trigger: z.string().optional(),
  lang: z.enum(["fa", "en"]).default("en"),
});

/* POST /api/seo/tasks/run — scheduler entry point.
   Runs every task whose interval has elapsed (daily / weekly / monthly).
   Authorized by admin session OR the x-cron-secret header shared with
   the Netlify Scheduled Function (netlify/functions/seo-scheduler.mjs)
   and n8n workflows. Due-ness is decided by the last SUCCESSFUL run, so
   missed schedules self-heal and duplicate jobs are impossible. */
export async function POST(req: Request) {
  if (!(await guard(req, { allowCron: true }))) return deny();
  const rl = rateLimit(`seo-tasks-run:${clientIp(req)}`, 4, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown = {};
  try {
    body = await req.json();
  } catch {
    /* empty body allowed */
  }
  const parsed = RunSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");
  const lang: TextLang = parsed.data.lang === "fa" ? "fa" : "en";

  try {
    const result = await runDueTasks("schedule", lang);
    return NextResponse.json({ ok: true, ...result });
  } catch (error) {
    console.error("[seo/tasks/run] failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
