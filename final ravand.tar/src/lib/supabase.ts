/* ------------------------------------------------------------------
   Server-side REST client for the project's Supabase instance.

   • Credentials live in .env (never exposed to the browser — this
     module may only be imported from API routes / server code).
   • Every call is fail-safe: on any error (missing table, network
     hiccup, RLS denial) the helpers resolve to null/[] and the
     caller's local-database fallback keeps the site fully working.
   • Optional SUPABASE_SERVICE_KEY bypasses RLS for server writes
     once the project owner adds it to .env.
   ------------------------------------------------------------------ */

const SB_URL = (process.env.SUPABASE_URL || "").replace(/\/+$/, "");
const SB_KEY = process.env.SUPABASE_API_KEY || "";
const SB_SERVICE = process.env.SUPABASE_SERVICE_KEY || "";

export const supabaseEnabled = Boolean(SB_URL && SB_KEY);

const REST = `${SB_URL}/rest/v1`;
const TIMEOUT_MS = 8_000;

/* warn once per (method,table,status) so logs stay readable */
const warned = new Set<string>();
function warnOnce(key: string, detail: string): void {
  if (warned.has(key)) return;
  warned.add(key);
  console.warn(`[supabase] ${key} ${detail}`);
}

async function sb<T>(
  method: "GET" | "POST" | "PATCH" | "DELETE",
  path: string,
  body?: unknown,
  prefer?: string,
  opts?: { silentConflict?: boolean }
): Promise<{ data: T | null; rangeTotal: number | null; ok: boolean; status: number | null }> {
  if (!supabaseEnabled) return { data: null, rangeTotal: null, ok: false, status: null };
  try {
    const res = await fetch(`${REST}/${path}`, {
      method,
      headers: {
        apikey: SB_KEY,
        Authorization: `Bearer ${SB_SERVICE || SB_KEY}`,
        Accept: "application/json",
        ...(body ? { "Content-Type": "application/json" } : {}),
        ...(prefer ? { Prefer: prefer } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      /* an append-only backfill hitting an already-mirrored row is
         expected — don't spam the log for it */
      if (!(opts?.silentConflict && res.status === 409)) {
        warnOnce(`${method} ${path.split("?")[0]}`, `→ ${res.status} ${text.slice(0, 140)}`);
      }
      return { data: null, rangeTotal: null, ok: false, status: res.status };
    }
    const range = res.headers.get("content-range");
    const total = range ? Number(range.split("/")[1]) : null;
    /* 201/204 bulk responses ship an empty body — never parse it */
    if (res.status === 204) return { data: null, rangeTotal: total, ok: true, status: 204 };
    const text = await res.text().catch(() => "");
    let data: T | null = null;
    if (text) {
      try {
        data = JSON.parse(text) as T;
      } catch {
        data = null; // empty/odd body — request itself still succeeded
      }
    }
    return { data, rangeTotal: total, ok: true, status: res.status };
  } catch (error) {
    warnOnce(`${method} ${path.split("?")[0]}`, `failed: ${String(error).slice(0, 140)}`);
    return { data: null, rangeTotal: null, ok: false, status: null };
  }
}

export const sbTable = {
  /** Exact row count (null = unreachable). */
  async count(table: string): Promise<number | null> {
    const { data, rangeTotal } = await sb<unknown[]>(
      "GET",
      `${table}?select=*&limit=1`,
      undefined,
      "count=exact"
    );
    if (rangeTotal !== null && !Number.isNaN(rangeTotal)) return rangeTotal;
    if (data) return data.length;
    return null;
  },

  /** Insert (returns the stored row when allowed).
   *  For append-only tables (ContactMessage / Subscriber) pass
   *  { returning: false, silentConflict: true }: their rows are
   *  intentionally NOT readable by the public key, so PostgREST's
   *  RETURNING clause would violate the (absent) SELECT policy, and
   *  a duplicate id simply means the row was already mirrored. */
  async insert<T extends Record<string, unknown>>(
    table: string,
    row: T,
    opts?: { returning?: boolean; silentConflict?: boolean }
  ): Promise<T | null> {
    const { returning = true, silentConflict = false } = opts ?? {};
    const { data } = await sb<T[]>(
      "POST",
      table,
      row,
      returning ? "return=representation" : undefined,
      { silentConflict }
    );
    return Array.isArray(data) ? (data[0] ?? null) : null;
  },

  /** Lead insert for hosting fallback — plain insert under the
   *  insert-only RLS policies (no RETURNING). Tri-state so the caller
   *  can treat a unique-constraint hit as idempotent success. */
  async insertLead<T extends Record<string, unknown>>(
    table: string,
    row: T
  ): Promise<"stored" | "duplicate" | "failed"> {
    const { ok, status } = await sb<unknown[]>("POST", table, row, undefined, {
      silentConflict: true,
    });
    if (ok) return "stored";
    if (status === 409) return "duplicate"; // unique email/id already present
    return "failed";
  },

  /** Upsert by the primary key column (default "id").
   *  NOTE: never use this for append-only tables (ContactMessage /
   *  Subscriber) — RLS forbids their updates by design; plain insert
   *  is the correct mirror for them. */
  async upsert<T extends Record<string, unknown>>(
    table: string,
    row: T,
    onConflict = "id"
  ): Promise<T | null> {
    const { data } = await sb<T[]>(
      "POST",
      `${table}?on_conflict=${onConflict}`,
      row,
      "resolution=merge-duplicates,return=representation"
    );
    return Array.isArray(data) ? (data[0] ?? null) : null;
  },

  /** Patch a single row by id. */
  async update(
    table: string,
    id: string,
    patch: Record<string, unknown>
  ): Promise<boolean> {
    const { data } = await sb<unknown[]>(
      "PATCH",
      `${table}?id=eq.${encodeURIComponent(id)}`,
      patch,
      "return=representation"
    );
    return Array.isArray(data);
  },

  /** Remove a row by id. */
  async remove(table: string, id: string): Promise<boolean> {
    const { ok } = await sb<unknown[]>(
      "DELETE",
      `${table}?id=eq.${encodeURIComponent(id)}`
    );
    return ok; // 204 with empty body still means success
  },

  /** Bulk upsert (chunked) — used by the initial content sync. */
  async upsertMany<T extends Record<string, unknown>>(
    table: string,
    rows: T[],
    onConflict = "id",
    chunkSize = 200
  ): Promise<boolean> {
    for (let i = 0; i < rows.length; i += chunkSize) {
      const chunk = rows.slice(i, i + chunkSize);
      const { ok } = await sb<T[]>(
        "POST",
        `${table}?on_conflict=${onConflict}`,
        chunk,
        "resolution=merge-duplicates"
      );
      if (!ok) return false;
    }
    return true;
  },
};
