import Lenis from "lenis";

/**
 * Module-singleton Lenis instance driven by one rAF loop.
 * start/stop are used to lock scroll for the loader / menu / modal.
 *
 * Touch devices scroll natively — hijacking wheel/scroll there costs
 * main-thread time and hurts INP, so Lenis is desktop-only.
 */
let lenis: Lenis | null = null;

export function initLenis(): Lenis | null {
  if (lenis) return lenis;
  if (typeof window === "undefined") return null;
  if (window.matchMedia("(hover: none), (pointer: coarse)").matches) return null;
  lenis = new Lenis({ smoothWheel: true });
  function raf(time: number) {
    lenis?.raf(time);
    requestAnimationFrame(raf);
  }
  requestAnimationFrame(raf);
  return lenis;
}

export function stopLenis() {
  lenis?.stop();
}

export function startLenis() {
  lenis?.start();
}

/** Smooth scroll back to the top of the page. */
export function scrollToTop() {
  if (lenis) {
    lenis.scrollTo(0, { duration: 1.2 });
  } else {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
}
