# Ravand Tech — Trilingual Business Website / وب‌سایت سه‌زبانه راوند تک

English (default) · Dari (فارسی دری) · Pashto (پښتو) — full RTL support.

## Quick start (local)

```bash
cp .env.example .env      # then edit values (or keep the dev defaults)
npm install               # or: bun install
npm run dev               # → http://localhost:3000
```

The SQLite database file, schema and seed content are created
**automatically** on the first request — no manual migration step.

| What | Where |
|---|---|
| Website | `http://localhost:3000/#/` |
| Admin panel | `/#/admin` — local password: `ravand2024` (from `.env`) |
| SEO dashboard | `/#/seo` — same password |
| Full hosting guide (Netlify / VPS / Turso / Supabase) | **`DEPLOY.md`** |
| SEO Assistant guide (Dari) | `docs/RAVAND-SEO-ASSISTANT-GUIDE-FA.md` |

## Production checklist (short version)

1. Deploy to Netlify (config is in `netlify.toml`) or any Node host.
2. Set env vars — required: `ADMIN_PASSWORD` (**use a strong value,
   never the local default on a public site**), `TURSO_DATABASE_URL`,
   `TURSO_AUTH_TOKEN`; optional: `SUPABASE_URL`, `SUPABASE_API_KEY`,
   `CRON_SECRET`, `PAGESPEED_API_KEY`.
3. Run `supabase/schema.sql` in the Supabase SQL editor (only if the
   Supabase mirror is wanted).
4. Done — schema + seed content bootstrap automatically.

## Tech stack

Next.js 16 (App Router) · TypeScript · Tailwind CSS 4 · Prisma
(SQLite locally / Turso in production) · Supabase content mirror ·
rule-based multilingual support assistant · PWA manifest ·
self-hosted Persian-friendly fonts.
