"use client";

import Image from "next/image";
import { useRef, useState } from "react";
import { Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export type L10nValue = { fa: string; ps: string; en: string };

const LANG_TABS: Array<{ key: keyof L10nValue; label: string; dir: "rtl" | "ltr" }> = [
  { key: "fa", label: "دری", dir: "rtl" },
  { key: "ps", label: "پښتو", dir: "rtl" },
  { key: "en", label: "English", dir: "ltr" },
];

const INPUT_CLS =
  "w-full rounded-xl border border-hairline bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-soft/60 focus:border-brand-light focus:outline-none focus:ring-2 focus:ring-brand-light/40";

/**
 * Trilingual field — three tabs (fa / ps / en), each input rendered
 * in its own direction so text is written and read correctly.
 */
export function L10nField({
  label,
  value,
  onChange,
  multiline = false,
  rows = 3,
  placeholder,
}: {
  label: string;
  value: L10nValue;
  onChange: (v: L10nValue) => void;
  multiline?: boolean;
  rows?: number;
  placeholder?: string;
}) {
  const [tab, setTab] = useState<keyof L10nValue>("fa");
  const active = LANG_TABS.find((l) => l.key === tab)!;

  return (
    <div>
      <span className="display-caps mb-2 block text-[0.7rem] font-medium uppercase tracking-[0.16em] text-ink-soft">
        {label}
      </span>
      <div className="flex gap-1.5 pb-2">
        {LANG_TABS.map((l) => (
          <button
            key={l.key}
            type="button"
            onClick={() => setTab(l.key)}
            aria-pressed={tab === l.key}
            className={cn(
              "cursor-pointer rounded-pill px-3 py-1.5 text-xs font-medium transition-colors",
              tab === l.key
                ? "bg-brand text-white"
                : "bg-surface text-ink-soft hover:bg-hairline"
            )}
          >
            {l.label}
          </button>
        ))}
      </div>
      {multiline ? (
        <textarea
          dir={active.dir}
          lang={tab === "fa" ? "fa-AF" : tab === "ps" ? "ps" : "en"}
          rows={rows}
          value={value[tab]}
          onChange={(e) => onChange({ ...value, [tab]: e.target.value })}
          placeholder={placeholder?.[tab]}
          className={cn(INPUT_CLS, "resize-y leading-relaxed")}
        />
      ) : (
        <input
          dir={active.dir}
          lang={tab === "fa" ? "fa-AF" : tab === "ps" ? "ps" : "en"}
          value={value[tab]}
          onChange={(e) => onChange({ ...value, [tab]: e.target.value })}
          placeholder={placeholder?.[tab]}
          className={INPUT_CLS}
        />
      )}
    </div>
  );
}

/** Sticker choices available in the picker */
export const STICKER_CHOICES = [
  "/stickers/st-services.svg",
  "/stickers/st-portfolio.svg",
  "/stickers/st-blog.svg",
  "/stickers/st-testimonials.svg",
  "/stickers/st-stats.svg",
  "/stickers/st-why.svg",
  "/stickers/st-contact.svg",
  "/stickers/hamsafar.svg",
  "/stickers/omo.svg",
  "/stickers/agentic-platform.svg",
  "/stickers/ai-workspace.svg",
  "/stickers/business-integration.svg",
  "/stickers/mobile-app.svg",
  "/stickers/blog-web.svg",
  "/stickers/blog-ai.svg",
  "/stickers/blog-seo.svg",
];

/**
 * Media picker — select from the built-in library or upload a new
 * image (admin-only /api/admin/upload endpoint, 4 MB limit, raster
 * formats only — SVG uploads are rejected server-side for XSS safety).
 * Used for stickers, project covers and the site logo.
 */
export function MediaPicker({
  label,
  value,
  onChange,
  choices = STICKER_CHOICES,
  showLibrary = true,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  choices?: string[];
  showLibrary?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const upload = async (file: File) => {
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
      const json = await res.json();
      if (!res.ok || !json?.ok) {
        toast.error(
          json?.error === "TOO_LARGE"
            ? "Max 4 MB"
            : json?.error === "UNSUPPORTED_TYPE"
              ? "PNG / JPG / WebP / GIF / SVG only"
              : "Upload failed"
        );
        return;
      }
      onChange(json.url as string);
      toast.success("Uploaded");
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <span className="display-caps mb-2 block text-[0.7rem] font-medium uppercase tracking-[0.16em] text-ink-soft">
        {label}
      </span>
      <div className="flex items-center gap-3 rounded-xl border border-hairline bg-surface p-2">
        <span className="grid size-14 shrink-0 place-items-center overflow-hidden rounded-lg bg-white">
          <Image
            src={value || choices[0]}
            alt=""
            width={56}
            height={56}
            className="size-14 object-contain"
          />
        </span>
        <p dir="ltr" className="min-w-0 flex-1 truncate text-xs text-ink-soft">
          {value}
        </p>
        <input
          ref={inputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void upload(f);
            e.target.value = "";
          }}
        />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="inline-flex shrink-0 cursor-pointer items-center gap-1.5 rounded-pill bg-brand px-3.5 py-2 text-xs font-medium text-white transition-colors hover:bg-brand-deep disabled:opacity-60"
        >
          {uploading ? (
            <Loader2 className="size-3.5 animate-spin" aria-hidden />
          ) : (
            <Upload className="size-3.5" aria-hidden />
          )}
          Upload
        </button>
      </div>
      {showLibrary && (
        <div className="mt-2 grid max-h-44 grid-cols-6 gap-2 overflow-y-auto rounded-xl border border-hairline bg-surface p-2 sm:grid-cols-8">
          {choices.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => onChange(s)}
              aria-pressed={value === s}
              title={s.split("/").pop()}
              className={cn(
                "cursor-pointer rounded-lg bg-white p-1.5 transition-all",
                value === s
                  ? "ring-2 ring-brand ring-offset-1"
                  : "opacity-70 hover:opacity-100"
              )}
            >
              <Image src={s} alt="" width={40} height={40} className="size-9 object-contain" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/** Visual sticker picker — library + upload. */
export function StickerPicker({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return <MediaPicker label={label} value={value} onChange={onChange} />;
}

/** Simple labeled text/number input */
export function TextField({
  label,
  value,
  onChange,
  type = "text",
  dir,
  placeholder,
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  type?: "text" | "number" | "email";
  dir?: "ltr" | "rtl";
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="display-caps mb-2 block text-[0.7rem] font-medium uppercase tracking-[0.16em] text-ink-soft">
        {label}
      </span>
      <input
        type={type}
        dir={dir}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={INPUT_CLS}
      />
    </label>
  );
}
