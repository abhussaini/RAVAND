/* ------------------------------------------------------------------
   Ravand SEO Assistant — integration registry.

   HONESTY POLICY: a service is only reported "connected" when its
   configuration is actually present in this environment. Services
   that need the owner's own account (Search Console, Bing, n8n…)
   show step-by-step setup instructions instead of a fake status.
   ------------------------------------------------------------------ */

import { aiStatus } from "@/lib/seo/ai";

export interface IntegrationInfo {
  key: string;
  name: string;
  status: "connected" | "available" | "not_connected";
  detail: string;
  docsUrl: string;
  steps: { fa: string[]; en: string[] };
}

export async function integrationStatuses(): Promise<IntegrationInfo[]> {
  const ai = await aiStatus();
  return [
    {
      key: "ai",
      name: "z.ai — AI suggestions (assistant brain)",
      status: ai.connected ? "connected" : "not_connected",
      detail: ai.connected
        ? `Active provider: ${ai.provider}${ai.detail ? ` — ${ai.detail}` : ""}`
        : "No AI provider in this environment — suggestions fall back to deterministic rules",
      docsUrl: "https://z.ai",
      steps: {
        fa: [
          "زیرساخت توسعه z.ai به‌صورت پیش‌فرض فعال است؛ پیشنهادهای کلمات کلیدی و بهینه‌ساز محتوا با هوش مصنوعی ساخته می‌شوند.",
          "برای هاست اختصاصی، یک سرویس OpenAI-compatible (مثلاً AI_API_KEY + AI_BASE_URL) تنظیم کنید.",
        ],
        en: [
          "The z.ai development SDK is active by default; keyword ideas and the content optimizer are AI-generated.",
          "For self-hosted production, set an OpenAI-compatible provider (AI_API_KEY + AI_BASE_URL).",
        ],
      },
    },
    {
      key: "pagespeed",
      name: "Google PageSpeed Insights API",
      status: process.env.PAGESPEED_API_KEY ? "connected" : "available",
      detail: process.env.PAGESPEED_API_KEY
        ? "PAGESPEED_API_KEY configured"
        : "Works without a key at low volume; add PAGESPEED_API_KEY for reliable quotas",
      docsUrl: "https://developers.google.com/speed/docs/insights/v5/get-started",
      steps: {
        fa: [
          "در Google Cloud Console یک API Key بسازید و سرویس PageSpeed Insights API را فعال کنید.",
          "متغیر PAGESPEED_API_KEY را در Netlify ثبت کنید.",
        ],
        en: [
          "Create an API key in Google Cloud Console and enable the PageSpeed Insights API.",
          "Set the PAGESPEED_API_KEY environment variable in Netlify.",
        ],
      },
    },
    {
      key: "gsc",
      name: "Google Search Console",
      status: "not_connected",
      detail: "Manual verification required — no OAuth account connection is stored by this site",
      docsUrl: "https://search.google.com/search-console/",
      steps: {
        fa: [
          "در Search Console پراپرتی دامنه (rawandtech.com) را اضافه کنید.",
          "مالکیت را با رکورد DNS یا فایل HTML تأیید کنید.",
          "در بخش Sitemaps آدرس https://دامنه‌شما/sitemap.xml را ثبت کنید.",
          "داده‌های کلیک و نمایش را از خود Search Console بخوانید؛ اتصال API فقط با OAuth ممکن است و بعداً قابل افزودن است.",
        ],
        en: [
          "Add your domain property (rawandtech.com) in Search Console.",
          "Verify ownership via DNS record or HTML file.",
          "Submit https://your-domain/sitemap.xml under Sitemaps.",
          "Read clicks/impressions directly in Search Console; API access needs OAuth and can be added later.",
        ],
      },
    },
    {
      key: "bing",
      name: "Bing Webmaster Tools",
      status: "not_connected",
      detail: "Manual setup required",
      docsUrl: "https://www.bing.com/webmasters/",
      steps: {
        fa: [
          "در Bing Webmaster Tools با ایمیل ثبت‌نام کنید.",
          "سایت را از Search Console ایمپورت کنید یا مالکیت را تأیید کنید.",
          "نقشه سایت را ثبت کنید.",
        ],
        en: [
          "Sign up at Bing Webmaster Tools.",
          "Import the site from Search Console or verify ownership manually.",
          "Submit your sitemap.",
        ],
      },
    },
    {
      key: "netlify",
      name: "Netlify (hosting & scheduled functions)",
      status: process.env.NETLIFY === "true" ? "connected" : "not_connected",
      detail:
        process.env.NETLIFY === "true"
          ? "Site runs on Netlify — scheduled automation active after deploy"
          : "Deploy the project to Netlify to enable scheduled automation",
      docsUrl: "https://docs.netlify.com/functions/scheduled-functions/",
      steps: {
        fa: [
          "پروژه را به Netlify وصل کنید (GitHub یا CLI).",
          "متغیرهای محیطی را در پنل Netlify ثبت کنید.",
          "تابع زمان‌بندی‌شده seo-scheduler پس از دیپلوی هر روز اجرا می‌شود.",
        ],
        en: [
          "Connect the repository (GitHub or CLI) to Netlify.",
          "Set the environment variables in the Netlify panel.",
          "The seo-scheduler scheduled function runs daily after deployment.",
        ],
      },
    },
    {
      key: "github",
      name: "GitHub (version control & rollback)",
      status: process.env.GITHUB_ACTIONS === "true" ? "connected" : "not_connected",
      detail: "Push the repository to GitHub and connect it to Netlify for git-based rollbacks",
      docsUrl: "https://docs.netlify.com/git/overview/",
      steps: {
        fa: [
          "یک مخزن GitHub بسازید و کد را push کنید.",
          "در Netlify گزینه Import from Git را انتخاب کنید.",
          "هر تغییر = یک commit؛ بازگشت (rollback) با دیپلوی نسخه قبلی انجام می‌شود.",
        ],
        en: [
          "Create a GitHub repository and push the code.",
          "Choose Import from Git in Netlify.",
          "Every change is a commit; rollback = redeploy a previous version.",
        ],
      },
    },
    {
      key: "n8n",
      name: "n8n Community Edition (advanced automation)",
      status: "not_connected",
      detail: "Optional — the built-in scheduler already covers daily/weekly/monthly tasks",
      docsUrl: "https://docs.n8n.io/",
      steps: {
        fa: [
          "n8n را روی یک سرور رایگان/ارزان خودتان اجرا کنید.",
          "یک Workflow با Schedule Trigger بسازید که هر روز به آدرس /api/seo/tasks/run با هدر x-cron-secret درخواست بزند.",
          "مقدار CRON_SECRET را در هر دو جا یکسان تنظیم کنید.",
        ],
        en: [
          "Run n8n Community Edition on your own free/cheap server.",
          "Create a Schedule Trigger workflow calling /api/seo/tasks/run with the x-cron-secret header.",
          "Set the same CRON_SECRET value in both places.",
        ],
      },
    },
    {
      key: "screamingfrog",
      name: "Screaming Frog SEO Spider (deep desktop crawls)",
      status: "not_connected",
      detail: "Complementary desktop tool for very deep crawls (free up to 500 URLs)",
      docsUrl: "https://www.screamingfrog.co.uk/seo-spider/",
      steps: {
        fa: [
          "نسخه رایگان Screaming Frog را روی کامپیوتر نصب کنید.",
          "آدرس سایت را crawl کنید و نتایج را با یافته‌های همین پنل مقایسه کنید.",
        ],
        en: [
          "Install the free Screaming Frog version on your computer.",
          "Crawl your URL and compare results with this dashboard.",
        ],
      },
    },
  ];
}
