"use client";

import Image from "next/image";
import { ArrowUpRight, Clock } from "lucide-react";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { navigate } from "@/lib/router";
import { Reveal, StackedLines } from "./reveal";
import { BlockSticker } from "./sticker";
import { Eyebrow } from "./ui-v2";

const FALLBACK = [
  { slug: "web-design-trends-2025", img: "/stickers/blog-web.svg", title: "b1_title", cat: "b1_cat", desc: "b1_d", date: "b1_date", read: 6, alt: "Web design trends 2025 — browser window illustration" },
  { slug: "ai-automation-small-business", img: "/stickers/blog-ai.svg", title: "b2_title", cat: "b2_cat", desc: "b2_d", date: "b2_date", read: 8, alt: "AI automation for small businesses — chip illustration" },
  { slug: "seo-afghan-market", img: "/stickers/blog-seo.svg", title: "b3_title", cat: "b3_cat", desc: "b3_d", date: "b3_date", read: 7, alt: "SEO for the Afghan market — rising chart illustration" },
] as const;

/**
 * Modern blog section — editorial cards with sticker covers, image
 * zoom, category chip, meta row and sliding arrow. Cards open the
 * dedicated post page (#/blog/:slug). DB-driven with fallback.
 *
 * `eager` — how many leading card images get next/image priority;
 * set on the blog index page where the first cards are the LCP.
 * The home page keeps the default (lazy) because the section sits
 * far below the fold there.
 */
export function BlogSection({
  showHeader = true,
  eager = 0,
}: {
  showHeader?: boolean;
  eager?: number;
}) {
  const { t } = useT();
  const { content, pick } = useContent();

  const posts = content?.posts?.length
    ? content.posts.map((p) => ({
        slug: p.slug,
        img: p.sticker,
        title: pick(p.title),
        cat: pick(p.cat),
        desc: pick(p.excerpt),
        date: pick(p.dateLabel),
        read: p.readMin,
        alt: pick(p.title),
      }))
    : FALLBACK.map((p) => ({
        slug: p.slug,
        img: p.img,
        title: t(p.title),
        cat: t(p.cat),
        desc: t(p.desc),
        date: t(p.date),
        read: p.read,
        alt: p.alt,
      }));

  return (
    <section
      id="blog"
      className={showHeader ? "bg-surface px-6 py-20 sm:px-10 sm:py-24" : "bg-surface px-6 pb-20 pt-3 sm:px-10 sm:pb-24"}
    >
      {/* header — text + sticker */}
      {showHeader && (
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between md:gap-10">
        <div className="max-w-2xl">
          <Eyebrow>{t("blog.eyebrow")}</Eyebrow>
          <h2 className="font-display t-section mt-4 font-medium">
            <StackedLines lines={[t("v2.blog.one")]} stagger={120} />
          </h2>
          <Reveal from={{ opacity: 0, y: 14 }} delayIn={0.2}>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-ink-soft sm:text-[0.95rem]">
              {t("blog.desc")}
            </p>
          </Reveal>
        </div>
        <BlockSticker src="/stickers/st-blog.svg" alt="" tone="light" delay={0.15} />
      </div>
      )}

      {/* cards */}
      <ul className={showHeader ? "mt-12 grid gap-4 sm:gap-5 md:grid-cols-3" : "grid gap-4 sm:gap-5 md:grid-cols-3"}>
        {posts.map((p, i) => (
          <li key={p.slug}>
            <Reveal
              from={{ opacity: 0, y: 36 }}
              delayIn={i * 0.1}

              className="h-full"
            >
              <article
                onClick={() => navigate(`/blog/${p.slug}`)}
                className="group flex h-full cursor-pointer flex-col overflow-hidden rounded-card border border-hairline bg-white transition-[box-shadow,transform] duration-300 hover:shadow-[0_30px_60px_-30px_rgba(15,47,99,0.35)] hover:-translate-y-1.5"
              >
                {/* sticker cover — 1KB vector, no raster */}
                <span className="relative block aspect-[16/10] overflow-hidden">
                  <span
                    className="absolute inset-0 block transition-transform duration-500 group-hover:scale-[1.06]"
                  >
                    <Image
                      src={p.img}
                      alt={p.alt}
                      fill
                      sizes="(max-width: 768px) 100vw, 33vw"
                      className="object-cover"
                      priority={i < eager}
                    />
                  </span>
                  <span className="glass-caption absolute start-3 top-3 rounded-pill px-3 py-1 text-[0.65rem] font-medium text-white">
                    <span className="display-caps block uppercase tracking-wide">{p.cat}</span>
                  </span>
                </span>

                {/* body */}
                <span className="flex flex-1 flex-col p-5 sm:p-6">
                  <span className="flex items-center gap-2.5 text-[0.7rem] text-ink-soft">
                    <span>{p.date}</span>
                    <span aria-hidden className="size-1 rounded-pill bg-ghost" />
                    <span className="inline-flex items-center gap-1">
                      <Clock aria-hidden className="size-3" />
                      {p.read} {t("blog.min")}
                    </span>
                  </span>

                  <h3 className="font-display mt-3 text-base font-medium leading-snug tracking-tight transition-colors duration-300 group-hover:text-brand sm:text-lg">
                    {p.title}
                  </h3>
                  <span className="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-ink-soft">
                    {p.desc}
                  </span>

                  <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-brand">
                    {t("blog.read")}
                    <span
                      aria-hidden
                      className="inline-flex transition-transform duration-300 group-hover:translate-x-1"
                    >
                      <ArrowUpRight className="size-4 rtl:-scale-x-100" />
                    </span>
                  </span>
                </span>
              </article>
            </Reveal>
          </li>
        ))}
      </ul>
    </section>
  );
}
