/* ------------------------------------------------------------------
   Shared contact-form validation.

   • Client-side pre-validation mirrors the server's zod schema so
     obvious mistakes never leave the browser and every field shows
     a clear, translated error message.
   • Server 4xx responses are parsed into the same shape, so a
     submission that fails remotely highlights exactly which fields
     need fixing (instead of the old generic "please try again").
   ------------------------------------------------------------------ */

export const SERVICE_VALUES = ["web", "software", "uiux", "shop", "seo", "support"] as const;
export type ServiceValue = (typeof SERVICE_VALUES)[number];

export interface ContactValues {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
}

export type ContactField = "name" | "email" | "phone" | "message";
export type ContactFieldErrors = Partial<Record<ContactField, string>>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Same rules as the API's zod schema, keyed by i18n message. */
export function validateContact(
  values: ContactValues,
  t: (key: string) => string
): ContactFieldErrors {
  const errors: ContactFieldErrors = {};
  if (values.name.trim().length < 2) errors.name = t("contact.err_name");
  if (!EMAIL_RE.test(values.email.trim())) errors.email = t("contact.err_email");
  if (values.phone.trim().length > 40) errors.phone = t("contact.err_phone");
  if (values.message.trim().length < 5) errors.message = t("contact.err_message");
  return errors;
}

interface ContactErrorBody {
  error?: string;
  issues?: Record<string, string[] | undefined>;
  retryAfter?: number;
}

/** Turn a non-2xx /api/contact response into field + banner messages. */
export function parseContactFailure(
  status: number,
  body: ContactErrorBody | null,
  t: (key: string) => string
): { fieldErrors: ContactFieldErrors; topMessage: string } {
  if (status === 400 && body?.error === "VALIDATION") {
    const issues = body.issues ?? {};
    const fieldErrors: ContactFieldErrors = {};
    if (issues.name?.length) fieldErrors.name = t("contact.err_name");
    if (issues.email?.length) fieldErrors.email = t("contact.err_email");
    if (issues.phone?.length) fieldErrors.phone = t("contact.err_phone");
    if (issues.message?.length) fieldErrors.message = t("contact.err_message");
    return { fieldErrors, topMessage: t("contact.err_fix") };
  }
  if (status === 429) {
    return { fieldErrors: {}, topMessage: t("contact.err_rate") };
  }
  return { fieldErrors: {}, topMessage: t("contact.err_d") };
}
