import { NextResponse } from "next/server";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { fetchPageSpeed } from "@/lib/seo/pagespeed";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/* GET /api/seo/pagespeed?strategy=mobile|desktop
   Real Google PSI results (cached 6h). No key → keyless attempt with
   honest failure reporting. Scores are never invented. */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-psi:${clientIp(req)}`, 5, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  const strategy = new URL(req.url).searchParams.get("strategy") === "desktop" ? "desktop" : "mobile";
  try {
    const result = await fetchPageSpeed(strategy);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    console.error("[seo/pagespeed] failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
