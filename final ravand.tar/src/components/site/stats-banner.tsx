"use client";

import { useEffect, useState } from "react";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { Reveal, StackedLines, useInViewOnce } from "./reveal";
import { BlockSticker } from "./sticker";
import { Eyebrow } from "./ui-v2";

const FALLBACK = [
  { id: "s1", value: 40, suffix: "+", label: "stats.projects", sub: "stats.projects_s" },
  { id: "s2", value: 25, suffix: "+", label: "stats.clients", sub: "stats.clients_s" },
  { id: "s3", value: 24, suffix: "h", label: "stats.response", sub: "stats.response_s" },
  { id: "s4", value: 3, suffix: "", label: "stats.langs", sub: "stats.langs_s" },
] as const;

/* Count-up number that fires when scrolled into view — plain rAF,
   expo-out easing matches the original spring feel */
function CountUp({ to, suffix }: { to: number; suffix: string }) {
  const [ref, inView] = useInViewOnce<HTMLSpanElement>(0.4);
  const [v, setV] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const t0 = performance.now();
    const DURATION = 1800;
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / DURATION);
      const eased = p >= 1 ? 1 : 1 - Math.pow(2, -10 * p);
      setV(Math.round(to * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);

  return (
    <span ref={ref} dir="ltr" className="inline-flex items-baseline">
      {v}
      <span className="text-brand-light">{suffix}</span>
    </span>
  );
}

/** Navy "by the numbers" band with count-up animation — DB-driven. */
export function StatsBanner() {
  const { t } = useT();
  const { content, pick } = useContent();

  const stats = content?.stats?.length
    ? content.stats.map((s) => ({
        id: s.id,
        value: s.value,
        suffix: s.suffix,
        label: pick(s.label),
        sub: pick(s.sub),
      }))
    : FALLBACK.map((s) => ({ ...s, label: t(s.label), sub: t(s.sub) }));

  return (
    <section
      aria-label={t("v2.stats.eyebrow")}
      className="mt-3 rounded-card-lg bg-brand-deep px-6 py-20 text-white sm:px-10 sm:py-24"
    >
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between md:gap-10">
        <div className="max-w-xl">
          <Eyebrow tone="light">{t("v2.stats.eyebrow")}</Eyebrow>
          <h2 className="font-display t-section mt-4 font-medium">
            <StackedLines lines={[t("v2.stats.one")]} stagger={120} />
          </h2>
        </div>
        <BlockSticker src="/stickers/st-stats.svg" alt="" tone="dark" delay={0.15} />
      </div>

      {/* Plain div grid — the label & sub are visible text, so no
          dl/dt/dd semantics are needed (they broke axe/Lighthouse). */}
      <div className="mt-14 grid grid-cols-2 gap-x-8 gap-y-10 lg:grid-cols-4">
        {stats.map((s, i) => (
          <Reveal
            key={s.id}
            from={{ opacity: 0, y: 30 }}
            delayIn={i * 0.11}

          >
            <div className="group border-t border-white/20 pt-5 transition-colors duration-300 hover:border-brand-light/70">
              <span className="font-display block text-5xl font-medium leading-none tracking-tight transition-transform duration-300 group-hover:-translate-y-1 sm:text-6xl">
                <CountUp to={s.value} suffix={s.suffix} />
              </span>
              <span className="mt-3 block text-sm font-medium text-white/85">{s.label}</span>
              <span className="mt-1 block text-[0.8rem] text-white/55">{s.sub}</span>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
