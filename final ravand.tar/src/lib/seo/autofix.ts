import { db, ensureDb } from "@/lib/db";
import { parseL10n } from "@/app/api/content/route";
import { cleanText } from "./assistant";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — safe auto-fix system.

   Risk policy (enforced here, not just in the UI):
     LOW    → applies with a single confirmation (admin-only anyway)
     MEDIUM → UI asks for explicit approval showing old → new
     HIGH   → applyFix() refuses — codes are never automated
   Every change records old/new values + reason in SeoChange and can
   be rolled back while the target still exists.
   ------------------------------------------------------------------ */

export type ApplyOk = { ok: true; changeId: string; oldValue: string; newValue: string };
export type ApplyErr = { ok: false; error: string };
export type ApplyResult = ApplyOk | ApplyErr;

const OVERRIDE_FIELDS = new Set(["title", "description", "ogTitle", "ogDescription"]);
const OVERRIDE_LIMITS: Record<string, number> = {
  title: 120,
  description: 320,
  ogTitle: 120,
  ogDescription: 320,
};
const RESOURCE_MODELS = new Set(["post", "service"]);
const RESOURCE_FIELDS = new Set(["title", "desc", "excerpt", "cat", "body"]);
const LANGS = new Set(["fa", "ps", "en"]);

type LoadedPayload =
  | { ok: false; error: string }
  | { ok: true; issue: NonNullable<Awaited<ReturnType<typeof db.seoIssue.findUnique>>>; payload: Record<string, unknown> };

async function loadPayload(issueId: string): Promise<LoadedPayload> {
  const issue = await db.seoIssue.findUnique({ where: { id: issueId } });
  if (!issue) return { ok: false, error: "ISSUE_NOT_FOUND" };
  if (issue.risk === "high") return { ok: false, error: "HIGH_RISK_NEVER_AUTOMATED" };
  if (issue.status === "applied") return { ok: false, error: "ALREADY_APPLIED" };
  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(issue.fixPayload || "{}") as Record<string, unknown>;
  } catch {
    return { ok: false, error: "BAD_PAYLOAD" };
  }
  return { ok: true, issue, payload };
}

/** Apply one approved auto-fix. */
export async function applyFix(issueId: string, reason: string): Promise<ApplyResult> {
  await ensureDb();
  const loaded = await loadPayload(issueId);
  if (!loaded.ok) return { ok: false, error: loaded.error };
  const { issue, payload } = loaded;
  const type = typeof payload.type === "string" ? payload.type : "";

  /* ---- metadata override (site <head>) ---- */
  if (type === "override") {
    const field = cleanText(payload.field, 40);
    const value = cleanText(payload.value, OVERRIDE_LIMITS[field] ?? 300);
    const route = cleanText(payload.path ?? "/", 200) || "/";
    if (!OVERRIDE_FIELDS.has(field) || !value) return { ok: false, error: "BAD_PAYLOAD" };

    const existing = await db.seoOverride.findUnique({
      where: { path_field: { path: route, field } },
    });
    const oldValue = existing?.value ?? "";

    await db.seoOverride.upsert({
      where: { path_field: { path: route, field } },
      update: { value, active: true },
      create: { path: route, field, value },
    });
    const change = await db.seoChange.create({
      data: {
        issueId,
        targetType: "override",
        targetRef: `${route}#${field}`,
        oldValue,
        newValue: value,
        reason: cleanText(reason, 300) || `auto-fix ${issue.code}`,
      },
    });
    await db.seoIssue.update({ where: { id: issueId }, data: { status: "applied" } });
    return { ok: true, changeId: change.id, oldValue, newValue: value };
  }

  /* ---- resource field (post/service L10n content) ---- */
  if (type === "resource") {
    const model = cleanText(payload.model, 20);
    const id = cleanText(payload.id, 60);
    const field = cleanText(payload.field, 20);
    const lang = cleanText(payload.lang, 5);
    const value = cleanText(payload.value, field === "body" ? 20_000 : 2_000);
    if (!RESOURCE_MODELS.has(model) || !RESOURCE_FIELDS.has(field)) return { ok: false, error: "BAD_PAYLOAD" };
    if (!LANGS.has(lang) || !value || !id) return { ok: false, error: "BAD_PAYLOAD" };

    const row =
      model === "post"
        ? await db.post.findUnique({ where: { id } })
        : await db.service.findUnique({ where: { id } });
    if (!row) return { ok: false, error: "TARGET_NOT_FOUND" };

    const raw = (row as Record<string, unknown>)[field];
    const l10n = parseL10n(typeof raw === "string" ? raw : undefined);
    const oldValue = l10n[lang as "fa" | "ps" | "en"] ?? "";
    l10n[lang as "fa" | "ps" | "en"] = value;

    if (model === "post") {
      await db.post.update({ where: { id }, data: { [field]: JSON.stringify(l10n) } });
    } else {
      await db.service.update({ where: { id }, data: { [field]: JSON.stringify(l10n) } });
    }
    const change = await db.seoChange.create({
      data: {
        issueId,
        targetType: model,
        targetRef: `${model}:${id}:${field}:${lang}`,
        oldValue,
        newValue: value,
        reason: cleanText(reason, 300) || `auto-fix ${issue.code}`,
      },
    });
    await db.seoIssue.update({ where: { id: issueId }, data: { status: "applied" } });
    return { ok: true, changeId: change.id, oldValue, newValue: value };
  }

  return { ok: false, error: "NOT_AUTOMATABLE" };
}

/** Roll a previously applied change back to its old value. */
export async function rollbackChange(changeId: string): Promise<ApplyResult> {
  await ensureDb();
  const change = await db.seoChange.findUnique({ where: { id: changeId } });
  if (!change) return { ok: false, error: "CHANGE_NOT_FOUND" };
  if (change.status !== "applied") return { ok: false, error: "NOT_APPLIED" };

  if (change.targetType === "override") {
    const [route, field] = change.targetRef.split("#");
    if (!route || !field) return { ok: false, error: "BAD_REF" };
    if (change.oldValue) {
      await db.seoOverride.update({
        where: { path_field: { path: route, field } },
        data: { value: change.oldValue },
      });
    } else {
      await db.seoOverride.delete({ where: { path_field: { path: route, field } } }).catch(() => undefined);
    }
  } else if (change.targetType === "post" || change.targetType === "service") {
    const [, id, field, lang] = change.targetRef.split(":");
    if (!id || !field || !lang) return { ok: false, error: "BAD_REF" };
    const row =
      change.targetType === "post"
        ? await db.post.findUnique({ where: { id } })
        : await db.service.findUnique({ where: { id } });
    if (!row) return { ok: false, error: "TARGET_NOT_FOUND" };
    const raw = (row as Record<string, unknown>)[field];
    const l10n = parseL10n(typeof raw === "string" ? raw : undefined);
    l10n[lang as "fa" | "ps" | "en"] = change.oldValue;
    if (change.targetType === "post") {
      await db.post.update({ where: { id }, data: { [field]: JSON.stringify(l10n) } });
    } else {
      await db.service.update({ where: { id }, data: { [field]: JSON.stringify(l10n) } });
    }
  } else {
    return { ok: false, error: "NOT_AUTOMATABLE" };
  }

  await db.seoChange.update({ where: { id: changeId }, data: { status: "rolled_back" } });
  if (change.issueId) {
    await db.seoIssue
      .update({ where: { id: change.issueId }, data: { status: "open" } })
      .catch(() => undefined);
  }
  return {
    ok: true,
    changeId,
    oldValue: change.newValue,
    newValue: change.oldValue,
  };
}
