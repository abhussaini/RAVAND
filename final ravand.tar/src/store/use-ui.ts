"use client";

import { create } from "zustand";

interface UiState {
  /** loader finished — gates hero entrance reveals */
  ready: boolean;
  setReady: (v: boolean) => void;
  menuOpen: boolean;
  setMenuOpen: (v: boolean) => void;
  contactOpen: boolean;
  contactPreset: string;
  openContact: (preset?: string) => void;
  closeContact: () => void;
}

export const useUi = create<UiState>()((set) => ({
  ready: false,
  setReady: (v) => set({ ready: v }),
  menuOpen: false,
  setMenuOpen: (v) => set({ menuOpen: v }),
  contactOpen: false,
  contactPreset: "",
  openContact: (preset = "") =>
    set({ contactOpen: true, contactPreset: preset, menuOpen: false }),
  closeContact: () => set({ contactOpen: false }),
}));
