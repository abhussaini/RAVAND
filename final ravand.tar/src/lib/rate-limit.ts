/* ------------------------------------------------------------------
   Per-IP in-memory rate limiter (spam & brute-force protection).

   Serverless note: each Netlify/Lambda instance keeps its own map, so
   limits are approximate there — still effective against bursts and
   abusive loops. For strict global limits, swap the store for Upstash
   or Turso later; the call sites stay identical.
   ------------------------------------------------------------------ */

type Bucket = { hits: number[]; };

const STORE = new Map<string, Bucket>();

export function rateLimit(
  key: string,
  limit: number,
  windowMs: number
): { ok: boolean; retryAfter: number } {
  const now = Date.now();
  const bucket = STORE.get(key) ?? { hits: [] };
  bucket.hits = bucket.hits.filter((t) => now - t < windowMs);

  if (bucket.hits.length >= limit) {
    STORE.set(key, bucket);
    const oldest = bucket.hits[0] ?? now;
    return { ok: false, retryAfter: Math.ceil((windowMs - (now - oldest)) / 1000) };
  }

  bucket.hits.push(now);
  STORE.set(key, bucket);

  /* keep memory bounded on long-lived servers */
  if (STORE.size > 2000) {
    for (const [k, b] of STORE) {
      if (!b.hits.some((t) => now - t < windowMs)) STORE.delete(k);
    }
  }
  return { ok: true, retryAfter: 0 };
}

/** Best-effort client IP from proxy headers. */
export function clientIp(req: Request): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip")?.trim() ||
    "local"
  );
}
