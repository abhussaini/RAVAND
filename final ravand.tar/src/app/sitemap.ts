import type { MetadataRoute } from "next";

/**
 * XML sitemap — served at /sitemap.xml (Next file convention).
 * The public site is a hash-routed SPA on "/" (#/services, #/portfolio,
 * #/blog, #/about, #/contact); crawlers canonicalize fragments away,
 * so the sitemap lists the canonical base URL plus the hash sections
 * for tools that render fragments.
 */
const BASE = "https://rawandtech.com";

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();
  return [
    { url: BASE, lastModified, changeFrequency: "weekly", priority: 1 },
    { url: `${BASE}/#/services`, lastModified, changeFrequency: "monthly", priority: 0.8 },
    { url: `${BASE}/#/portfolio`, lastModified, changeFrequency: "monthly", priority: 0.8 },
    { url: `${BASE}/#/blog`, lastModified, changeFrequency: "weekly", priority: 0.7 },
    { url: `${BASE}/#/about`, lastModified, changeFrequency: "monthly", priority: 0.6 },
    { url: `${BASE}/#/contact`, lastModified, changeFrequency: "monthly", priority: 0.9 },
  ];
}
