"use client";

import Image from "next/image";
import { cn } from "@/lib/utils";
import { Reveal } from "./reveal";

/**
 * BlockSticker — the visual "sticker" that sits opposite the heading
 * text in every section. Die-cut vector artwork (1–2KB SVGs), gentle
 * float + tilt loop so the page feels alive without heavy images.
 */
export function BlockSticker({
  src,
  alt,
  tone = "light",
  size = "md",
  className,
  delay = 0,
}: {
  src: string;
  alt: string;
  /** light = white glass chip (for white/surface sections) — dark = navy glass (on brand surfaces) */
  tone?: "light" | "dark";
  size?: "sm" | "md" | "lg";
  className?: string;
  delay?: number;
}) {
  const box =
    size === "sm"
      ? "size-24 sm:size-28"
      : size === "lg"
        ? "size-44 sm:size-56"
        : "size-36 sm:size-44";

  return (
    <Reveal
      from={{ opacity: 0, scale: 0.6 }}
      delayIn={delay}
      className={cn("relative inline-block shrink-0", box, className)}
    >
      <span aria-hidden={alt === ""} className="block size-full">
        {/* wobbling sticker chip */}
        <span
          className={cn(
            "anim-float grid size-full place-items-center rounded-card shadow-[0_22px_44px_-18px_rgba(15,47,99,0.4)]",
            tone === "light" ? "glass-light" : "glass-dark-chip"
          )}
          style={{ animationDelay: `${delay}s` }}
        >
          <Image
            src={src}
            alt={alt}
            width={224}
            height={224}
            className="size-[80%] object-contain"
            sizes="224px"
          />
        </span>
      </span>
    </Reveal>
  );
}
