/* Brand social glyphs + agent mascot — tinted via currentColor */

export function WhatsAppIcon({
  className,
}: {
  className?: string;
  /* accepted so the icon can sit in icon slots that pass stroke props */
  strokeWidth?: number;
}) {
  return (
    <svg viewBox="0 0 448 512" fill="currentColor" aria-hidden className={className}>
      <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.6-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.7 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z" />
    </svg>
  );
}

export function FacebookIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 320 512" fill="currentColor" aria-hidden className={className}>
      <path d="M80 299.3V512H196V299.3h86.5l18-97.8H196V166.9c0-51.7 20.3-71.5 72.7-71.5c16.3 0 29.4 .4 37 1.2V7.9C291.4 4 256.4 0 236.2 0C129.3 0 80 50.5 80 159.4v42.1H14v97.8H80z" />
    </svg>
  );
}

/**
 * AgentIcon — Ravand assistant mascot: a friendly robot head drawn in the
 * brand palette (white shell, deep-navy face plate, lime antenna +
 * smile). Designed to sit on navy surfaces (launcher / chat header).
 */
export function AgentIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" aria-hidden className={className}>
      {/* antenna stem + lime beacon */}
      <line
        x1="32"
        y1="8"
        x2="32"
        y2="15"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        opacity="0.9"
      />
      <circle cx="32" cy="6" r="4" fill="#c2e029" />
      {/* side ears */}
      <rect x="3" y="29" width="8" height="13" rx="4" fill="currentColor" opacity="0.5" />
      <rect x="53" y="29" width="8" height="13" rx="4" fill="currentColor" opacity="0.5" />
      {/* head shell */}
      <rect x="9" y="16" width="46" height="37" rx="14" fill="currentColor" />
      {/* face plate — same navy as the surfaces it sits on */}
      <rect x="16" y="23" width="32" height="23" rx="10" fill="#0f2f63" />
      {/* eyes */}
      <circle cx="25.5" cy="32.5" r="3.4" fill="#ffffff" />
      <circle cx="38.5" cy="32.5" r="3.4" fill="#ffffff" />
      {/* cheeks */}
      <circle cx="21.5" cy="38.5" r="1.6" fill="#5790e6" opacity="0.85" />
      <circle cx="42.5" cy="38.5" r="1.6" fill="#5790e6" opacity="0.85" />
      {/* smile */}
      <path
        d="M26.5 39 Q32 43.4 37.5 39"
        stroke="#c2e029"
        strokeWidth="2.6"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}
