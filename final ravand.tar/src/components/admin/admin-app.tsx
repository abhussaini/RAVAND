"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import { QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BarChart3,
  ExternalLink,
  FolderOpen,
  LayoutDashboard,
  Loader2,
  LogOut,
  Mail,
  MessageSquareQuote,
  Newspaper,
  Pencil,
  Plus,
  Settings as SettingsIcon,
  Sparkles,
  Trash2,
  Users,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Toaster } from "@/components/ui/sonner";
import { BrandMark, BrandWordmark } from "@/components/site/ui-v2";
import { navigate } from "@/lib/router";
import { useLang } from "@/store/use-lang";
import { useBrand } from "@/store/use-brand";
import { cn } from "@/lib/utils";
import { useAdminT } from "./admin-strings";
import { L10nField, MediaPicker, StickerPicker, TextField, type L10nValue } from "./fields";

/* ────────────────────────────── helpers ────────────────────────────── */

type Row = Record<string, unknown> & { id: string };

function parseL10nField(v: unknown): L10nValue {
  const empty = { fa: "", ps: "", en: "" };
  if (v && typeof v === "object") return { ...empty, ...(v as L10nValue) };
  if (typeof v !== "string") return empty;
  try {
    const o = JSON.parse(v);
    return typeof o === "object" && o ? { ...empty, ...o } : { fa: v, ps: v, en: v };
  } catch {
    return { fa: v, ps: v, en: v };
  }
}

const str = (v: unknown) => (typeof v === "string" ? v : "");
const num = (v: unknown) => (typeof v === "number" ? v : 0);
const bool = (v: unknown) => v === true;

async function api(url: string, init?: RequestInit) {
  const res = await fetch(url, init);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.error || String(res.status));
  return json;
}

/* ────────────────────────────── login ────────────────────────────── */

function LoginCard() {
  const { t } = useAdminT();
  const qc = useQueryClient();
  const [pw, setPw] = useState("");
  const [error, setError] = useState(false);

  const login = useMutation({
    mutationFn: () =>
      api("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      }),
    onSuccess: () => {
      setError(false);
      qc.invalidateQueries({ queryKey: ["admin-session"] });
    },
    onError: () => setError(true),
  });

  return (
    <div className="grid min-h-screen place-items-center bg-surface px-4">
      <div className="w-full max-w-sm rounded-card-lg border border-hairline bg-white p-8 shadow-[0_30px_60px_-30px_rgba(15,47,99,0.3)]">
        <div className="flex items-center gap-2">
          <BrandMark />
          <BrandWordmark className="text-base" />
        </div>
        <h1 className="font-display mt-6 text-xl font-medium">{t("a.login_t")}</h1>
        <p className="mt-1.5 text-sm text-ink-soft">{t("a.login_d")}</p>
        <form
          className="mt-6 flex flex-col gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            login.mutate();
          }}
        >
          <Label htmlFor="admin-pw" className="sr-only">
            {t("a.password")}
          </Label>
          <Input
            id="admin-pw"
            type="password"
            dir="ltr"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            placeholder={t("a.password")}
            className="h-11"
          />
          {error && (
            <p role="alert" className="text-sm font-medium text-destructive">
              {t("a.wrong_pass")}
            </p>
          )}
          <Button type="submit" disabled={login.isPending} className="h-11 cursor-pointer rounded-pill">
            {login.isPending ? <Loader2 className="size-4 animate-spin" /> : t("a.sign_in")}
          </Button>
        </form>
      </div>
      <Toaster position="bottom-center" richColors />
    </div>
  );
}

/* ────────────────────────────── generic list/edit shell ────────────────────────────── */

/** Safe date rendering — "—" instead of "Invalid Date". */
function fmtDate(value: unknown): string {
  const d = new Date(String(value ?? ""));
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString();
}

function ListShell({
  title,
  onNew,
  children,
  busy,
}: {
  title: string;
  onNew?: () => void;
  children: React.ReactNode;
  busy?: boolean;
}) {
  const { t } = useAdminT();
  return (
    <div>
      <div className="flex items-center justify-between gap-4">
        <h2 className="font-display text-xl font-medium">{title}</h2>
        {onNew && (
          <Button onClick={onNew} className="cursor-pointer gap-2 rounded-pill" size="sm">
            <Plus className="size-4" />
            {t("a.new")}
          </Button>
        )}
      </div>
      <div className="mt-5">{busy ? <Spinner /> : children}</div>
    </div>
  );
}

function Spinner() {
  return (
    <div className="grid place-items-center py-16">
      <Loader2 className="size-6 animate-spin text-brand" />
    </div>
  );
}

function EmptyNote() {
  const { t } = useAdminT();
  return <p className="rounded-card bg-surface px-6 py-10 text-center text-sm text-ink-soft">{t("a.empty")}</p>;
}

function DeleteButton({ onDelete }: { onDelete: () => void }) {
  const { t } = useAdminT();
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        aria-label={t("a.delete")}
        onClick={() => setOpen(true)}
        className="grid size-9 cursor-pointer place-items-center rounded-lg text-ink-soft transition-colors hover:bg-destructive/10 hover:text-destructive"
      >
        <Trash2 className="size-4" />
      </button>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("a.confirm_del_t")}</AlertDialogTitle>
            <AlertDialogDescription>{t("a.confirm_del_d")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="cursor-pointer">{t("a.cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="cursor-pointer bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                setOpen(false);
                onDelete();
              }}
            >
              {t("a.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/* ────────────────────────────── resource forms ────────────────────────────── */

interface ServiceForm {
  slug: string;
  title: L10nValue;
  desc: L10nValue;
  sticker: string;
  order: number;
  active: boolean;
}
interface ProjectForm {
  slug: string;
  title: L10nValue;
  cat: L10nValue;
  desc: L10nValue;
  sticker: string;
  order: number;
  active: boolean;
}
interface PostForm {
  slug: string;
  title: L10nValue;
  cat: L10nValue;
  excerpt: L10nValue;
  body: L10nValue;
  sticker: string;
  readMin: number;
  dateLabel: L10nValue;
  published: boolean;
}
interface TestimonialForm {
  name: string;
  role: L10nValue;
  quote: L10nValue;
  order: number;
  active: boolean;
}
interface StatForm {
  value: number;
  suffix: string;
  label: L10nValue;
  sub: L10nValue;
  order: number;
  active: boolean;
}

const EMPTY: L10nValue = { fa: "", ps: "", en: "" };

function FormDialog({
  open,
  onClose,
  title,
  children,
  onSave,
  saving,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  onSave: () => void;
  saving: boolean;
}) {
  const { t } = useAdminT();
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        aria-describedby={undefined}
        className="max-h-[88svh] max-w-2xl overflow-y-auto rounded-card-lg"
        data-lenis-prevent
      >
        <DialogHeader>
          <DialogTitle className="font-display text-lg font-medium">{title}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4">{children}</div>
        <div className="mt-2 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="cursor-pointer rounded-pill">
            {t("a.cancel")}
          </Button>
          <Button onClick={onSave} disabled={saving} className="cursor-pointer rounded-pill">
            {saving ? <Loader2 className="size-4 animate-spin" /> : t("a.save")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ────────────────────────────── dashboard ────────────────────────────── */

type View =
  | "overview"
  | "services"
  | "projects"
  | "posts"
  | "testimonials"
  | "stats"
  | "messages"
  | "subscribers"
  | "settings";

const NAV_ITEMS: Array<{ key: View; icon: LucideIcon }> = [
  { key: "overview", icon: LayoutDashboard },
  { key: "services", icon: Wrench },
  { key: "projects", icon: FolderOpen },
  { key: "posts", icon: Newspaper },
  { key: "testimonials", icon: MessageSquareQuote },
  { key: "stats", icon: BarChart3 },
  { key: "messages", icon: Mail },
  { key: "subscribers", icon: Users },
  { key: "settings", icon: SettingsIcon },
];

function Dashboard() {
  const { t, lang } = useAdminT();
  const qc = useQueryClient();
  const [view, setView] = useState<View>("overview");
  const [editing, setEditing] = useState<Row | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<Record<string, unknown>>({});

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-list"] });
    qc.invalidateQueries({ queryKey: ["site-content"] });
  };

  /* mutations */
  const saveMutation = useMutation({
    mutationFn: ({ resource, id, body }: { resource: string; id?: string; body: Record<string, unknown> }) =>
      api(id ? `/api/admin/${resource}/${id}` : `/api/admin/${resource}`, {
        method: id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }),
    onSuccess: (_d, v) => {
      toast.success(v.id ? t("a.saved") : t("a.created"));
      setDialogOpen(false);
      invalidate();
    },
    onError: () => toast.error(t("a.error")),
  });

  const deleteMutation = useMutation({
    mutationFn: ({ resource, id }: { resource: string; id: string }) =>
      api(`/api/admin/${resource}/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success(t("a.deleted"));
      invalidate();
    },
    onError: () => toast.error(t("a.error")),
  });

  const patchMutation = useMutation({
    mutationFn: ({ id, read }: { id: string; read: boolean }) =>
      api(`/api/admin/messages/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ read }),
      }),
    onSuccess: () => invalidate(),
    onError: () => toast.error(t("a.error")),
  });

  const logout = useMutation({
    mutationFn: () => api("/api/admin/logout", { method: "POST" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-session"] }),
    onError: () => toast.error(t("a.error")),
  });

  /* list fetchers */
  const useListQuery = (resource: string) =>
    useQuery({
      queryKey: ["admin-list", resource],
      queryFn: () => api(`/api/admin/${resource}`),
      staleTime: 0,
      refetchOnMount: "always",
    });

  /* open editor */
  const openEdit = (resource: "services" | "projects" | "posts" | "testimonials" | "stats", row: Row | null) => {
    setEditing(row);
    setDialogOpen(true);
    if (!row) {
      setForm(resource === "stats" ? { value: 0, suffix: "", label: EMPTY, sub: EMPTY, order: 0, active: true } : {});
      return;
    }
    switch (resource) {
      case "services":
        setForm({
          slug: str(row.slug),
          title: parseL10nField(row.title),
          desc: parseL10nField(row.desc),
          sticker: str(row.sticker) || "/stickers/st-services.svg",
          order: num(row.order),
          active: bool(row.active),
        });
        break;
      case "projects":
        setForm({
          slug: str(row.slug),
          title: parseL10nField(row.title),
          cat: parseL10nField(row.cat),
          desc: parseL10nField(row.desc),
          sticker: str(row.sticker) || "/stickers/st-portfolio.svg",
          order: num(row.order),
          active: bool(row.active),
        });
        break;
      case "posts":
        setForm({
          slug: str(row.slug),
          title: parseL10nField(row.title),
          cat: parseL10nField(row.cat),
          excerpt: parseL10nField(row.excerpt),
          body: parseL10nField(row.body),
          sticker: str(row.sticker) || "/stickers/st-blog.svg",
          readMin: num(row.readMin) || 6,
          dateLabel: parseL10nField(row.dateLabel),
          published: bool(row.published),
        });
        break;
      case "testimonials":
        setForm({
          name: str(row.name),
          role: parseL10nField(row.role),
          quote: parseL10nField(row.quote),
          order: num(row.order),
          active: bool(row.active),
        });
        break;
      case "stats":
        setForm({
          value: num(row.value),
          suffix: str(row.suffix),
          label: parseL10nField(row.label),
          sub: parseL10nField(row.sub),
          order: num(row.order),
          active: bool(row.active),
        });
        break;
    }
  };

  const saveCurrent = (resource: string) => {
    const id = editing?.id;
    saveMutation.mutate({ resource, id, body: form });
  };

  /* ── single-resource list views ── */

  const services = useListQuery("services");
  const projects = useListQuery("projects");
  const posts = useListQuery("posts");
  const testimonials = useListQuery("testimonials");
  const stats = useListQuery("stats");
  const messages = useListQuery("messages");
  const subscribers = useListQuery("subscribers");
  const settings = useQuery({
    queryKey: ["admin-settings"],
    queryFn: () => api("/api/admin/settings"),
    enabled: view === "settings",
  });

  const f = form as Record<string, unknown>;
  const setF = (k: string, v: unknown) => setForm((prev) => ({ ...prev, [k]: v }));
  const l10nForm = (k: string) => (parseL10nField(f[k]) as L10nValue);

  const iconFor = (row: Row) => str(row.sticker) || "/stickers/st-services.svg";

  const dialogResource: string =
    view === "services" || view === "projects" || view === "posts" || view === "testimonials" || view === "stats"
      ? view
      : "";

  const dialogTitle = editing
    ? `${t("a.edit")} — ${editing.id.slice(0, 6)}`
    : `${t("a.new")} · ${t(`a.${dialogResource}`)}`;

  return (
    <div className="flex min-h-screen flex-col bg-surface lg:flex-row">
      {/* sidebar */}
      <aside className="flex shrink-0 flex-col border-b border-hairline bg-white lg:min-h-screen lg:w-64 lg:border-b-0 lg:border-e">
        <div className="flex items-center justify-between p-5">
          <span className="flex items-center gap-2">
            <BrandMark />
            <BrandWordmark className="text-sm" />
          </span>
          <button
            type="button"
            onClick={() => navigate("/")}
            className="inline-flex cursor-pointer items-center gap-1.5 rounded-pill bg-surface px-3 py-1.5 text-xs font-medium text-ink-soft transition-colors hover:bg-hairline"
          >
            <ExternalLink className="size-3.5" />
            {t("a.view_site")}
          </button>
        </div>
        <nav className="flex flex-row flex-wrap gap-1.5 px-4 pb-4 lg:flex-col lg:flex-nowrap" aria-label={t("a.panel_t")}>
          {NAV_ITEMS.map((n) => (
            <button
              key={n.key}
              type="button"
              onClick={() => setView(n.key)}
              aria-current={view === n.key}
              className={cn(
                "flex cursor-pointer items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
                view === n.key
                  ? "bg-brand text-white"
                  : "text-ink-soft hover:bg-surface hover:text-ink"
              )}
            >
              <n.icon className="size-4" strokeWidth={1.8} />
              {t(`a.${n.key}`)}
              {n.key === "messages" && (messages.data?.items?.filter((m: Row) => !bool(m.read)).length ?? 0) > 0 && (
                <span className="ms-auto rounded-pill bg-destructive px-1.5 text-[0.65rem] font-semibold text-white">
                  {messages.data?.items?.filter((m: Row) => !bool(m.read)).length}
                </span>
              )}
            </button>
          ))}
          <button
            type="button"
            onClick={() => navigate("/seo")}
            className="flex cursor-pointer items-center gap-2.5 rounded-xl bg-brand-deep px-3.5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-brand"
          >
            <Sparkles className="size-4" strokeWidth={1.8} />
            {t("a.seo_assistant")}
          </button>
        </nav>
        <div className="mt-auto hidden p-4 lg:block">
          <button
            type="button"
            onClick={() => logout.mutate()}
            className="flex w-full cursor-pointer items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-medium text-ink-soft transition-colors hover:bg-destructive/10 hover:text-destructive"
          >
            <LogOut className="size-4 rtl:-scale-x-100" />
            {t("a.logout")}
          </button>
        </div>
      </aside>

      {/* content */}
      <main className="flex-1 p-5 sm:p-8">
        {/* mobile logout */}
        <div className="mb-4 flex justify-end lg:hidden">
          <Button variant="outline" size="sm" className="cursor-pointer rounded-pill" onClick={() => logout.mutate()}>
            <LogOut className="size-3.5 rtl:-scale-x-100" />
            {t("a.logout")}
          </Button>
        </div>

        {view === "overview" && (
          <div>
            <h2 className="font-display text-xl font-medium">{t("a.overview")}</h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-soft">{t("a.overview_hint")}</p>
            <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-6">
              {[
                { label: t("a.services"), count: services.data?.items?.length, icon: Wrench },
                { label: t("a.projects"), count: projects.data?.items?.length, icon: FolderOpen },
                { label: t("a.posts"), count: posts.data?.items?.length, icon: Newspaper },
                { label: t("a.testimonials"), count: testimonials.data?.items?.length, icon: MessageSquareQuote },
                { label: t("a.messages"), count: messages.data?.items?.length, icon: Mail },
                { label: t("a.subscribers"), count: subscribers.data?.items?.length, icon: Users },
              ].map((c) => (
                <div key={c.label} className="rounded-card border border-hairline bg-white p-5">
                  <c.icon className="size-5 text-brand" strokeWidth={1.7} />
                  <p dir="ltr" className="font-display mt-3 text-3xl font-medium leading-none">
                    {c.count ?? "—"}
                  </p>
                  <p className="mt-1.5 text-xs text-ink-soft">{c.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* services */}
        {view === "services" && (
          <ListShell title={t("a.services")} onNew={() => openEdit("services", null)} busy={services.isLoading}>
            {services.data?.items?.length ? (
              <ul className="grid gap-3 md:grid-cols-2">
                {services.data.items.map((row: Row) => (
                  <li key={row.id} className="flex items-center gap-4 rounded-card border border-hairline bg-white p-4">
                    <Image src={iconFor(row)} alt="" width={48} height={48} className="size-12 shrink-0 object-contain" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{parseL10nField(row.title)[lang] || parseL10nField(row.title).fa}</p>
                      <p dir="ltr" className="truncate text-xs text-ink-soft">{str(row.slug)} · #{num(row.order)}</p>
                    </div>
                    <span className={cn("rounded-pill px-2.5 py-1 text-[0.65rem] font-semibold", bool(row.active) ? "bg-brand/10 text-brand" : "bg-surface text-ink-soft")}>
                      {bool(row.active) ? t("a.active") : "—"}
                    </span>
                    <button type="button" aria-label={t("a.edit")} onClick={() => openEdit("services", row)} className="grid size-9 cursor-pointer place-items-center rounded-lg text-ink-soft transition-colors hover:bg-brand/10 hover:text-brand">
                      <Pencil className="size-4" />
                    </button>
                    <DeleteButton onDelete={() => deleteMutation.mutate({ resource: "services", id: row.id })} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyNote />
            )}
          </ListShell>
        )}

        {/* projects */}
        {view === "projects" && (
          <ListShell title={t("a.projects")} onNew={() => openEdit("projects", null)} busy={projects.isLoading}>
            {projects.data?.items?.length ? (
              <ul className="grid gap-3 md:grid-cols-2">
                {projects.data.items.map((row: Row) => (
                  <li key={row.id} className="flex items-center gap-4 rounded-card border border-hairline bg-white p-4">
                    <Image src={iconFor(row)} alt="" width={48} height={48} className="size-12 shrink-0 object-contain" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{parseL10nField(row.title)[lang] || parseL10nField(row.title).fa}</p>
                      <p className="truncate text-xs text-ink-soft">{parseL10nField(row.cat)[lang] || parseL10nField(row.cat).fa}</p>
                    </div>
                    <button type="button" aria-label={t("a.edit")} onClick={() => openEdit("projects", row)} className="grid size-9 cursor-pointer place-items-center rounded-lg text-ink-soft transition-colors hover:bg-brand/10 hover:text-brand">
                      <Pencil className="size-4" />
                    </button>
                    <DeleteButton onDelete={() => deleteMutation.mutate({ resource: "projects", id: row.id })} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyNote />
            )}
          </ListShell>
        )}

        {/* posts */}
        {view === "posts" && (
          <ListShell title={t("a.posts")} onNew={() => openEdit("posts", null)} busy={posts.isLoading}>
            {posts.data?.items?.length ? (
              <ul className="grid gap-3 md:grid-cols-2">
                {posts.data.items.map((row: Row) => (
                  <li key={row.id} className="flex items-center gap-4 rounded-card border border-hairline bg-white p-4">
                    <Image src={iconFor(row)} alt="" width={48} height={48} className="size-12 shrink-0 object-contain" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{parseL10nField(row.title)[lang] || parseL10nField(row.title).fa}</p>
                      <p dir="ltr" className="truncate text-xs text-ink-soft">
                        {str(row.slug)} · {num(row.readMin)}min
                      </p>
                    </div>
                    <span className={cn("rounded-pill px-2.5 py-1 text-[0.65rem] font-semibold", bool(row.published) ? "bg-brand/10 text-brand" : "bg-surface text-ink-soft")}>
                      {bool(row.published) ? t("a.published") : "—"}
                    </span>
                    <button type="button" aria-label={t("a.edit")} onClick={() => openEdit("posts", row)} className="grid size-9 cursor-pointer place-items-center rounded-lg text-ink-soft transition-colors hover:bg-brand/10 hover:text-brand">
                      <Pencil className="size-4" />
                    </button>
                    <DeleteButton onDelete={() => deleteMutation.mutate({ resource: "posts", id: row.id })} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyNote />
            )}
          </ListShell>
        )}

        {/* testimonials */}
        {view === "testimonials" && (
          <ListShell title={t("a.testimonials")} onNew={() => openEdit("testimonials", null)} busy={testimonials.isLoading}>
            {testimonials.data?.items?.length ? (
              <ul className="grid gap-3 md:grid-cols-2">
                {testimonials.data.items.map((row: Row) => (
                  <li key={row.id} className="flex items-center gap-4 rounded-card border border-hairline bg-white p-4">
                    <span aria-hidden className="font-display grid size-11 shrink-0 place-items-center rounded-pill bg-brand-deep text-sm font-medium text-white">
                      {str(row.name).trim().charAt(0) || "؟"}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{str(row.name)}</p>
                      <p className="truncate text-xs text-ink-soft">{parseL10nField(row.role)[lang] || parseL10nField(row.role).fa}</p>
                    </div>
                    <button type="button" aria-label={t("a.edit")} onClick={() => openEdit("testimonials", row)} className="grid size-9 cursor-pointer place-items-center rounded-lg text-ink-soft transition-colors hover:bg-brand/10 hover:text-brand">
                      <Pencil className="size-4" />
                    </button>
                    <DeleteButton onDelete={() => deleteMutation.mutate({ resource: "testimonials", id: row.id })} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyNote />
            )}
          </ListShell>
        )}

        {/* stats */}
        {view === "stats" && (
          <ListShell title={t("a.stats")} onNew={() => openEdit("stats", null)} busy={stats.isLoading}>
            {stats.data?.items?.length ? (
              <ul className="grid gap-3 sm:grid-cols-2">
                {stats.data.items.map((row: Row) => (
                  <li key={row.id} className="flex items-center gap-4 rounded-card border border-hairline bg-white p-4">
                    <span dir="ltr" className="font-display text-2xl font-medium text-brand">
                      {num(row.value)}
                      {str(row.suffix)}
                    </span>
                    <p className="min-w-0 flex-1 truncate text-sm font-medium">{parseL10nField(row.label)[lang] || parseL10nField(row.label).fa}</p>
                    <button type="button" aria-label={t("a.edit")} onClick={() => openEdit("stats", row)} className="grid size-9 cursor-pointer place-items-center rounded-lg text-ink-soft transition-colors hover:bg-brand/10 hover:text-brand">
                      <Pencil className="size-4" />
                    </button>
                    <DeleteButton onDelete={() => deleteMutation.mutate({ resource: "stats", id: row.id })} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyNote />
            )}
          </ListShell>
        )}

        {/* messages */}
        {view === "messages" && (
          <ListShell title={t("a.messages")} busy={messages.isLoading}>
            {messages.data?.items?.length ? (
              <ul className="flex flex-col gap-3">
                {messages.data.items.map((row: Row) => (
                  <li
                    key={row.id}
                    className={cn(
                      "rounded-card border bg-white p-5",
                      bool(row.read) ? "border-hairline" : "border-brand/40"
                    )}
                  >
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="text-sm font-medium">{str(row.name)}</span>
                      <a dir="ltr" href={`mailto:${str(row.email)}`} className="text-xs text-brand hover:underline">
                        {str(row.email)}
                      </a>
                      {str(row.phone) && (
                        <span dir="ltr" className="text-xs text-ink-soft">{str(row.phone)}</span>
                      )}
                      {str(row.service) && (
                        <span className="rounded-pill bg-surface px-2.5 py-1 text-[0.65rem] font-semibold text-ink-soft">
                          {str(row.service)}
                        </span>
                      )}
                      <span className="ms-auto text-xs text-ink-soft">
                        {fmtDate(row.createdAt)}
                      </span>
                      {!bool(row.read) && (
                        <button
                          type="button"
                          onClick={() => patchMutation.mutate({ id: row.id, read: true })}
                          className="cursor-pointer rounded-pill bg-brand/10 px-3 py-1.5 text-xs font-medium text-brand transition-colors hover:bg-brand hover:text-white"
                        >
                          {t("a.mark_read")}
                        </button>
                      )}
                      <DeleteButton onDelete={() => deleteMutation.mutate({ resource: "messages", id: row.id })} />
                    </div>
                    <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-ink-soft">{str(row.message)}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyNote />
            )}
          </ListShell>
        )}

        {/* subscribers */}
        {view === "subscribers" && (
          <ListShell title={t("a.subscribers")} busy={subscribers.isLoading}>
            {subscribers.data?.items?.length ? (
              <ul className="flex flex-col gap-2">
                {subscribers.data.items.map((row: Row) => (
                  <li key={row.id} className="flex items-center gap-4 rounded-xl border border-hairline bg-white px-4 py-3">
                    <Mail className="size-4 shrink-0 text-brand" />
                    <a dir="ltr" href={`mailto:${str(row.email)}`} className="min-w-0 flex-1 truncate text-sm hover:underline">
                      {str(row.email)}
                    </a>
                    <span className="text-xs text-ink-soft">
                      {fmtDate(row.createdAt)}
                    </span>
                    <DeleteButton onDelete={() => deleteMutation.mutate({ resource: "subscribers", id: row.id })} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyNote />
            )}
          </ListShell>
        )}

        {/* settings */}
        {view === "settings" && (
          <ListShell title={t("a.settings")} busy={settings.isLoading}>
            {settings.data?.item && (
              <SettingsForm
                item={settings.data.item as Row}
                onSave={(body) =>
                  saveMutation.mutate({ resource: "settings", id: "main", body })
                }
                saving={saveMutation.isPending}
              />
            )}
          </ListShell>
        )}
      </main>

      {/* edit dialog */}
      {dialogResource && dialogOpen && (
        <FormDialog
          open={dialogOpen}
          onClose={() => setDialogOpen(false)}
          title={dialogTitle}
          saving={saveMutation.isPending}
          onSave={() => saveCurrent(dialogResource)}
        >
          {dialogResource === "services" && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <TextField label={t("a.slug")} dir="ltr" value={str(f.slug)} onChange={(v) => setF("slug", v)} />
                <TextField label={t("a.order")} type="number" dir="ltr" value={num(f.order)} onChange={(v) => setF("order", Number(v) || 0)} />
              </div>
              <L10nField label={t("a.title")} value={l10nForm("title")} onChange={(v) => setF("title", v)} />
              <L10nField label={t("a.desc")} value={l10nForm("desc")} onChange={(v) => setF("desc", v)} multiline rows={3} />
              <StickerPicker label={t("a.sticker")} value={str(f.sticker) || "/stickers/st-services.svg"} onChange={(v) => setF("sticker", v)} />
              <label className="flex cursor-pointer items-center gap-3">
                <Switch checked={bool(f.active)} onCheckedChange={(v) => setF("active", v)} />
                <span className="text-sm font-medium">{t("a.active")}</span>
              </label>
            </>
          )}

          {dialogResource === "projects" && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <TextField label={t("a.slug")} dir="ltr" value={str(f.slug)} onChange={(v) => setF("slug", v)} />
                <TextField label={t("a.order")} type="number" dir="ltr" value={num(f.order)} onChange={(v) => setF("order", Number(v) || 0)} />
              </div>
              <L10nField label={t("a.title")} value={l10nForm("title")} onChange={(v) => setF("title", v)} />
              <L10nField label={t("a.cat")} value={l10nForm("cat")} onChange={(v) => setF("cat", v)} />
              <L10nField label={t("a.desc")} value={l10nForm("desc")} onChange={(v) => setF("desc", v)} multiline rows={2} />
              <StickerPicker label={t("a.sticker")} value={str(f.sticker) || "/stickers/st-portfolio.svg"} onChange={(v) => setF("sticker", v)} />
              <label className="flex cursor-pointer items-center gap-3">
                <Switch checked={bool(f.active)} onCheckedChange={(v) => setF("active", v)} />
                <span className="text-sm font-medium">{t("a.active")}</span>
              </label>
            </>
          )}

          {dialogResource === "posts" && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <TextField label={t("a.slug")} dir="ltr" value={str(f.slug)} onChange={(v) => setF("slug", v)} />
                <TextField label={t("a.read_min")} type="number" dir="ltr" value={num(f.readMin) || 6} onChange={(v) => setF("readMin", Number(v) || 1)} />
              </div>
              <L10nField label={t("a.title")} value={l10nForm("title")} onChange={(v) => setF("title", v)} />
              <L10nField label={t("a.cat")} value={l10nForm("cat")} onChange={(v) => setF("cat", v)} />
              <L10nField label={t("a.date_label")} value={l10nForm("dateLabel")} onChange={(v) => setF("dateLabel", v)} />
              <L10nField label={t("a.excerpt")} value={l10nForm("excerpt")} onChange={(v) => setF("excerpt", v)} multiline rows={2} />
              <L10nField label={t("a.body")} value={l10nForm("body")} onChange={(v) => setF("body", v)} multiline rows={7} />
              <StickerPicker label={t("a.sticker")} value={str(f.sticker) || "/stickers/st-blog.svg"} onChange={(v) => setF("sticker", v)} />
              <label className="flex cursor-pointer items-center gap-3">
                <Switch checked={bool(f.published)} onCheckedChange={(v) => setF("published", v)} />
                <span className="text-sm font-medium">{t("a.published")}</span>
              </label>
            </>
          )}

          {dialogResource === "testimonials" && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <TextField label={t("a.name")} value={str(f.name)} onChange={(v) => setF("name", v)} />
                <TextField label={t("a.order")} type="number" dir="ltr" value={num(f.order)} onChange={(v) => setF("order", Number(v) || 0)} />
              </div>
              <L10nField label={t("a.role")} value={l10nForm("role")} onChange={(v) => setF("role", v)} />
              <L10nField label={t("a.quote")} value={l10nForm("quote")} onChange={(v) => setF("quote", v)} multiline rows={4} />
              <label className="flex cursor-pointer items-center gap-3">
                <Switch checked={bool(f.active)} onCheckedChange={(v) => setF("active", v)} />
                <span className="text-sm font-medium">{t("a.active")}</span>
              </label>
            </>
          )}

          {dialogResource === "stats" && (
            <>
              <div className="grid gap-4 sm:grid-cols-3">
                <TextField label={t("a.value")} type="number" dir="ltr" value={num(f.value)} onChange={(v) => setF("value", Number(v) || 0)} />
                <TextField label={t("a.suffix")} dir="ltr" value={str(f.suffix)} onChange={(v) => setF("suffix", v)} />
                <TextField label={t("a.order")} type="number" dir="ltr" value={num(f.order)} onChange={(v) => setF("order", Number(v) || 0)} />
              </div>
              <L10nField label={t("a.label")} value={l10nForm("label")} onChange={(v) => setF("label", v)} />
              <L10nField label={t("a.sub")} value={l10nForm("sub")} onChange={(v) => setF("sub", v)} />
              <label className="flex cursor-pointer items-center gap-3">
                <Switch checked={bool(f.active)} onCheckedChange={(v) => setF("active", v)} />
                <span className="text-sm font-medium">{t("a.active")}</span>
              </label>
            </>
          )}
        </FormDialog>
      )}

      <Toaster position="bottom-center" richColors />
    </div>
  );
}

/* ────────────────────────────── settings form ────────────────────────────── */

function SettingsForm({
  item,
  onSave,
  saving,
}: {
  item: Row;
  onSave: (body: Record<string, unknown>) => void;
  saving: boolean;
}) {
  const { t } = useAdminT();
  const setLogoUrl = useBrand((s) => s.setLogoUrl);
  const [form, setForm] = useState(() => ({
    logoUrl: str(item.logoUrl) || "/images/logo-r.webp",
    email: str(item.email),
    phone1: str(item.phone1),
    phone2: str(item.phone2),
    whatsapp: str(item.whatsapp),
    instagram: str(item.instagram),
    tagline: parseL10nField(item.tagline),
    address: parseL10nField(item.address),
    hours: parseL10nField(item.hours),
  }));

  return (
    <div className="flex flex-col gap-4 max-w-2xl">
      <MediaPicker
        label={t("a.logo")}
        value={form.logoUrl}
        showLibrary={false}
        onChange={(v) => setForm((p) => ({ ...p, logoUrl: v }))}
      />
      <div className="grid gap-4 sm:grid-cols-2">
        <TextField label={t("a.email")} dir="ltr" value={form.email} onChange={(v) => setForm((p) => ({ ...p, email: v }))} />
        <TextField label={t("a.instagram")} dir="ltr" value={form.instagram} onChange={(v) => setForm((p) => ({ ...p, instagram: v }))} />
        <TextField label={t("a.phone1")} dir="ltr" value={form.phone1} onChange={(v) => setForm((p) => ({ ...p, phone1: v }))} />
        <TextField label={t("a.phone2")} dir="ltr" value={form.phone2} onChange={(v) => setForm((p) => ({ ...p, phone2: v }))} />
        <TextField label={t("a.whatsapp")} dir="ltr" value={form.whatsapp} onChange={(v) => setForm((p) => ({ ...p, whatsapp: v }))} />
      </div>
      <L10nField label={t("a.tagline")} value={form.tagline} onChange={(v) => setForm((p) => ({ ...p, tagline: v }))} multiline rows={2} />
      <div className="grid gap-4 sm:grid-cols-2">
        <L10nField label={t("a.address")} value={form.address} onChange={(v) => setForm((p) => ({ ...p, address: v }))} />
        <L10nField label={t("a.hours")} value={form.hours} onChange={(v) => setForm((p) => ({ ...p, hours: v }))} />
      </div>
      <div>
        <Button
          onClick={() => {
            setLogoUrl(form.logoUrl); // live preview in the panel too
            onSave(form);
          }}
          disabled={saving}
          className="cursor-pointer rounded-pill"
        >
          {saving ? <Loader2 className="size-4 animate-spin" /> : t("a.save")}
        </Button>
      </div>
    </div>
  );
}

/* ────────────────────────────── root ────────────────────────────── */

/* Provider lives here (inside the dynamic admin chunk) so react-query
   is not part of the public site bundle. */
export function AdminApp() {
  const [qc] = useState(
    () =>
      new QueryClient({
        defaultOptions: { queries: { staleTime: 30_000, retry: 1 } },
      })
  );
  return (
    <QueryClientProvider client={qc}>
      <AdminAppInner />
    </QueryClientProvider>
  );
}

function AdminAppInner() {
  const { t } = useAdminT();
  const session = useQuery({
    queryKey: ["admin-session"],
    queryFn: () => api("/api/admin/session"),
    staleTime: 60_000,
  });

  if (session.isLoading) return <Spinner />;
  if (!session.data?.authed) return <LoginCard />;

  return (
    <>
      {/* panel top bar (RTL/LTR aware) */}
      <div className="flex items-center justify-between border-b border-hairline bg-white px-5 py-3">
        <p className="text-sm font-medium">{t("a.panel_t")}</p>
        <LangSwitchInline />
      </div>
      <Dashboard />
    </>
  );
}

function LangSwitchInline() {
  const { lang, t } = useAdminT();
  const setLang = useLang((s) => s.setLang);
  return (
    <div className="flex items-center gap-1.5" role="group" aria-label={t("nav.language")}>
      {(["fa", "ps", "en"] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cn(
            "cursor-pointer rounded-pill px-3 py-1.5 text-xs font-medium transition-colors",
            lang === l ? "bg-ink text-white" : "bg-surface text-ink-soft hover:bg-hairline"
          )}
        >
          {l === "fa" ? "دری" : l === "ps" ? "پښتو" : "EN"}
        </button>
      ))}
    </div>
  );
}
