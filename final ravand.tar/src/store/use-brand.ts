"use client";

import { useEffect } from "react";
import { create } from "zustand";

/**
 * Brand assets — the logo URL the admin manages in Settings.
 * Hydrated once per session from /api/brand; every BrandMark
 * instance renders the live value immediately after that.
 */
interface BrandState {
  logoUrl: string;
  setLogoUrl: (url: string) => void;
}

export const useBrand = create<BrandState>()((set) => ({
  logoUrl: "/images/logo-r.webp",
  setLogoUrl: (logoUrl) => set({ logoUrl }),
}));

let hydrated = false;

/** Fetch the admin-managed logo once per page load. */
export function useBrandSync() {
  const setLogoUrl = useBrand((s) => s.setLogoUrl);
  useEffect(() => {
    if (hydrated) return;
    hydrated = true;
    fetch("/api/brand", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (j?.ok && typeof j.logoUrl === "string" && j.logoUrl) {
          setLogoUrl(j.logoUrl);
        }
      })
      .catch(() => {});
  }, [setLogoUrl]);
}
