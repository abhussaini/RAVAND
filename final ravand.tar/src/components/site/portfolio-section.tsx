"use client";

import { PortfolioCards, type PortfolioCard } from "@/components/site/portfolio-cards";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { useUi } from "@/store/use-ui";
import { StackedLines } from "./reveal";
import { BlockSticker } from "./sticker";
import { Eyebrow } from "./ui-v2";

const FALLBACK = [
  { slug: "hamsafar-tours", title: "p1_title", cat: "p1_cat", preset: "web", alt: "Hamsafar Tours — tourism & hotel booking website", img: "/stickers/hamsafar.svg" },
  { slug: "omo-education", title: "p2_title", cat: "p2_cat", preset: "web", alt: "OMO Education — online course platform", img: "/stickers/omo.svg" },
  { slug: "agentic-platform", title: "p3_title", cat: "p3_cat", preset: "software", alt: "Agentic Platform — AI process automation", img: "/stickers/agentic-platform.svg" },
  { slug: "ai-workspace", title: "p4_title", cat: "p4_cat", preset: "software", alt: "AI Workspace — smart workspace product", img: "/stickers/ai-workspace.svg" },
  { slug: "business-integration", title: "p5_title", cat: "p5_cat", preset: "software", alt: "Business Integration — data integration & CRM", img: "/stickers/business-integration.svg" },
  { slug: "mobile-app-suite", title: "p6_title", cat: "p6_cat", preset: "uiux", alt: "Mobile App Suite — scalable mobile applications", img: "/stickers/mobile-app.svg" },
] as const;

const PRESET_BY_SLUG: Record<string, string> = {
  "hamsafar-tours": "web",
  "omo-education": "web",
  "agentic-platform": "software",
  "ai-workspace": "software",
  "business-integration": "software",
  "mobile-app-suite": "uiux",
};

/**
 * "Work we're proud of" — sticker beside the heading, then the
 * PortfolioCards grid of small sticker boxes: colorful vector
 * artwork (1KB SVGs), blur-in reveal, glass CTA per box.
 * Content is DB-driven (admin panel) with the dictionary fallback.
 */
/** Cards-only grid — reused by the portfolio page. */
export function PortfolioGrid() {
  const { t } = useT();
  const { content, pick } = useContent();
  const openContact = useUi((s) => s.openContact);

  const projects = content?.projects?.length
    ? content.projects.map((p) => ({
        slug: p.slug,
        title: pick(p.title),
        cat: pick(p.cat),
        img: p.sticker,
        alt: pick(p.title),
        preset: PRESET_BY_SLUG[p.slug] ?? "web",
      }))
    : FALLBACK.map((p) => ({ ...p, title: t(p.title), cat: t(p.cat) }));

  const cards: PortfolioCard[] = projects.map((p) => ({
    title: p.title,
    subtitle: p.cat,
    image: p.img,
    imageAlt: p.alt,
    invert: true,
    cta: {
      ctaEnabled: true,
      text: t("portfolio.view"),
      size: "sm",
      onClick: () => openContact(p.preset),
    },
  }));

  return <PortfolioCards cards={cards} animation="subtle" />;
}

export function PortfolioSection() {
  const { t } = useT();

  return (
    <section id="portfolio" className="relative overflow-hidden bg-white">
      {/* header — text + sticker */}
      <div className="flex flex-col gap-6 px-6 pt-16 sm:px-10 sm:pt-20 md:flex-row md:items-center md:justify-between md:gap-10">
        <div className="max-w-2xl">
          <Eyebrow>{t("portfolio.eyebrow")}</Eyebrow>
          <h2 className="font-display t-section mt-4 font-medium">
            <StackedLines lines={[t("v2.portfolio.one")]} stagger={120} />
          </h2>
        </div>
        <BlockSticker src="/stickers/st-portfolio.svg" alt="" tone="light" delay={0.15} />
      </div>

      <div className="-mt-2">
        <PortfolioGrid />
      </div>
    </section>
  );
}
