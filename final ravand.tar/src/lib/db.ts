import { PrismaClient } from "@prisma/client";
import {
  J,
  SEED_SERVICES,
  SEED_PROJECTS,
  SEED_POSTS,
  SEED_TESTIMONIALS,
  SEED_STATS,
  SEED_SETTING,
} from "./seed-data";

/* ------------------------------------------------------------------
   Ravand Tech — database layer (Supabase Postgres, hosting-ready).

   • The app talks to the project's Supabase Postgres database through
     Prisma using DATABASE_URL — the Supavisor transaction pooler URL
     (port 6543). That URL works identically in local development and
     on Netlify serverless functions, so there is exactly ONE durable
     store for the site, the admin panel, the leads and the SEO
     assistant — everywhere.
   • DIRECT_URL (session pooler, port 5432) is used only by the Prisma
     CLI (`prisma db push` / migrations), never by the running app.
   • SQLite / libSQL file databases are no longer supported: they
     cannot persist on serverless platforms (Netlify's function
     filesystem is read-only and ephemeral). A wrong DATABASE_URL now
     fails fast with a clear, actionable error instead of silently
     breaking on the host.

   ensureDb() runs at most once per server process: it creates any
   missing tables (Postgres dialect, idempotent) and seeds an EMPTY
   database with the real site content, so pointing the site at a
   brand-new Supabase project never needs a manual migration.
   ------------------------------------------------------------------ */

const globalForDb = globalThis as unknown as {
  prisma: PrismaClient | undefined;
  rvSchemaReady: Promise<void> | undefined;
};

/** The exact helpful error to show when the database is not configured. */
export function dbConfigError(): Error | null {
  const url = process.env.DATABASE_URL || "";
  if (!url) {
    return new Error(
      "DATABASE_URL is not set. Add the Supabase pooler connection string " +
        "(postgresql://postgres.<project-ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres" +
        "?pgbouncer=true&connection_limit=1) to the environment variables " +
        "(Netlify → Site configuration → Environment variables) and redeploy."
    );
  }
  if (
    url.startsWith("file:") ||
    url.startsWith("libsql:") ||
    url.startsWith("http://") ||
    url.startsWith("https://")
  ) {
    return new Error(
      "DATABASE_URL must be a Supabase Postgres URL (postgresql://...). " +
        "File databases (SQLite/libSQL) do not persist on serverless hosting."
    );
  }
  return null;
}

function createDb(): PrismaClient {
  /* Never throw at import time — API routes catch ensureDb() failures
     and keep serving (Supabase REST fallback, rule-based chat). A
     placeholder keeps the client constructible while misconfigured. */
  if (!process.env.DATABASE_URL) {
    process.env.DATABASE_URL = "postgresql://placeholder@localhost:5432/placeholder";
  }
  return new PrismaClient();
}

export const db = globalForDb.prisma ?? createDb();

if (process.env.NODE_ENV !== "production") globalForDb.prisma = db;

/* ------------------------------------------------------------------
   Schema bootstrap — mirrors prisma/schema.prisma exactly (Postgres
   dialect). CREATE TABLE IF NOT EXISTS keeps it idempotent and cheap;
   a fast to_regclass probe skips the whole list once the schema is
   already complete (warm path = one extra query per cold start).
   ------------------------------------------------------------------ */
const SCHEMA_SQL: string[] = [
  /* ── Site content ─────────────────────────────────────── */
  `CREATE TABLE IF NOT EXISTS "ContactMessage" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "name" TEXT NOT NULL,
     "email" TEXT NOT NULL,
     "phone" TEXT,
     "service" TEXT,
     "message" TEXT NOT NULL,
     "read" BOOLEAN NOT NULL DEFAULT false,
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS "Subscriber" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "email" TEXT NOT NULL,
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "Subscriber_email_key" ON "Subscriber"("email")`,
  `CREATE TABLE IF NOT EXISTS "Service" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "slug" TEXT NOT NULL,
     "title" TEXT NOT NULL,
     "desc" TEXT NOT NULL,
     "sticker" TEXT NOT NULL DEFAULT '/stickers/st-services.svg',
     "order" INTEGER NOT NULL DEFAULT 0,
     "active" BOOLEAN NOT NULL DEFAULT true
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "Service_slug_key" ON "Service"("slug")`,
  `CREATE TABLE IF NOT EXISTS "Project" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "slug" TEXT NOT NULL,
     "title" TEXT NOT NULL,
     "cat" TEXT NOT NULL,
     "desc" TEXT NOT NULL DEFAULT '{}',
     "sticker" TEXT NOT NULL DEFAULT '/stickers/st-portfolio.svg',
     "order" INTEGER NOT NULL DEFAULT 0,
     "active" BOOLEAN NOT NULL DEFAULT true
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "Project_slug_key" ON "Project"("slug")`,
  `CREATE TABLE IF NOT EXISTS "Post" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "slug" TEXT NOT NULL,
     "title" TEXT NOT NULL,
     "cat" TEXT NOT NULL DEFAULT '{}',
     "excerpt" TEXT NOT NULL DEFAULT '{}',
     "body" TEXT NOT NULL DEFAULT '{}',
     "sticker" TEXT NOT NULL DEFAULT '/stickers/st-blog.svg',
     "readMin" INTEGER NOT NULL DEFAULT 6,
     "dateLabel" TEXT NOT NULL DEFAULT '{}',
     "published" BOOLEAN NOT NULL DEFAULT true,
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
     "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "Post_slug_key" ON "Post"("slug")`,
  `CREATE TABLE IF NOT EXISTS "Testimonial" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "name" TEXT NOT NULL,
     "role" TEXT NOT NULL,
     "quote" TEXT NOT NULL,
     "order" INTEGER NOT NULL DEFAULT 0,
     "active" BOOLEAN NOT NULL DEFAULT true
   )`,
  `CREATE TABLE IF NOT EXISTS "Stat" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "value" INTEGER NOT NULL DEFAULT 0,
     "suffix" TEXT NOT NULL DEFAULT '',
     "label" TEXT NOT NULL,
     "sub" TEXT NOT NULL DEFAULT '{}',
     "order" INTEGER NOT NULL DEFAULT 0,
     "active" BOOLEAN NOT NULL DEFAULT true
   )`,
  `CREATE TABLE IF NOT EXISTS "Setting" (
     "id" TEXT NOT NULL PRIMARY KEY DEFAULT 'main',
     "logoUrl" TEXT NOT NULL DEFAULT '/images/logo-r.webp',
     "email" TEXT NOT NULL DEFAULT 'hello@rawandtech.com',
     "phone1" TEXT NOT NULL DEFAULT '+93777638600',
     "phone2" TEXT NOT NULL DEFAULT '+93793268319',
     "whatsapp" TEXT NOT NULL DEFAULT '93777638600',
     "instagram" TEXT NOT NULL DEFAULT 'https://instagram.com/rawandtech',
     "tagline" TEXT NOT NULL DEFAULT '{}',
     "address" TEXT NOT NULL DEFAULT '{}',
     "hours" TEXT NOT NULL DEFAULT '{}'
   )`,

  /* ── Ravand AI SEO Assistant ─────────────────────────── */
  `CREATE TABLE IF NOT EXISTS "SeoAudit" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "trigger" TEXT NOT NULL DEFAULT 'manual',
     "status" TEXT NOT NULL DEFAULT 'running',
     "score" INTEGER NOT NULL DEFAULT 0,
     "pages" INTEGER NOT NULL DEFAULT 0,
     "critical" INTEGER NOT NULL DEFAULT 0,
     "warning" INTEGER NOT NULL DEFAULT 0,
     "opportunity" INTEGER NOT NULL DEFAULT 0,
     "summary" TEXT NOT NULL DEFAULT '{}',
     "error" TEXT NOT NULL DEFAULT '',
     "startedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
     "finishedAt" TIMESTAMPTZ
   )`,
  `CREATE TABLE IF NOT EXISTS "SeoPageResult" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "auditId" TEXT NOT NULL,
     "url" TEXT NOT NULL,
     "status" INTEGER NOT NULL DEFAULT 0,
     "loadMs" INTEGER NOT NULL DEFAULT 0,
     "redirect" BOOLEAN NOT NULL DEFAULT false,
     "title" TEXT NOT NULL DEFAULT '',
     "description" TEXT NOT NULL DEFAULT '',
     "h1" TEXT NOT NULL DEFAULT '',
     "headings" TEXT NOT NULL DEFAULT '[]',
     "images" INTEGER NOT NULL DEFAULT 0,
     "imagesNoAlt" INTEGER NOT NULL DEFAULT 0,
     "internalLinks" INTEGER NOT NULL DEFAULT 0,
     "externalLinks" INTEGER NOT NULL DEFAULT 0,
     "canonical" TEXT NOT NULL DEFAULT '',
     "metaRobots" TEXT NOT NULL DEFAULT '',
     "og" BOOLEAN NOT NULL DEFAULT false,
     "twitter" BOOLEAN NOT NULL DEFAULT false,
     "jsonLd" BOOLEAN NOT NULL DEFAULT false,
     "lang" TEXT NOT NULL DEFAULT '',
     "viewport" BOOLEAN NOT NULL DEFAULT false,
     "wordCount" INTEGER NOT NULL DEFAULT 0,
     "contentText" TEXT NOT NULL DEFAULT '',
     "issues" TEXT NOT NULL DEFAULT '[]'
   )`,
  `CREATE INDEX IF NOT EXISTS "SeoPageResult_auditId_idx" ON "SeoPageResult"("auditId")`,
  `CREATE TABLE IF NOT EXISTS "SeoIssue" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "auditId" TEXT,
     "pageUrl" TEXT NOT NULL DEFAULT '',
     "code" TEXT NOT NULL,
     "severity" TEXT NOT NULL,
     "risk" TEXT NOT NULL DEFAULT 'medium',
     "title" TEXT NOT NULL,
     "why" TEXT NOT NULL DEFAULT '',
     "fix" TEXT NOT NULL DEFAULT '',
     "status" TEXT NOT NULL DEFAULT 'open',
     "source" TEXT NOT NULL DEFAULT 'rules',
     "fixPayload" TEXT NOT NULL DEFAULT '{}',
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
     "resolvedAt" TIMESTAMPTZ
   )`,
  `CREATE INDEX IF NOT EXISTS "SeoIssue_code_page_idx" ON "SeoIssue"("code", "pageUrl")`,
  `CREATE TABLE IF NOT EXISTS "SeoKeyword" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "keyword" TEXT NOT NULL,
     "pageUrl" TEXT NOT NULL DEFAULT '/',
     "lang" TEXT NOT NULL DEFAULT 'en',
     "notes" TEXT NOT NULL DEFAULT '',
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "SeoKeyword_keyword_pageUrl_key" ON "SeoKeyword"("keyword", "pageUrl")`,
  `CREATE TABLE IF NOT EXISTS "SeoOverride" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "path" TEXT NOT NULL DEFAULT '/',
     "field" TEXT NOT NULL,
     "value" TEXT NOT NULL,
     "active" BOOLEAN NOT NULL DEFAULT true,
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "SeoOverride_path_field_key" ON "SeoOverride"("path", "field")`,
  `CREATE TABLE IF NOT EXISTS "SeoChange" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "issueId" TEXT,
     "targetType" TEXT NOT NULL,
     "targetRef" TEXT NOT NULL DEFAULT '',
     "oldValue" TEXT NOT NULL DEFAULT '',
     "newValue" TEXT NOT NULL DEFAULT '',
     "reason" TEXT NOT NULL DEFAULT '',
     "status" TEXT NOT NULL DEFAULT 'applied',
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS "SeoTaskRun" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "task" TEXT NOT NULL,
     "status" TEXT NOT NULL,
     "trigger" TEXT NOT NULL DEFAULT 'manual',
     "log" TEXT NOT NULL DEFAULT '',
     "startedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
     "finishedAt" TIMESTAMPTZ
   )`,
  `CREATE TABLE IF NOT EXISTS "SeoReport" (
     "id" TEXT NOT NULL PRIMARY KEY,
     "period" TEXT NOT NULL,
     "summary" TEXT NOT NULL DEFAULT '{}',
     "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS "SeoSetting" (
     "id" TEXT NOT NULL PRIMARY KEY DEFAULT 'main',
     "baseUrl" TEXT NOT NULL DEFAULT '',
     "psiData" TEXT NOT NULL DEFAULT '{}'
   )`,
];

async function schemaComplete(): Promise<boolean> {
  /* the "last" table of the bootstrap list — exists ⇒ everything does */
  const rows = (await db.$queryRawUnsafe<unknown[]>(
    `SELECT to_regclass('public."SeoSetting"') IS NOT NULL AS ok`
  )) as { ok: boolean }[];
  return Boolean(rows[0]?.ok);
}

async function seedIfEmpty(): Promise<void> {
  /* settings singleton — real contact facts, never blank */
  await db.setting.upsert({ where: { id: "main" }, update: {}, create: { ...SEED_SETTING } });

  if ((await db.service.count()) === 0) {
    await db.service.createMany({
      data: SEED_SERVICES.map((s) => ({ ...s, title: J(s.title), desc: J(s.desc) })),
    });
  }
  if ((await db.project.count()) === 0) {
    await db.project.createMany({
      data: SEED_PROJECTS.map((p) => ({ ...p, title: J(p.title), cat: J(p.cat), desc: J(p.desc) })),
    });
  }
  if ((await db.post.count()) === 0) {
    await db.post.createMany({
      data: SEED_POSTS.map((p) => ({
        ...p,
        title: J(p.title),
        cat: J(p.cat),
        excerpt: J(p.excerpt),
        body: J(p.body),
        dateLabel: J(p.dateLabel),
      })),
    });
  }
  if ((await db.testimonial.count()) === 0) {
    await db.testimonial.createMany({
      data: SEED_TESTIMONIALS.map((t) => ({ ...t, role: J(t.role), quote: J(t.quote) })),
    });
  }
  if ((await db.stat.count()) === 0) {
    await db.stat.createMany({
      data: SEED_STATS.map((s) => ({ ...s, label: J(s.label), sub: J(s.sub) })),
    });
  }
}

async function bootstrap(): Promise<void> {
  const configError = dbConfigError();
  if (configError) throw configError;

  if (!(await schemaComplete())) {
    for (const stmt of SCHEMA_SQL) {
      await db.$executeRawUnsafe(stmt);
    }
  }
  await seedIfEmpty();
}

/**
 * Call at the top of every API route that touches the database.
 * Runs at most once per server process; concurrent callers share
 * the same promise. If bootstrap fails (e.g. transient network),
 * the next request retries.
 */
export function ensureDb(): Promise<void> {
  if (!globalForDb.rvSchemaReady) {
    globalForDb.rvSchemaReady = bootstrap().catch((err) => {
      globalForDb.rvSchemaReady = undefined; // allow retry
      throw err;
    });
  }
  return globalForDb.rvSchemaReady;
}
