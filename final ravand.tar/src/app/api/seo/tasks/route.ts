import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { runDueTasks, runTask, taskStatuses } from "@/lib/seo/tasks";
import type { TextLang } from "@/lib/seo/audit-texts";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const RunSchema = z.object({
  task: z.enum(["daily", "weekly", "monthly", "due"]).default("due"),
  lang: z.enum(["fa", "en"]).default("en"),
});

/* GET /api/seo/tasks — schedule status + run history (admin only). */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    await ensureDb();
    const [statuses, history] = await Promise.all([
      taskStatuses(),
      db.seoTaskRun.findMany({ orderBy: { startedAt: "desc" }, take: 20 }),
    ]);
    return NextResponse.json({ ok: true, statuses, history });
  } catch (error) {
    console.error("[seo/tasks] list failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}

/* POST /api/seo/tasks — run due tasks or one specific task.
   Authorized by admin session OR x-cron-secret header (scheduler). */
export async function POST(req: Request) {
  if (!(await guard(req, { allowCron: true }))) return deny();
  const rl = rateLimit(`seo-tasks-run:${clientIp(req)}`, 4, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown = {};
  try {
    body = await req.json();
  } catch {
    /* empty body → due */
  }
  const parsed = RunSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");
  const lang: TextLang = parsed.data.lang === "fa" ? "fa" : "en";

  try {
    if (parsed.data.task === "due") {
      const result = await runDueTasks("schedule", lang);
      return NextResponse.json({ ok: true, ...result });
    }
    const result = await runTask(parsed.data.task, "manual", lang);
    return NextResponse.json({ ok: true, ran: [{ task: parsed.data.task, ok: result.ok }], log: result.log });
  } catch (error) {
    console.error("[seo/tasks] run failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
