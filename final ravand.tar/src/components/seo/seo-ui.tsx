"use client";

import { useState, type ReactNode } from "react";
import { AlertTriangle, CheckCircle2, CircleDashed, Loader2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import type { SeoLang } from "./seo-strings";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — shared UI primitives.
   Brand-consistent with Ravand Tech (navy / brand blue / teal), fully
   responsive, RTL-friendly (logical properties via Tailwind).
   ------------------------------------------------------------------ */

export type Sev = "critical" | "warning" | "opportunity";
export type IssueStatus = "open" | "approved" | "applied" | "ignored" | "resolved";

const SEV_STYLES: Record<string, string> = {
  critical: "bg-red-100 text-red-800 border-red-200",
  warning: "bg-amber-100 text-amber-900 border-amber-200",
  opportunity: "bg-teal-100 text-teal-900 border-teal-200",
  ok: "bg-emerald-100 text-emerald-800 border-emerald-200",
  info: "bg-slate-100 text-slate-700 border-slate-200",
};

export function Badge({ kind, children }: { kind: string; children: ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        SEV_STYLES[kind] ?? SEV_STYLES.info
      )}
    >
      {children}
    </span>
  );
}

export function SevBadge({ sev, label }: { sev: string; label: string }) {
  const icon =
    sev === "critical" ? (
      <XCircle className="size-3" />
    ) : sev === "warning" ? (
      <AlertTriangle className="size-3" />
    ) : (
      <CircleDashed className="size-3" />
    );
  return (
    <Badge kind={sev}>
      {icon}
      {label}
    </Badge>
  );
}

export function StatusBadge({ status, label }: { status: string; label: string }) {
  const kind =
    status === "applied" || status === "resolved"
      ? "ok"
      : status === "ignored"
        ? "info"
        : status === "open"
          ? "critical"
          : "warning";
  return <Badge kind={kind}>{label}</Badge>;
}

export function CheckRow({
  label,
  ok,
  okLabel,
  badLabel,
  naLabel,
  detail,
}: {
  label: string;
  ok: boolean | null;
  okLabel: string;
  badLabel: string;
  naLabel: string;
  detail?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5">
      <div className="min-w-0">
        <p className="truncate text-sm font-medium text-ink">{label}</p>
        {detail ? <p className="mt-0.5 truncate text-xs text-ink-soft">{detail}</p> : null}
      </div>
      <Badge kind={ok === null ? "info" : ok ? "ok" : "critical"}>
        {ok === null ? naLabel : ok ? okLabel : badLabel}
      </Badge>
    </div>
  );
}

export function SeoCard({
  title,
  icon: Icon,
  action,
  children,
  className,
}: {
  title?: string;
  icon?: React.ComponentType<{ className?: string }>;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "rounded-card border border-hairline bg-white p-4 shadow-[0_1px_2px_rgba(15,47,99,0.04)] sm:p-6",
        className
      )}
    >
      {title ? (
        <header className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="flex min-w-0 items-center gap-2 font-display text-base font-semibold text-brand-deep">
            {Icon ? <Icon className="size-4.5 shrink-0 text-brand" aria-hidden /> : null}
            {title}
          </h3>
          {action ? <div className="flex min-w-0 flex-wrap">{action}</div> : null}
        </header>
      ) : null}
      {children}
    </section>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "default",
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  tone?: "default" | "critical" | "warning" | "opportunity" | "ok";
}) {
  const toneClass =
    tone === "critical"
      ? "text-red-700"
      : tone === "warning"
        ? "text-amber-700"
        : tone === "opportunity"
          ? "text-teal-700"
          : tone === "ok"
            ? "text-emerald-700"
            : "text-brand-deep";
  return (
    <div className="rounded-card border border-hairline bg-white p-4">
      <p className="text-xs font-medium text-ink-soft">{label}</p>
      <p className={cn("mt-1 font-display text-2xl font-bold tabular-nums", toneClass)}>{value}</p>
      {hint ? <p className="mt-0.5 text-xs text-ink-soft">{hint}</p> : null}
    </div>
  );
}

export function ScoreRing({ score, label }: { score: number; label?: string }) {
  const color = score >= 80 ? "#059669" : score >= 50 ? "#d97706" : "#dc2626";
  const circumference = 2 * Math.PI * 42;
  const offset = circumference - (Math.max(0, Math.min(100, score)) / 100) * circumference;
  return (
    <div className="relative grid size-28 place-items-center" role="img" aria-label={label ?? `${score}`}>
      <svg viewBox="0 0 100 100" className="size-28 -rotate-90">
        <circle cx="50" cy="50" r="42" fill="none" stroke="#e8ecf3" strokeWidth="9" />
        <circle
          cx="50"
          cy="50"
          r="42"
          fill="none"
          stroke={color}
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-[stroke-dashoffset] duration-700"
        />
      </svg>
      <div className="absolute text-center">
        <span className="font-display text-2xl font-bold tabular-nums text-brand-deep">{score}</span>
        {label ? <span className="block text-[10px] text-ink-soft">{label}</span> : null}
      </div>
    </div>
  );
}

export function EmptyState({ icon: Icon, text, hint }: { icon: React.ComponentType<{ className?: string }>; text: string; hint?: string }) {
  return (
    <div className="grid place-items-center rounded-card border border-dashed border-hairline bg-surface px-6 py-10 text-center">
      <Icon className="size-8 text-ink-soft/60" aria-hidden />
      <p className="mt-3 text-sm font-medium text-ink">{text}</p>
      {hint ? <p className="mt-1 max-w-sm text-xs text-ink-soft">{hint}</p> : null}
    </div>
  );
}

export function Loading({ label }: { label: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-10 text-sm text-ink-soft">
      <Loader2 className="size-4 animate-spin" aria-hidden />
      {label}
    </div>
  );
}

/** Approval dialog — shows old → new for MEDIUM-risk fixes. */
export function ApplyDialog({
  open,
  onClose,
  onConfirm,
  title,
  desc,
  oldValue,
  newValue,
  labels,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  desc: string;
  oldValue: string;
  newValue: string;
  labels: { old: string; new: string; confirm: string; cancel: string };
}) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="rounded-card sm:max-w-md" dir="auto">
        <DialogHeader>
          <DialogTitle className="font-display text-brand-deep">{title}</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-ink-soft">{desc}</p>
        <div className="grid gap-2 rounded-card bg-surface p-3 text-sm">
          <div>
            <span className="text-xs font-medium text-ink-soft">{labels.old}:</span>
            <p className="mt-0.5 break-words text-ink">{oldValue || "—"}</p>
          </div>
          <div>
            <span className="text-xs font-medium text-ink-soft">{labels.new}:</span>
            <p className="mt-0.5 break-words font-medium text-brand">{newValue || "—"}</p>
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="cursor-pointer rounded-pill">
            {labels.cancel}
          </Button>
          <Button onClick={onConfirm} className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep">
            {labels.confirm}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Confirm dialog (generic yes/no). */
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  desc,
  confirmLabel,
  cancelLabel,
  danger,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  desc?: string;
  confirmLabel: string;
  cancelLabel: string;
  danger?: boolean;
}) {
  return (
    <AlertDialog open={open} onOpenChange={(v) => !v && onClose()}>
      <AlertDialogContent className="rounded-card" dir="auto">
        <AlertDialogHeader>
          <AlertDialogTitle className="font-display text-brand-deep">{title}</AlertDialogTitle>
          {desc ? <AlertDialogDescription>{desc}</AlertDialogDescription> : null}
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="cursor-pointer rounded-pill">{cancelLabel}</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className={cn("cursor-pointer rounded-pill", danger ? "bg-red-600 text-white hover:bg-red-700" : "bg-brand text-white hover:bg-brand-deep")}
          >
            {confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

/** Small tab helper — keeps active state accessible. */
export function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex shrink-0 cursor-pointer items-center gap-2 rounded-pill px-3.5 py-2 text-sm font-medium transition-colors",
        active ? "bg-brand-deep text-white" : "text-ink-soft hover:bg-surface hover:text-ink"
      )}
    >
      {children}
    </button>
  );
}

export interface SeoTabProps {
  lang: SeoLang;
  t: (key: string) => string;
  dir: "rtl" | "ltr";
}

/** Hook-ish helper for local dialog state in tabs. */
export function useToggle(initial = false): [boolean, () => void, () => void] {
  const [on, setOn] = useState(initial);
  return [on, () => setOn(true), () => setOn(false)];
}

export const CheckCircle = CheckCircle2;
