"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useT } from "@/lib/i18n";
import { useContent } from "@/lib/content";
import { cn } from "@/lib/utils";
import { AgentIcon, WhatsAppIcon } from "./icons";

/**
 * Ravand Smart Assistant — floating customer-support widget.
 * Replaces the old floating WhatsApp button: questions are answered
 * instantly by the backend assistant (/api/chat) which composes every
 * reply from the live site content. WhatsApp stays one tap away for
 * human hand-off.
 */

type Msg = { role: "user" | "assistant"; content: string };

const FALLBACK_WA = "93777638600";

export function SmartAssistant() {
  const { t, lang, isRtl } = useT();
  const { content } = useContent();
  const wa = content?.settings?.whatsapp || FALLBACK_WA;

  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [busy, setBusy] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  /* keep the latest message in view */
  useEffect(() => {
    listRef.current?.scrollTo({
      top: listRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [msgs, busy, open]);

  const send = async (text: string) => {
    const message = text.trim();
    if (!message || busy) return;
    setInput("");
    const history = [...msgs, { role: "user" as const, content: message }];
    setMsgs(history);
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        /* send the recent conversation so the assistant keeps context */
        body: JSON.stringify({
          lang,
          message,
          messages: msgs.slice(-8).map((m) => ({
            role: m.role,
            content: m.content.slice(0, 1500),
          })),
        }),
      });
      const json = await res.json();
      setMsgs((p) => [
        ...p,
        {
          role: "assistant",
          content:
            json?.ok && json.reply
              ? json.reply
              : t("assistant.err"),
        },
      ]);
    } catch {
      setMsgs((p) => [...p, { role: "assistant", content: t("assistant.err") }]);
    } finally {
      setBusy(false);
    }
  };

  const suggestions = [t("assistant.s1"), t("assistant.s2"), t("assistant.s3")];

  return (
    <>
      {/* panel — CSS visibility/transform transition, no unmount cost */}
      <section
        aria-label={t("assistant.title")}
        aria-hidden={!open}
        className={cn(
          "fixed bottom-[calc(6.25rem+env(safe-area-inset-bottom,0px))] end-4 z-[75] flex max-h-[calc(100svh-7.75rem-env(safe-area-inset-bottom,0px))] w-[min(23rem,calc(100vw-2rem))] flex-col overflow-hidden rounded-card border border-hairline bg-white shadow-[0_28px_70px_-18px_rgba(15,47,99,0.45)] transition-[opacity,transform,visibility] duration-300 sm:end-5",
          open
            ? "visible translate-y-0 scale-100 opacity-100"
            : "invisible translate-y-4 scale-[0.97] opacity-0"
        )}
      >
        {/* header */}
        <header className="flex items-center gap-3 bg-brand-deep px-4 py-3.5 text-white">
          <span className="grid size-9 shrink-0 place-items-center rounded-pill bg-white/12">
            <AgentIcon className="size-6" aria-hidden />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium">
              {t("assistant.title")}
            </span>
            <span className="block truncate text-[0.72rem] text-white/65">
              {t("assistant.sub")}
            </span>
          </span>
          <a
            href={`https://wa.me/${wa}`}
            target="_blank"
            rel="noreferrer"
            aria-label={t("assistant.human")}
            title={t("assistant.human")}
            className="grid size-8 shrink-0 place-items-center rounded-pill bg-[#25D366]/90 text-white transition-transform hover:scale-105"
          >
            <WhatsAppIcon className="size-4" />
          </a>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Close"
            className="grid size-8 shrink-0 cursor-pointer place-items-center rounded-pill text-white/70 transition-colors hover:bg-white/10 hover:text-white"
          >
            <X className="size-4" aria-hidden />
          </button>
        </header>

        {/* messages — flexes to fit the panel, never pushes the header off-screen */}
        <div
          ref={listRef}
          role="log"
          aria-live="polite"
          data-lenis-prevent
          className="nice-scroll flex min-h-0 max-h-[24rem] flex-1 flex-col gap-2.5 overflow-y-auto overscroll-contain bg-surface px-3.5 py-4"
        >
          {/* welcome */}
          <Bubble side="ai">
            <span>{t("assistant.welcome")}</span>
          </Bubble>

          {msgs.map((m, i) => (
            <Bubble key={i} side={m.role === "user" ? "me" : "ai"}>
              {m.content}
            </Bubble>
          ))}

          {busy && (
            <Bubble side="ai">
              <span className="flex items-center gap-1.5 py-0.5" aria-label="…">
                {[0, 1, 2].map((d) => (
                  <span
                    key={d}
                    className="anim-dot size-1.5 rounded-pill bg-ink-soft"
                    style={{ animationDelay: `${d * 0.18}s` }}
                  />
                ))}
              </span>
            </Bubble>
          )}
        </div>

        {/* suggestions + composer */}
        {msgs.length === 0 && (
          <div className="flex flex-wrap gap-1.5 border-t border-hairline bg-white px-3.5 pt-3">
            {suggestions.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => void send(s)}
                className="cursor-pointer rounded-pill bg-surface px-3 py-1.5 text-xs font-medium text-brand transition-colors hover:bg-brand hover:text-white"
              >
                {s}
              </button>
            ))}
          </div>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send(input);
          }}
          className="flex items-center gap-2 bg-white px-3.5 py-3 pb-3.5"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t("assistant.ph")}
            maxLength={900}
            aria-label={t("assistant.ph")}
            className="h-10 min-w-0 flex-1 rounded-pill border-hairline bg-surface focus-visible:border-brand-light focus-visible:ring-brand-light/40"
          />
          <Button
            type="submit"
            disabled={busy || !input.trim()}
            aria-label={t("assistant.send")}
            className="size-10 shrink-0 cursor-pointer rounded-pill p-0"
          >
            {busy ? (
              <Loader2 className="size-4 animate-spin" aria-hidden />
            ) : (
              <ArrowUp
                className={cn("size-4", isRtl && "-scale-x-100")}
                aria-hidden
              />
            )}
          </Button>
        </form>
      </section>

      {/* launcher */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={t("assistant.title")}
        aria-expanded={open}
        className="anim-fade-up group fixed bottom-[calc(2rem+env(safe-area-inset-bottom,0px))] end-4 z-[70] flex cursor-pointer items-center gap-2.5 transition-transform duration-300 hover:scale-[1.06] active:scale-95 sm:end-5"
        style={{ animationDelay: "0.9s" }}
      >
        <span className="display-caps pointer-events-none hidden rounded-pill bg-ink px-3.5 py-2 text-xs font-medium uppercase tracking-wide text-white opacity-0 shadow-lg transition-opacity duration-300 group-hover:opacity-100 sm:block">
          {t("assistant.title")}
        </span>
        <span className="relative grid size-14 place-items-center rounded-pill bg-brand-deep text-white shadow-[0_18px_38px_-10px_rgba(15,47,99,0.7)]">
          <span
            aria-hidden
            className="absolute inset-0 rounded-pill bg-brand-deep/40 animate-ping"
          />
          <AgentIcon className="relative size-8" aria-hidden />
        </span>
      </button>
    </>
  );
}

/* message bubble */
function Bubble({
  side,
  children,
}: {
  side: "me" | "ai";
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-block max-w-[88%] rounded-2xl px-3.5 py-2.5 text-[0.83rem] leading-relaxed whitespace-pre-wrap",
        side === "me"
          ? "self-end rounded-ee-md bg-brand text-white"
          : "self-start rounded-es-md border border-hairline bg-white text-ink"
      )}
    >
      {children}
    </span>
  );
}
