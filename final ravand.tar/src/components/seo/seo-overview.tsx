"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeftRight, Loader2, Radar, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { fmtDate, seoApi, type OverviewData } from "./seo-api";
import { Badge, EmptyState, Loading, ScoreRing, SeoCard, Stat, type SeoTabProps } from "./seo-ui";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — Overview tab (dashboard section A).
   ------------------------------------------------------------------ */

export function OverviewTab({
  lang,
  t,
  goTab,
}: Omit<SeoTabProps, "dir"> & { goTab: (key: string) => void }) {
  const qc = useQueryClient();

  const overview = useQuery({
    queryKey: ["seo-overview"],
    queryFn: () => seoApi<{ ok: true } & OverviewData>("/api/seo/overview"),
    refetchOnMount: "always",
  });

  const runAudit = useMutation({
    mutationFn: () => seoApi<{ ok: boolean }>("/api/seo/audit", { method: "POST", body: JSON.stringify({ lang }) }),
    onSuccess: () => {
      toast.success(t("s.run_audit"));
      qc.invalidateQueries({ queryKey: ["seo-overview"] });
      goTab("audit");
    },
    onError: (e: Error) => {
      if (e.message === "RATE_LIMITED") toast.error(lang === "fa" ? "هر دقیقه یک بار امکان اجرا است." : "One run per minute — try again shortly.");
      else toast.error(t("s.error"));
    },
  });

  if (overview.isLoading) return <Loading label={t("s.loading")} />;
  if (overview.isError || !overview.data) return <EmptyState icon={ShieldCheck} text={t("s.error")} hint={t("s.retry")} />;

  const d = overview.data;
  const a = d.latestAudit;
  const auditRunning = a?.status === "running";

  return (
    <div className="grid grid-cols-1 gap-4 lg:gap-6">
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <SeoCard className="flex items-center gap-4 md:col-span-2 xl:col-span-1">
          <ScoreRing score={a?.status === "done" ? a.score : 0} label={t("s.of_100")} />
          <div className="min-w-0">
            <p className="text-xs font-medium text-ink-soft">{t("s.health_score")}</p>
            <p className="mt-1 text-sm font-medium text-ink">
              {a ? fmtDate(a.finishedAt ?? a.startedAt, lang) : t("s.no_audit")}
            </p>
            <p className="text-xs text-ink-soft">{d.auditsCount > 0 ? `${d.auditsCount} × ${t("s.tab_audit")}` : ""}</p>
          </div>
        </SeoCard>
        <Stat label={t("s.critical")} value={a?.critical ?? "—"} tone="critical" />
        <Stat label={t("s.warning")} value={a?.warning ?? "—"} tone="warning" />
        <Stat label={t("s.opportunity")} value={a?.opportunity ?? "—"} tone="opportunity" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Stat label={t("s.pages_analyzed")} value={a?.pages ?? 0} />
        <Stat label={t("s.keywords_count")} value={d.keywords} />
        <Stat label={t("s.applied_fixes")} value={d.issues.applied} tone="ok" />
        <Stat
          label={t("s.next_scheduled")}
          value={d.nextScheduled ? fmtDate(d.nextScheduled, lang) : t("s.not_set")}
          hint={d.settings.cronSecret ? undefined : lang === "fa" ? "CRON_SECRET تنظیم نشده" : undefined}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <SeoCard title={t("s.last_audit")} icon={Radar} className="lg:col-span-2">
          {auditRunning ? (
            <div className="flex items-center gap-2 text-sm text-ink-soft">
              <Loader2 className="size-4 animate-spin" aria-hidden />
              {t("s.running_audit")}
            </div>
          ) : a && a.status === "failed" ? (
            <div className="text-sm text-red-700">
              {t("s.error")} {a.error ? `(${a.error})` : ""}
            </div>
          ) : !a || a.status !== "done" ? (
            <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-medium text-ink">{t("s.no_audit")}</p>
                <p className="mt-1 text-xs text-ink-soft">{t("s.no_audit_d")}</p>
              </div>
              <Button onClick={() => runAudit.mutate()} disabled={runAudit.isPending} className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep">
                {runAudit.isPending ? <Loader2 className="size-4 animate-spin" /> : <Radar className="size-4" />}
                {t("s.audit_now")}
              </Button>
            </div>
          ) : (
            <div className="grid gap-3 text-sm sm:grid-cols-2">
              <div className="flex items-center justify-between gap-2 rounded-card bg-surface px-3 py-2">
                <span className="text-ink-soft">{t("s.last_audit")}</span>
                <span className="font-medium">{fmtDate(a.finishedAt, lang)}</span>
              </div>
              <div className="flex items-center justify-between gap-2 rounded-card bg-surface px-3 py-2">
                <span className="text-ink-soft">{t("s.trigger")}</span>
                <Badge kind="info">{a.trigger === "manual" ? t("s.manual_trigger") : t("s.schedule_trigger")}</Badge>
              </div>
              <div className="flex items-center justify-between gap-2 sm:col-span-2">
                <Button variant="outline" onClick={() => goTab("audit")} className="cursor-pointer rounded-pill">
                  <Radar className="size-4" aria-hidden />
                  {t("s.tab_audit")}
                </Button>
                <Button
                  onClick={() => runAudit.mutate()}
                  disabled={runAudit.isPending}
                  className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
                >
                  {runAudit.isPending ? <Loader2 className="size-4 animate-spin" /> : <Radar className="size-4" aria-hidden />}
                  {t("s.run_audit")}
                </Button>
              </div>
            </div>
          )}
        </SeoCard>

        <SeoCard title={t("s.recent_activity")} icon={ArrowLeftRight} className="max-h-96 overflow-y-auto">
          {d.recentChanges.length === 0 ? (
            <p className="py-6 text-center text-sm text-ink-soft">—</p>
          ) : (
            <ul className="grid gap-2.5">
              {d.recentChanges.map((c) => (
                <li key={c.id} className="rounded-card border border-hairline p-3 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-ink">{c.targetRef}</span>
                    <Badge kind={c.status === "applied" ? "ok" : c.status === "rolled_back" ? "warning" : "info"}>
                      {c.status === "applied" ? t("s.st_applied") : c.status === "rolled_back" ? t("s.rollback") : c.status}
                    </Badge>
                  </div>
                  <p className="mt-1 line-clamp-2 text-ink-soft">{c.reason || c.newValue}</p>
                  <p className="mt-1 text-[10px] text-ink-soft">{fmtDate(c.createdAt, lang)}</p>
                </li>
              ))}
            </ul>
          )}
        </SeoCard>
      </div>
    </div>
  );
}
