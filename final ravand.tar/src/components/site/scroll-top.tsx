"use client";

import { useEffect, useState } from "react";
import { ArrowUp } from "lucide-react";
import { scrollToTop } from "@/lib/lenis";

/**
 * Scroll-to-top control — appears after the visitor scrolls past the
 * hero, opposite corner from the assistant launcher. Stays mounted
 * and toggles with a CSS transition (no remount, cheap on INP).
 */
export function ScrollTop() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 480);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <button
      type="button"
      onClick={scrollToTop}
      aria-label="Scroll to top"
      aria-hidden={!show}
      tabIndex={show ? 0 : -1}
      className={`fixed bottom-5 start-5 z-[70] grid size-11 cursor-pointer place-items-center rounded-pill border border-hairline bg-white/90 text-brand shadow-[0_14px_30px_-12px_rgba(15,47,99,0.45)] backdrop-blur-sm transition-[opacity,transform,background-color,color] duration-300 hover:bg-brand-deep hover:text-white hover:-translate-y-1 active:scale-95 ${
        show
          ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
          : "pointer-events-none translate-y-3 scale-[0.6] opacity-0"
      }`}
    >
      <ArrowUp className="size-4.5" aria-hidden />
    </button>
  );
}
