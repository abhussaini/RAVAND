import fs from "fs";
import path from "path";
import { db, ensureDb } from "@/lib/db";
import { parseL10n } from "@/app/api/content/route";
import { getBaseUrl, approvedHosts, safeFetch, KNOWN_ROUTES, routeFromHash } from "./config";
import { extractPage, parseRobots, parseSitemap, type PageExtract } from "./extract";
import {
  issueText,
  issueRisk,
  issueAuto,
  issueSeverity,
  type TextLang,
  type Sev,
} from "./audit-texts";
import { cleanText } from "./assistant";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — audit engine.

   REAL checks only (no fabricated results):
   1.  Homepage server HTML  → status, title, description, headings,
       images/alt, links, canonical, robots meta, OG/Twitter, JSON-LD,
       lang, viewport, word count
   2.  robots.txt            → availability + light validation
   3.  sitemap.xml           → availability + URL/host validation
   4.  HTTPS                 → base URL scheme
   5.  Hash-route (SPA)      → indexability note from the actual
       architecture (single server-rendered shell)
   6.  Database content      → posts/services L10n completeness, thin
       content, duplicate titles, missing excerpts
   7.  Link checks (bounded) → hash links vs real posts/routes,
       internal assets, external links (HEAD)
   8.  Optional AI enrichment of recommendation texts (never blocks)
   ------------------------------------------------------------------ */

export interface Finding {
  code: string;
  pageUrl: string;
  vars?: Record<string, string | number>;
  severity?: Sev;
  fixPayload?: Record<string, unknown>;
}

interface UpsertResult {
  created: boolean;
  skipped: boolean;
}

const MAX_EXTERNAL_CHECKS = 12;
const MAX_INTERNAL_ASSET_CHECKS = 10;

const isLocalBase = (base: string) => /localhost|127\.0\.0\.1/.test(base);

/** Collapse duplicate findings with the same code+pageUrl (e.g. one per
    broken asset) so counts and score reflect distinct problems. */
function dedupeFindings(findings: Finding[]): Finding[] {
  const map = new Map<string, Finding>();
  for (const f of findings) {
    const key = `${f.code}|${f.pageUrl}`;
    const prev = map.get(key);
    if (!prev || (f.fixPayload && !prev.fixPayload)) map.set(key, f);
  }
  return [...map.values()];
}

function suggestTitle(ex: PageExtract): string {
  const h1 = ex.headings.find((h) => h.tag === "h1")?.text ?? "";
  const candidate = h1 ? `${h1} | Ravand Tech` : "Ravand Tech — Web Design & IT Solutions";
  return cleanText(candidate, 60);
}

function suggestDescription(ex: PageExtract): string {
  const t = ex.text.replace(/\s+/g, " ").trim();
  return cleanText(t, 155) || "Ravand Tech — modern websites, custom software and IT solutions in Afghanistan. From idea to market.";
}

/* ---------- link helpers ---------- */

function postExists(slug: string, slugs: Set<string>): boolean {
  return slugs.has(slug);
}

async function checkLocalAsset(urlPath: string): Promise<boolean> {
  try {
    const rel = decodeURIComponent(urlPath.split("?")[0]);
    const file = path.join(process.cwd(), "public", rel);
    return fs.existsSync(file);
  } catch {
    return true; /* cannot check — do not report a false positive */
  }
}

/* ---------- issue persistence (dedup by code+pageUrl) ---------- */

async function upsertIssue(
  f: Finding,
  auditId: string,
  lang: TextLang
): Promise<UpsertResult> {
  const severity = f.severity ?? issueSeverity(f.code);
  const vars = f.vars ?? {};
  const text = issueText(f.code, lang, vars);
  const payload = f.fixPayload ? JSON.stringify(f.fixPayload) : "{}";

  const existing = await db.seoIssue.findFirst({
    where: { code: f.code, pageUrl: f.pageUrl },
    orderBy: { createdAt: "desc" },
  });

  if (!existing) {
    await db.seoIssue.create({
      data: {
        auditId,
        pageUrl: f.pageUrl,
        code: f.code,
        severity,
        risk: issueRisk(f.code),
        title: text.title,
        why: text.why,
        fix: text.fix,
        status: "open",
        fixPayload: payload,
      },
    });
    return { created: true, skipped: false };
  }

  if (existing.status === "ignored") return { created: false, skipped: true };

  if (existing.status === "resolved") {
    /* regressed — reopen with fresh evidence */
    await db.seoIssue.update({
      where: { id: existing.id },
      data: {
        status: "open",
        auditId,
        severity,
        risk: issueRisk(f.code),
        title: text.title,
        why: text.why,
        fix: text.fix,
        fixPayload: payload,
        resolvedAt: null,
      },
    });
    return { created: false, skipped: false };
  }

  await db.seoIssue.update({
    where: { id: existing.id },
    data: {
      auditId,
      severity,
      risk: issueRisk(f.code),
      title: text.title,
      why: text.why,
      fix: text.fix,
      fixPayload: payload,
    },
  });
  return { created: false, skipped: false };
}

/* ---------- the audit ---------- */

export interface AuditOutcome {
  auditId: string;
  status: "done" | "failed";
  score: number;
  critical: number;
  warning: number;
  opportunity: number;
  pages: number;
  error?: string;
}

export async function runAudit(
  trigger: "manual" | "daily" | "weekly" | "monthly",
  lang: TextLang = "en"
): Promise<AuditOutcome> {
  await ensureDb();
  const audit = await db.seoAudit.create({ data: { trigger, status: "running" } });
  const auditId = audit.id;

  try {
    const base = await getBaseUrl();
    const allowed = approvedHosts(base);
    const isHttps = base.startsWith("https://");
    const findings: Finding[] = [];
    const summary: Record<string, unknown> = { baseUrl: base, https: isLocalBase(base) ? null : isHttps, trigger };
    const startedAll = Date.now();

    /* ---------- 1. homepage shell ---------- */
    const shell = await safeFetch(`${base}/`, base, allowed, { timeoutMs: 12_000 });
    let ex: PageExtract | null = null;

    if (shell.status !== 200 || !shell.body) {
      findings.push({ code: "SITE_UNREACHABLE", pageUrl: "", severity: "critical" });
      summary.site = { status: shell.status, error: shell.error ?? "empty body", ms: shell.ms };
    } else {
      ex = extractPage(shell.body, base);
      const pageIssues: { code: string; severity: string; message: string }[] = [];

      /* title */
      const tLen = ex.title.length;
      if (tLen === 0) {
        findings.push({
          code: "MISSING_TITLE",
          pageUrl: "/",
          severity: "critical",
          fixPayload: { type: "override", field: "title", value: suggestTitle(ex) },
        });
      } else if (tLen < 25) {
        findings.push({
          code: "SHORT_TITLE",
          pageUrl: "/",
          vars: { value: tLen },
          fixPayload: { type: "override", field: "title", value: suggestTitle(ex) },
        });
      } else if (tLen > 65) {
        findings.push({
          code: "LONG_TITLE",
          pageUrl: "/",
          vars: { value: tLen },
          fixPayload: { type: "override", field: "title", value: cleanText(ex.title, 60) },
        });
      }

      /* description */
      const dLen = ex.description.length;
      if (dLen === 0) {
        findings.push({
          code: "MISSING_DESCRIPTION",
          pageUrl: "/",
          severity: "critical",
          fixPayload: { type: "override", field: "description", value: suggestDescription(ex) },
        });
      } else if (dLen < 50) {
        findings.push({
          code: "SHORT_DESCRIPTION",
          pageUrl: "/",
          vars: { value: dLen },
          fixPayload: { type: "override", field: "description", value: suggestDescription(ex) },
        });
      } else if (dLen > 165) {
        findings.push({
          code: "LONG_DESCRIPTION",
          pageUrl: "/",
          vars: { value: dLen },
          fixPayload: { type: "override", field: "description", value: cleanText(ex.description, 155) },
        });
      }

      /* headings */
      if (ex.h1Count !== 1) {
        findings.push({ code: "H1_COUNT", pageUrl: "/", vars: { count: ex.h1Count } });
      }

      /* indexing */
      if (ex.metaRobots.includes("noindex")) {
        findings.push({ code: "ROBOTS_NOINDEX", pageUrl: "/", severity: "critical" });
      }
      if (!ex.canonical) {
        /* deliberately pending until the production domain is confirmed */
        findings.push({ code: "CANONICAL_PENDING", pageUrl: "/" });
      }

      /* mobile / language */
      if (!ex.viewport) findings.push({ code: "VIEWPORT_MISSING", pageUrl: "/" });
      if (!ex.lang) findings.push({ code: "LANG_MISSING", pageUrl: "/" });

      /* images */
      const noAlt = ex.images.filter((i) => !i.alt.trim()).length;
      if (noAlt > 0) {
        findings.push({ code: "IMAGES_MISSING_ALT", pageUrl: "/", vars: { count: noAlt } });
      }

      /* social + structured data */
      if (!ex.og || !ex.twitter) {
        if (!ex.og) {
          findings.push({
            code: "OG_MISSING",
            pageUrl: "/",
            fixPayload: {
              type: "override",
              field: "ogTitle",
              value: cleanText(ex.title, 90),
              ogDescription: cleanText(ex.description, 200),
            },
          });
        }
        if (!ex.twitter) findings.push({ code: "TWITTER_MISSING", pageUrl: "/" });
      }
      if (!ex.jsonLdTypes.length) findings.push({ code: "JSONLD_MISSING", pageUrl: "/" });
      else if (!ex.jsonLdValid) findings.push({ code: "JSONLD_INVALID", pageUrl: "/" });

      /* content */
      if (ex.wordCount < 300) {
        findings.push({ code: "THIN_CONTENT", pageUrl: "/", vars: { count: ex.wordCount } });
      }

      summary.site = {
        status: shell.status,
        ms: shell.ms,
        redirected: shell.redirected,
        title: cleanText(ex.title, 200),
        titleLength: tLen,
        descriptionLength: dLen,
        h1Count: ex.h1Count,
        headings: ex.headings.slice(0, 24),
        images: ex.images.length,
        imagesNoAlt: noAlt,
        internalLinks: ex.links.filter((l) => l.kind !== "external").length,
        externalLinks: ex.links.filter((l) => l.kind === "external").length,
        wordCount: ex.wordCount,
        lang: ex.lang,
        viewport: ex.viewport,
        og: ex.og,
        twitter: ex.twitter,
        jsonLdTypes: ex.jsonLdTypes.slice(0, 8),
        canonical: cleanText(ex.canonical, 200),
      };
      pageIssues.push(
        ...findings
          .filter((f) => f.pageUrl === "/")
          .map((f) => ({
            code: f.code,
            severity: f.severity ?? issueSeverity(f.code),
            message: issueText(f.code, "en", f.vars).title,
          }))
      );

      await db.seoPageResult.create({
        data: {
          auditId,
          url: "/",
          status: shell.status,
          loadMs: shell.ms,
          redirect: shell.redirected,
          title: cleanText(ex.title, 250),
          description: cleanText(ex.description, 400),
          h1: cleanText(ex.headings.find((h) => h.tag === "h1")?.text ?? "", 250),
          headings: JSON.stringify(ex.headings.slice(0, 40)),
          images: ex.images.length,
          imagesNoAlt: noAlt,
          internalLinks: ex.links.filter((l) => l.kind !== "external").length,
          externalLinks: ex.links.filter((l) => l.kind === "external").length,
          canonical: cleanText(ex.canonical, 200),
          metaRobots: cleanText(ex.metaRobots, 120),
          og: ex.og,
          twitter: ex.twitter,
          jsonLd: ex.jsonLdTypes.length > 0,
          lang: cleanText(ex.lang, 12),
          viewport: ex.viewport,
          wordCount: ex.wordCount,
          contentText: cleanText(ex.text, 4000),
          issues: JSON.stringify(pageIssues),
        },
      });
    }

    /* ---------- 2. HTTPS (dev localhost is exempt) ---------- */
    if (!isHttps && !isLocalBase(base)) {
      findings.push({ code: "HTTP_NOT_HTTPS", pageUrl: "", severity: "critical" });
    }

    /* ---------- 3. robots.txt ---------- */
    const robots = await safeFetch(`${base}/robots.txt`, base, allowed, { timeoutMs: 6000 });
    if (robots.status !== 200 || !robots.body || !/user-agent/i.test(robots.body)) {
      findings.push({ code: "ROBOTS_MISSING", pageUrl: "" });
      summary.robots = { status: robots.status, ok: false };
    } else {
      const rb = parseRobots(robots.body);
      if (!rb.hasSitemap) findings.push({ code: "ROBOTS_NO_SITEMAP", pageUrl: "" });
      summary.robots = { ...rb, status: robots.status };
    }

    /* ---------- 4. sitemap.xml ---------- */
    const sm = await safeFetch(`${base}/sitemap.xml`, base, allowed, { timeoutMs: 8000 });
    let sitemapLocs: string[] = [];
    if (sm.status !== 200 || !sm.body || !/<urlset|<sitemapindex/i.test(sm.body)) {
      findings.push({ code: "SITEMAP_MISSING", pageUrl: "", severity: "critical" });
      summary.sitemap = { status: sm.status, count: 0 };
    } else {
      sitemapLocs = parseSitemap(sm.body);
      const mismatch = sitemapLocs.some((u) => {
        try {
          return new URL(u).hostname.toLowerCase() !== new URL(base).hostname.toLowerCase();
        } catch {
          return true;
        }
      });
      if (sitemapLocs.length === 0) findings.push({ code: "SITEMAP_MISSING", pageUrl: "", severity: "critical" });
      else if (mismatch && !isLocalBase(base)) findings.push({ code: "SITEMAP_HOST_MISMATCH", pageUrl: "" });
      summary.sitemap = { status: sm.status, count: sitemapLocs.length, hostMismatch: mismatch };
    }

    /* ---------- 5. hash-route (SPA) indexability note ---------- */
    const sitemapHashes = sitemapLocs
      .filter((u) => u.includes("#"))
      .map((u) => `#${u.split("#")[1] ?? ""}`);
    findings.push({ code: "SPA_HASH_ROUTES", pageUrl: "" });
    summary.spa = { serverRenderedRoutes: ["/"], hashRoutesInSitemap: sitemapHashes.length, knownRoutes: KNOWN_ROUTES.length };

    /* ---------- 6. database content audit ---------- */
    const posts = await db.post.findMany({ where: { published: true } });
    const postSlugs = new Set(posts.map((p) => p.slug));
    const titleSeen = new Map<string, string[]>(); // normalized en title -> ids

    for (const p of posts) {
      const title = parseL10n(p.title);
      const body = parseL10n(p.body);
      const excerpt = parseL10n(p.excerpt);
      const url = `#/blog/${p.slug}`;

      const enTitle = title.en.trim() || title.fa.trim();
      if (enTitle && enTitle.length < 20) {
        findings.push({
          code: "POST_TITLE_SHORT",
          pageUrl: url,
          vars: { value: cleanText(enTitle, 40) },
          fixPayload: {
            type: "resource", model: "post", id: p.id, field: "title", lang: title.en ? "en" : "fa",
            value: cleanText(`${enTitle} — Ravand Tech`, 70),
          },
        });
      }

      if (!excerpt.en.trim() && !excerpt.fa.trim()) {
        findings.push({
          code: "POST_EXCERPT_MISSING",
          pageUrl: url,
          vars: { value: cleanText(enTitle || p.slug, 50) },
          fixPayload: {
            type: "resource", model: "post", id: p.id, field: "excerpt",
            lang: title.en ? "en" : "fa",
            value: cleanText((body.en || body.fa || "").replace(/\s+/g, " ").slice(0, 150) || enTitle, 160),
          },
        });
      }

      const bodyLen = (body.en || body.fa || body.ps || "").length;
      if (bodyLen < 400) {
        findings.push({ code: "POST_BODY_THIN", pageUrl: url, vars: { value: cleanText(enTitle || p.slug, 50) } });
      }

      for (const lg of ["fa", "ps", "en"] as const) {
        if (!title[lg].trim() || !body[lg].trim()) {
          findings.push({
            code: "L10N_MISSING",
            pageUrl: url,
            vars: { field: !title[lg].trim() ? "title" : "body", lang: lg === "fa" ? "Dari" : lg === "ps" ? "Pashto" : "English", value: cleanText(enTitle || p.slug, 50) },
          });
          break; // one flag per post is enough
        }
      }

      const norm = enTitle.toLowerCase().replace(/\s+/g, " ").trim();
      if (norm) {
        const arr = titleSeen.get(norm) ?? [];
        arr.push(p.id);
        titleSeen.set(norm, arr);
        if (arr.length > 1) {
          findings.push({
            code: "DUPLICATE_TITLE",
            pageUrl: url,
            vars: { value: cleanText(enTitle, 60) },
            fixPayload: {
              type: "resource", model: "post", id: p.id, field: "title",
              lang: title.en ? "en" : "fa",
              value: cleanText(`${enTitle} — ${(parseL10n(p.cat).en || "Ravand Tech")}`, 70),
            },
          });
        }
      }
    }
    summary.content = { posts: posts.length };

    /* ---------- 7. link checks (bounded) ---------- */
    if (ex) {
      const hashLinks = ex.links.filter((l) => l.kind === "hash");
      const checkedRoutes = new Set<string>();
      for (const l of hashLinks.slice(0, 40)) {
        const route = routeFromHash(l.href);
        if (!route || checkedRoutes.has(route)) continue;
        checkedRoutes.add(route);
        if (KNOWN_ROUTES.includes(route as (typeof KNOWN_ROUTES)[number])) continue;
        const blogSlug = /^\/blog\/([a-z0-9-]+)$/i.exec(route);
        if (blogSlug) {
          if (!postExists(blogSlug[1], postSlugs)) {
            findings.push({ code: "UNKNOWN_ROUTE_LINK", pageUrl: "/", vars: { value: l.href.slice(0, 80) } });
          }
        } else if (!/^\/blog\//.test(route)) {
          findings.push({ code: "UNKNOWN_ROUTE_LINK", pageUrl: "/", vars: { value: l.href.slice(0, 80) } });
        }
      }

      /* internal assets (images) — local fs check in dev, HEAD on remote */
      const assetUrls = [
        ...ex.images.map((i) => i.src),
      ]
        .filter((s) => s.startsWith("/") && !s.startsWith("//") && !s.startsWith("/_next/"))
        .filter((s, i, a) => a.indexOf(s) === i)
        .slice(0, MAX_INTERNAL_ASSET_CHECKS);

      const local = isLocalBase(base);
      const brokenAssets: string[] = [];
      for (const asset of assetUrls) {
        if (local) {
          if (!(await checkLocalAsset(asset))) brokenAssets.push(asset);
        } else {
          const r = await safeFetch(`${base}${asset}`, base, allowed, { method: "HEAD", timeoutMs: 5000 });
          if (r.status >= 400) brokenAssets.push(asset);
        }
      }
      for (const b of brokenAssets) {
        findings.push({ code: "INTERNAL_ASSET_BROKEN", pageUrl: "/", vars: { value: b.slice(0, 100) } });
      }
      summary.linkChecks = { assetsChecked: assetUrls.length, brokenAssets };

      /* external links — bounded checks; HEAD first, GET retry on
         failure. Only definitive losses (404/410) count as broken;
         bot-blocks / network errors are reported as unverifiable
         instead of false positives. */
      const externals = [...new Set(ex.links.filter((l) => l.kind === "external").map((l) => l.href))].slice(0, MAX_EXTERNAL_CHECKS);
      const UA = { "User-Agent": "Mozilla/5.0 (compatible; RavandSeoAssistant/1.0)" };
      const brokenExternal: string[] = [];
      const unverifiedExternal: string[] = [];
      for (const href of externals) {
        try {
          const u = new URL(href);
          if (u.protocol !== "http:" && u.protocol !== "https:") continue;
          const r = await fetch(href, { method: "HEAD", redirect: "follow", signal: AbortSignal.timeout(5000), headers: UA });
          let status = r.status;
          try { await r.body?.cancel(); } catch { /* ignore */ }
          if (status >= 400 && status !== 405 && status !== 501) {
            const r2 = await fetch(href, { method: "GET", redirect: "follow", signal: AbortSignal.timeout(8000), headers: UA }).catch(() => null);
            status = r2 ? r2.status : status;
            try { await r2?.body?.cancel(); } catch { /* ignore */ }
          }
          if (status === 404 || status === 410) brokenExternal.push(href);
          else if (status >= 400) unverifiedExternal.push(href);
        } catch {
          unverifiedExternal.push(href);
        }
      }
      for (const b of brokenExternal.slice(0, 5)) {
        findings.push({ code: "EXTERNAL_LINK_BROKEN", pageUrl: "/", vars: { value: b.slice(0, 100) } });
      }
      summary.linkChecks = { ...(summary.linkChecks as Record<string, unknown>), externalChecked: externals.length, brokenExternal, unverifiedExternal };
    }

    /* ---------- 8. persist issues (deduped) ---------- */
    const uniqueFindings = dedupeFindings(findings);
    let created = 0;
    let skipped = 0;
    for (const f of uniqueFindings) {
      const r = await upsertIssue(f, auditId, lang);
      if (r.created) created++;
      if (r.skipped) skipped++;
    }

    /* issues no longer found → mark resolved (verified fixed) */
    const openIssues = await db.seoIssue.findMany({ where: { status: { in: ["open", "approved"] } } });
    const foundKeys = new Set(uniqueFindings.map((f) => `${f.code}|${f.pageUrl}`));
    let resolvedNow = 0;
    for (const issue of openIssues) {
      if (!foundKeys.has(`${issue.code}|${issue.pageUrl}`)) {
        await db.seoIssue.update({
          where: { id: issue.id },
          data: { status: "resolved", resolvedAt: new Date() },
        });
        resolvedNow++;
      }
    }

    /* ---------- 9. score + finish ---------- */
    const critical = uniqueFindings.filter((f) => (f.severity ?? issueSeverity(f.code)) === "critical").length;
    const warning = uniqueFindings.filter((f) => (f.severity ?? issueSeverity(f.code)) === "warning").length;
    const opportunity = uniqueFindings.filter((f) => (f.severity ?? issueSeverity(f.code)) === "opportunity").length;
    const score = critical > 0 && findings.some((f) => f.code === "SITE_UNREACHABLE")
      ? 0
      : Math.max(0, Math.min(100, 100 - critical * 12 - warning * 5 - opportunity * 2));

    summary.issues = { found: uniqueFindings.length, created, skippedIgnored: skipped, resolvedNow };
    summary.durationMs = Date.now() - startedAll;

    await db.seoAudit.update({
      where: { id: auditId },
      data: {
        status: "done",
        score,
        pages: ex ? 1 : 0,
        critical,
        warning,
        opportunity,
        summary: JSON.stringify(summary),
        finishedAt: new Date(),
      },
    });

    return { auditId, status: "done", score, critical, warning, opportunity, pages: ex ? 1 : 0 };
  } catch (error) {
    const msg = error instanceof Error ? error.message.slice(0, 300) : "audit failed";
    await db.seoAudit.update({
      where: { id: auditId },
      data: { status: "failed", error: cleanText(msg, 300), finishedAt: new Date() },
    }).catch(() => undefined);
    return { auditId, status: "failed", score: 0, critical: 0, warning: 0, opportunity: 0, pages: 0, error: msg };
  }
}
