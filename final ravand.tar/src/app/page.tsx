"use client";

import { useEffect } from "react";
import dynamic from "next/dynamic";
import { LangSync } from "@/components/lang-sync";
import { RemScaler } from "@/components/site/rem-scaler";
import { SmoothScroll } from "@/components/site/smooth-scroll";
import { IntroLoader } from "@/components/site/intro-loader";
import { useMounted } from "@/components/site/reveal";
import { ScrollTop } from "@/components/site/scroll-top";
import { ContentProvider } from "@/lib/content";
import { useRoute } from "@/lib/router";
import { useLang } from "@/store/use-lang";
import { useUi } from "@/store/use-ui";
import { HomePage } from "@/components/site/pages/home-page";

/* Code-split chunks — admin, chat widget, overlays and the secondary
   pages are NOT part of the first-load bundle. The home page (LCP)
   stays eager. */
const AdminApp = dynamic(
  () => import("@/components/admin/admin-app").then((m) => ({ default: m.AdminApp })),
  { loading: () => <div className="min-h-screen" /> }
);
const SeoApp = dynamic(
  () => import("@/components/seo/seo-app").then((m) => ({ default: m.SeoApp })),
  { loading: () => <div className="min-h-screen" /> }
);
const MenuOverlay = dynamic(
  () => import("@/components/site/menu-overlay").then((m) => ({ default: m.MenuOverlay }))
);
const ContactModal = dynamic(
  () => import("@/components/site/contact-modal").then((m) => ({ default: m.ContactModal }))
);
const SmartAssistant = dynamic(
  () => import("@/components/site/smart-assistant").then((m) => ({ default: m.SmartAssistant })),
  /* the floating widget renders real markup on the server — with the
     default SSR the client's loading fallback (null) races the chunk
     during hydration and trips a recoverable #418 mismatch */
  { ssr: false }
);
const ServicesPage = dynamic(
  () => import("@/components/site/pages/services-page").then((m) => ({ default: m.ServicesPage })),
  { loading: () => <div className="min-h-[70vh]" /> }
);
const PortfolioPage = dynamic(
  () => import("@/components/site/pages/portfolio-page").then((m) => ({ default: m.PortfolioPage })),
  { loading: () => <div className="min-h-[70vh]" /> }
);
const BlogPage = dynamic(
  () => import("@/components/site/pages/blog-page").then((m) => ({ default: m.BlogPage })),
  { loading: () => <div className="min-h-[70vh]" /> }
);
const PostPage = dynamic(
  () => import("@/components/site/pages/post-page").then((m) => ({ default: m.PostPage })),
  { loading: () => <div className="min-h-[70vh]" /> }
);
const AboutPage = dynamic(
  () => import("@/components/site/pages/about-page").then((m) => ({ default: m.AboutPage })),
  { loading: () => <div className="min-h-[70vh]" /> }
);
const ContactPage = dynamic(
  () => import("@/components/site/pages/contact-page").then((m) => ({ default: m.ContactPage })),
  { loading: () => <div className="min-h-[70vh]" /> }
);

/**
 * Ravand Tech — Web Design & IT Solutions
 * Hash-routed multi-page app inside the single sandbox route:
 *   #/ home · #/services · #/portfolio · #/blog · #/blog/:slug
 *   #/about · #/contact · #/admin (full CRUD dashboard)
 * Content lives in the database (Prisma — SQLite locally, Turso on
 * Netlify) managed by the admin panel; the site falls back to the
 * built-in dictionary.
 */
export default function Page() {
  /* QueryClientProvider lives inside the AdminApp / SeoApp dynamic chunks
     so react-query never ships with the public site bundle. */
  return <AppRouter />;
}

const PUBLIC_PAGES = ["", "services", "portfolio", "blog", "about", "contact"];

/* Hydration-safe mounted flag: the server cannot see the URL hash, so
   the first client render must match it (home branch). After hydration
   the real hash page takes over — kills the hydration mismatch for
   #/admin and #/seo without sacrificing home-page SSR content. */
function AppRouter() {
  const { parts } = useRoute();
  const mounted = useMounted();
  const page = mounted ? (parts[0] ?? "") : "";
  const subPage = mounted ? (parts[1] ?? "") : "";
  const lang = useLang((s) => s.lang);
  const ready = useUi((s) => s.ready);
  const closeContact = useUi((s) => s.closeContact);
  const setMenuOpen = useUi((s) => s.setMenuOpen);

  /* new "page" — start at the top, and close transient overlays.
     Without this, opening the contact modal (or menu) and then
     navigating to #/admin · #/seo and back leaks the open state:
     the modal reappears over the page on return. */
  useEffect(() => {
    window.scrollTo({ top: 0 });
    closeContact();
    setMenuOpen(false);
  }, [page, subPage, closeContact, setMenuOpen]);

  /* admin — own chrome, no site header/footer/loader */
  if (page === "admin") {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <LangSync />
        <RemScaler />
        <AdminApp />
      </div>
    );
  }

  /* Ravand SEO Assistant — protected dashboard, own chrome */
  if (page === "seo") {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <LangSync />
        <SeoApp />
      </div>
    );
  }

  /* public pages */
  const isHome = page === "";
  const known = PUBLIC_PAGES.includes(page);

  return (
    <ContentProvider lang={lang}>
      <LangSync />
      <RemScaler />
      <SmoothScroll />
      {isHome && !ready && <IntroLoader />}

      {/* min-h-screen flex wrapper — makes .page-frame (flex-1) stretch
          to the viewport so the footer sticks to the bottom on short
          pages and is pushed down naturally on long ones */}
      <div className="flex min-h-screen flex-col bg-background">
        <div className="page-frame flex flex-1 flex-col">
          {isHome && <HomePage />}
          {page === "services" && <ServicesPage />}
          {page === "portfolio" && <PortfolioPage />}
          {page === "blog" &&
            (subPage ? <PostPage slug={subPage} /> : <BlogPage />)}
          {page === "about" && <AboutPage />}
          {page === "contact" && <ContactPage />}
          {/* unknown hash → home */}
          {!known && !isHome && <HomePage />}
        </div>
      </div>

      <MenuOverlay />
      <ContactModal />
      <SmartAssistant />
      <ScrollTop />
    </ContentProvider>
  );
}
