"use client";

import type { SeoLang } from "./seo-strings";
import type { IssueStatus } from "./seo-ui";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — client API helpers + shared types.
   ------------------------------------------------------------------ */

export async function seoApi<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON */
  }
  if (!res.ok || (data as { ok?: boolean })?.ok === false) {
    const err = (data as { error?: string })?.error ?? `HTTP_${res.status}`;
    throw new Error(err);
  }
  return data as T;
}

export interface AuditRow {
  id: string;
  trigger: string;
  status: string;
  score: number;
  pages: number;
  critical: number;
  warning: number;
  opportunity: number;
  summary: string;
  error: string;
  startedAt: string;
  finishedAt: string | null;
}

export interface PageResultRow {
  id: string;
  auditId: string;
  url: string;
  status: number;
  loadMs: number;
  redirect: boolean;
  title: string;
  description: string;
  h1: string;
  images: number;
  imagesNoAlt: number;
  internalLinks: number;
  externalLinks: number;
  canonical: string;
  metaRobots: string;
  og: boolean;
  twitter: boolean;
  jsonLd: boolean;
  lang: string;
  viewport: boolean;
  wordCount: number;
  issues: string;
}

export interface IssueRow {
  id: string;
  pageUrl: string;
  code: string;
  severity: "critical" | "warning" | "opportunity";
  risk: "low" | "medium" | "high";
  title: string;
  why: string;
  fix: string;
  status: IssueStatus;
  source: string;
  fixPayload: string;
  createdAt: string;
}

export interface ChangeRow {
  id: string;
  issueId: string | null;
  targetType: string;
  targetRef: string;
  oldValue: string;
  newValue: string;
  reason: string;
  status: string;
  createdAt: string;
}

export interface KeywordRow {
  id: string;
  keyword: string;
  pageUrl: string;
  lang: string;
  notes: string;
  usage?: { homepage: number; posts: string[]; total: number; density: number };
  cannibalization?: string[];
}

export interface TaskStatus {
  task: string;
  lastDone: string | null;
  nextDue: string | null;
  lastStatus: string | null;
}

export interface OverviewData {
  latestAudit: {
    id: string;
    status: string;
    score: number;
    pages: number;
    critical: number;
    warning: number;
    opportunity: number;
    trigger: string;
    startedAt: string;
    finishedAt: string | null;
    error: string;
  } | null;
  auditsCount: number;
  issues: {
    open: number;
    critical: number;
    warning: number;
    opportunity: number;
    applied: number;
    resolved: number;
    ignored: number;
  };
  keywords: number;
  tasks: TaskStatus[];
  nextScheduled: string | null;
  recentChanges: ChangeRow[];
  settings: {
    baseUrl: string;
    psiKey: boolean;
    cronSecret: boolean;
    adminDefaultPassword: boolean;
  };
}

export interface IntegrationRow {
  key: string;
  name: string;
  status: "connected" | "available" | "not_connected";
  detail: string;
  docsUrl: string;
  steps: { fa: string[]; en: string[] };
}

export interface ReportRow {
  id: string;
  period: string;
  summary: string;
  createdAt: string;
}

export interface ReportSummaryData {
  period: string;
  generatedAt: string;
  scoreLatest: number | null;
  scoreTrend: { date: string; score: number }[];
  counts: { critical: number; warning: number; opportunity: number; open: number; applied: number; resolved: number; ignored: number };
  resolvedSinceLast: number;
  recurring: { code: string; seen: number }[];
  plan: { code: string; title: string; pageUrl: string; severity: string; risk: string }[];
  plain: { fa: string; en: string };
}

export interface PsiData {
  url: string;
  strategy: string;
  fetchedAt: number;
  ok: boolean;
  error?: string;
  performance?: number;
  metrics?: Record<string, { value: number; display: string }>;
  fieldData?: Record<string, { percentile: number; display: string }>;
  opportunities?: { id: string; title: string; display: string }[];
}

export interface OptimizerResponse {
  result: {
    titles: string[];
    descriptions: string[];
    headings: string[];
    sections: string[];
    internalLinks: string[];
    notes: string;
    source: "rules";
  };
  page: { title: string; description: string; wordCount: number };
  keywordUsage: { occurrences: number; densityPct: number; inTitle: boolean; inDescription: boolean };
}

export function fmtDate(iso: string | null | undefined, lang: SeoLang): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString(lang === "fa" ? "fa-AF" : "en-GB", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  } catch {
    return iso.slice(0, 16).replace("T", " ");
  }
}
