import { NextResponse } from "next/server";
import { z } from "zod";
import { ensureDb } from "@/lib/db";
import { saveSubscriber } from "@/lib/store";
import { supabaseEnabled } from "@/lib/supabase";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { sameOrigin } from "@/lib/http";

const SubscribeSchema = z.object({
  email: z.string().trim().email("invalid email").max(160),
});

/** POST /api/subscribe — newsletter signup (footer form). */
export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return NextResponse.json({ ok: false, error: "BAD_ORIGIN" }, { status: 403 });
  }
  /* spam protection — 8 signups per 10 minutes per IP */
  const rl = rateLimit(`subscribe:${clientIp(request)}`, 8, 10 * 60_000);
  if (!rl.ok) {
    return NextResponse.json(
      { ok: false, error: "RATE_LIMITED", retryAfter: rl.retryAfter },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } }
    );
  }

  try {
    let body: { email?: unknown };
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { ok: false, error: "VALIDATION", issues: { body: ["invalid JSON"] } },
        { status: 400 }
      );
    }
    /* local db bootstrap is best-effort — hosted platforms without a
       writable filesystem still accept subscribers via Supabase */
    try {
      await ensureDb();
    } catch (error) {
      if (!supabaseEnabled) throw error;
      console.error(
        "[/api/subscribe] local db unavailable — Supabase fallback active:",
        String(error).slice(0, 160)
      );
    }
    const parsed = SubscribeSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: "VALIDATION", issues: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }
    const email = parsed.data.email.toLowerCase();
    await saveSubscriber(email);
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (error) {
    console.error("[/api/subscribe] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
