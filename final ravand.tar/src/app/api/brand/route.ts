import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/** GET /api/brand — public brand assets (admin-managed logo). */
export async function GET() {
  try {
    const row = await db.setting.findUnique({
      where: { id: "main" },
      select: { logoUrl: true },
    });
    return NextResponse.json({
      ok: true,
      logoUrl: row?.logoUrl || "/images/logo-r.webp",
    });
  } catch (error) {
    console.error("[/api/brand] failed:", error);
    // The site must always render — fall back to the bundled logo.
    return NextResponse.json({ ok: true, logoUrl: "/images/logo-r.webp" });
  }
}
