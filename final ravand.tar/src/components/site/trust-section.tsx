"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { ArrowUpRight, Code2, Gauge, Globe, Languages, ShieldCheck, Timer } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useT } from "@/lib/i18n";
import { navigate } from "@/lib/router";
import { Reveal, StackedLines } from "./reveal";
import { BlockSticker } from "./sticker";
import { CarouselDots } from "./ui-v2";

const FEATURED = [
  { img: "/stickers/hamsafar.svg", title: "p1_title", cat: "p1_cat", alt: "Hamsafar Tours website" },
  { img: "/stickers/omo.svg", title: "p2_title", cat: "p2_cat", alt: "OMO Education platform" },
  { img: "/stickers/ai-workspace.svg", title: "p4_title", cat: "p4_cat", alt: "AI Workspace product" },
] as const;

const CAPABILITIES = [
  { icon: Code2, key: "why.f1_t" },
  { icon: ShieldCheck, key: "why.f4_t" },
  { icon: Gauge, key: "why.f3_t" },
  { icon: Timer, key: "why.f5_t" },
  { icon: Globe, key: "why.f2_t" },
  { icon: Languages, key: "stats.langs_s" },
] as const;

function FeatureCard({
  icon: Icon,
  title,
  desc,
  index,
  tint,
}: {
  icon: LucideIcon;
  title: string;
  desc: string;
  index: number;
  tint: "brand" | "teal" | "lime";
}) {
  const tintCls =
    tint === "brand"
      ? "bg-brand/10 text-brand group-hover:bg-brand group-hover:text-white"
      : tint === "teal"
        ? "bg-accent-court/10 text-accent-court group-hover:bg-accent-court group-hover:text-white"
        : "bg-[#c2e029]/25 text-[#5a7a00] group-hover:bg-[#c2e029] group-hover:text-brand-deep";

  return (
    <Reveal
      from={{ opacity: 0, y: 30 }}
      delayIn={0.08 * index}

      className="h-full"
    >
      <article
        className="group flex h-full flex-col rounded-card border border-hairline bg-white p-6 transition-[box-shadow,border-color,transform] duration-300 hover:border-brand/35 hover:shadow-[0_28px_56px_-30px_rgba(15,47,99,0.35)] hover:-translate-y-1.5"
      >
        <span className="flex items-center justify-between">
          <span
            aria-hidden
            className={`grid size-11 place-items-center rounded-xl transition-colors duration-300 ${tintCls}`}
          >
            <Icon className="size-5" strokeWidth={1.7} />
          </span>
          <span dir="ltr" aria-hidden className="font-display text-sm font-medium text-ghost">
            {String(index + 1).padStart(2, "0")}
          </span>
        </span>
        <h3 className="font-display mt-4 text-base font-medium leading-snug sm:text-lg">{title}</h3>
        <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{desc}</p>
      </article>
    </Reveal>
  );
}

/**
 * "Why Ravand Tech" — modern bento redesign: sticker beside the
 * heading, a navy featured-project card with auto rotation, a 24h
 * response card, feature tiles and a capability marquee strip.
 */
export function TrustSection() {
  const { t } = useT();
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => setActive((v) => (v + 1) % FEATURED.length), 4200);
    return () => window.clearInterval(id);
  }, []);

  const slide = FEATURED[active];

  return (
    <section id="why" className="relative overflow-hidden bg-white px-6 py-16 sm:px-10 sm:py-24">
      {/* ── header: text + sticker ── */}
      <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between md:gap-10">
        <div className="max-w-2xl">
          <Reveal from={{ opacity: 0, y: 16 }}>
            <span className="display-caps inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.22em] text-ink-soft">
              <span aria-hidden className="size-1.5 rounded-pill bg-brand" />
              {t("why.eyebrow")}
            </span>
            <h2 className="font-display t-section mt-4 font-medium">
              <StackedLines lines={[t("why.title")]} />
            </h2>
            <p className="mt-4 max-w-xl text-[0.95rem] leading-relaxed text-ink-soft sm:text-base">
              {t("why.desc")}
            </p>
          </Reveal>
        </div>
        <BlockSticker src="/stickers/st-why.svg" alt="" tone="light" size="lg" delay={0.15} />
      </div>

      {/* ── bento grid ── */}
      <div className="mt-12 grid gap-4 sm:gap-5 lg:grid-cols-3">
        {/* navy featured card (spans 2) */}
        <Reveal from={{ opacity: 0, y: 40 }} className="lg:col-span-2">
          <article
            className="group relative flex h-full flex-col justify-between gap-8 overflow-hidden rounded-card bg-brand-deep p-6 text-white sm:p-8"
          >
            {/* glow backdrop */}
            <div
              aria-hidden
              className="absolute inset-0"
              style={{
                background:
                  "radial-gradient(30rem 18rem at 85% 15%, rgba(37,99,201,0.5), transparent 65%), radial-gradient(22rem 14rem at 8% 95%, rgba(11,110,151,0.45), transparent 65%)",
              }}
            />
            <div className="relative flex items-start justify-between gap-6">
              <div className="max-w-sm">
                <span className="display-caps inline-flex items-center gap-2 text-[0.7rem] font-medium uppercase tracking-[0.2em] text-white/60">
                  <span aria-hidden className="size-1.5 rounded-pill bg-brand-light" />
                  {t("why.badge_t")}
                </span>
                <h3 className="font-display mt-3 text-xl font-medium leading-snug sm:text-2xl">
                  {t("why.f1_t")}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-white/70">{t("why.f1_d")}</p>
                <button
                  type="button"
                  onClick={() => navigate("/portfolio")}
                  className="mt-5 inline-flex cursor-pointer items-center gap-1.5 text-sm font-medium text-brand-light transition-colors hover:text-white"
                >
                  {t("hero.cta_secondary")}
                  <span
                    aria-hidden
                    className="inline-flex transition-transform duration-300 group-hover:translate-x-1 rtl:-scale-x-100"
                  >
                    <ArrowUpRight className="size-4" />
                  </span>
                </button>
              </div>

              {/* rotating project sticker — remount replays the CSS entrance */}
              <div className="relative hidden shrink-0 sm:block">
                <div
                  key={slide.img}
                  className="anim-rotate-in glass-light relative grid size-40 place-items-center rounded-card"
                >
                  <Image
                    src={slide.img}
                    alt={slide.alt}
                    width={120}
                    height={120}
                    className="size-28 object-contain"
                  />
                  <figcaption className="absolute inset-x-3 bottom-2.5 truncate text-center text-[0.7rem] font-medium text-white/90">
                    {t(slide.title)}
                  </figcaption>
                </div>
                <div className="mt-3 flex justify-center">
                  <CarouselDots count={FEATURED.length} active={active} onSelect={setActive} tone="light" label="Featured projects" />
                </div>
              </div>
            </div>

            {/* inline checks */}
            <ul className="relative flex flex-wrap gap-x-6 gap-y-2 border-t border-white/15 pt-5 text-[0.8rem] text-white/75">
              {(["why.check1", "why.check2", "why.check3"] as const).map((k) => (
                <li key={k} className="flex items-center gap-2">
                  <span aria-hidden className="grid size-4 place-items-center rounded-pill bg-brand-light/25 text-brand-light">
                    <svg viewBox="0 0 10 10" className="size-2.5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
                      <path d="M1.5 5.5l2.4 2.4L8.5 3" />
                    </svg>
                  </span>
                  {t(k)}
                </li>
              ))}
            </ul>
          </article>
        </Reveal>

        {/* 24h response accent card */}
        <Reveal from={{ opacity: 0, y: 40, scale: 0.97 }} delayIn={0.12} className="h-full">
          <article
            className="relative flex h-full flex-col justify-between overflow-hidden rounded-card bg-surface p-6 transition-transform duration-300 hover:-translate-y-1.5"
          >
            <div className="flex items-center justify-between">
              <span className="relative flex size-3">
                <span aria-hidden className="absolute inline-flex size-full animate-ping rounded-pill bg-brand/40" />
                <span className="relative inline-flex size-3 rounded-pill bg-brand" />
              </span>
              <Timer aria-hidden className="size-5 text-ink-soft" strokeWidth={1.7} />
            </div>
            <div>
              <p dir="ltr" className="font-display text-6xl font-medium leading-none tracking-tight">
                24<span className="text-brand-light">h</span>
              </p>
              <p className="mt-3 text-sm font-medium">{t("stats.response")}</p>
              <p className="mt-1 text-[0.8rem] leading-relaxed text-ink-soft">{t("why.f6_d")}</p>
            </div>
          </article>
        </Reveal>

        {/* feature tiles */}
        <FeatureCard icon={Code2} title={t("why.f2_t")} desc={t("why.f2_d")} index={0} tint="brand" />
        <FeatureCard icon={Gauge} title={t("why.f3_t")} desc={t("why.f3_d")} index={1} tint="teal" />
        <FeatureCard icon={ShieldCheck} title={t("why.f4_t")} desc={t("why.f4_d")} index={2} tint="lime" />
        <FeatureCard icon={Timer} title={t("why.f5_t")} desc={t("why.f5_d")} index={3} tint="brand" />
        <FeatureCard icon={Languages} title={t("stats.langs")} desc={t("stats.langs_s")} index={4} tint="teal" />
      </div>

      {/* ── capability marquee ── */}
      <div className="mt-12 overflow-hidden rounded-card border border-hairline bg-surface py-4" aria-hidden>
        <div className="marquee-track flex w-max animate-marquee items-center gap-10 px-5">
          {[...CAPABILITIES, ...CAPABILITIES].map((c, i) => (
            <span key={`${c.key}-${i}`} className="flex items-center gap-2.5 text-sm font-medium text-ink-soft">
              <c.icon className="size-4 text-brand" strokeWidth={1.7} />
              {t(c.key)}
              <span className="ms-6 size-1 rounded-pill bg-ghost" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
