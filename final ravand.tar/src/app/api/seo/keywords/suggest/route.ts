import { NextResponse } from "next/server";
import { z } from "zod";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { suggestKeywords } from "@/lib/seo/ai";

export const dynamic = "force-dynamic";

const SuggestSchema = z.object({
  seed: z.string().trim().min(2).max(60),
  lang: z.enum(["fa", "en"]).default("en"),
});

/* POST /api/seo/keywords/suggest — related keyword ideas built by
   deterministic tail-pattern rules over the seed term. */
export async function POST(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-kw-suggest:${clientIp(req)}`, 8, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = SuggestSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");

  try {
    const suggestions = await suggestKeywords(parsed.data.seed, parsed.data.lang);
    return NextResponse.json({ ok: true, suggestions, source: suggestions.length ? "ai" : "none" });
  } catch (error) {
    console.error("[seo/keywords] suggest failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
