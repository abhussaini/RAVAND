"use client";

import { Quote } from "lucide-react";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { Reveal, StackedLines } from "./reveal";
import { BlockSticker } from "./sticker";
import { Eyebrow } from "./ui-v2";

const FALLBACK = [
  { id: "t1", q: "testi1_q", n: "testi1_n", r: "testi1_r" },
  { id: "t2", q: "testi2_q", n: "testi2_n", r: "testi2_r" },
  { id: "t3", q: "testi3_q", n: "testi3_n", r: "testi3_r" },
] as const;

/**
 * Testimonials — 3-up cards with avatar initial, quote icon and
 * hover lift. DB-driven (admin panel) with dictionary fallback.
 */
export function TestimonialsSection() {
  const { t } = useT();
  const { content, pick } = useContent();

  const items = content?.testimonials?.length
    ? content.testimonials.map((tm) => ({
        id: tm.id,
        quote: pick(tm.quote),
        name: tm.name,
        role: pick(tm.role),
      }))
    : FALLBACK.map((x) => ({ id: x.id, quote: t(x.q), name: t(x.n), role: t(x.r) }));

  return (
    <section id="testimonials" className="bg-white px-6 py-20 sm:px-10 sm:py-24">
      {/* header — text + sticker */}
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between md:gap-10">
        <div className="max-w-xl">
          <Eyebrow>{t("testi.eyebrow")}</Eyebrow>
          <h2 className="font-display t-section mt-4 font-medium">
            <StackedLines lines={[t("v2.testi.one")]} stagger={120} />
          </h2>
        </div>
        <BlockSticker src="/stickers/st-testimonials.svg" alt="" tone="light" delay={0.15} />
      </div>

      <ul className="mt-12 grid gap-4 sm:gap-5 md:grid-cols-3">
        {items.map((item, i) => (
          <li key={item.id}>
            <Reveal
              from={{ opacity: 0, y: 40 }}
              delayIn={i * 0.12}

              className="h-full"
            >
              <article
                className="flex h-full flex-col justify-between rounded-card border border-hairline bg-surface p-6 transition-[box-shadow,border-color,transform] duration-300 hover:border-brand/30 hover:shadow-[0_26px_54px_-30px_rgba(15,47,99,0.3)] hover:-translate-y-2 sm:p-7"
              >
                <div>
                  <span
                    aria-hidden
                    className="grid size-10 place-items-center rounded-pill bg-brand/10 text-brand"
                  >
                    <Quote className="size-4" fill="currentColor" strokeWidth={0} />
                  </span>
                  <blockquote className="mt-4 text-base leading-relaxed text-ink sm:text-lg">
                    {item.quote}
                  </blockquote>
                </div>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-hairline pt-4">
                  <span
                    aria-hidden
                    className="font-display grid size-10 shrink-0 place-items-center rounded-pill bg-brand-deep text-sm font-medium text-white"
                  >
                    {item.name.trim().charAt(0)}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{item.name}</span>
                    <span className="mt-0.5 block truncate text-sm text-ink-soft">{item.role}</span>
                  </span>
                </figcaption>
              </article>
            </Reveal>
          </li>
        ))}
      </ul>
    </section>
  );
}
