"use client";

import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, ListChecks, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { fmtDate, seoApi, type ChangeRow, type IssueRow } from "./seo-api";
import {
  ApplyDialog,
  Badge,
  ConfirmDialog,
  EmptyState,
  Loading,
  SeoCard,
  SevBadge,
  StatusBadge,
  type IssueStatus,
  type SeoTabProps,
} from "./seo-ui";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — Recommendations tab (dashboard section C).
   Apply (LOW risk = one click, MEDIUM = confirm dialog, HIGH =
   disabled), ignore, resolve, reopen, rollback — every action real.
   ------------------------------------------------------------------ */

type Filter = "all" | IssueStatus;

interface FixPayload {
  type?: string;
  field?: string;
  value?: string;
  model?: string;
  id?: string;
  lang?: string;
  oldValue?: string;
}

function parsePayload(raw: string): FixPayload {
  try {
    return JSON.parse(raw) as FixPayload;
  } catch {
    return {};
  }
}

export function IssuesTab({ lang, t }: Omit<SeoTabProps, "dir">) {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<Filter>("all");
  const [confirmIssue, setConfirmIssue] = useState<IssueRow | null>(null);
  const [rollbackChange, setRollbackChange] = useState<ChangeRow | null>(null);

  const issues = useQuery({
    queryKey: ["seo-issues"],
    queryFn: () => seoApi<{ ok: true; issues: IssueRow[] }>("/api/seo/issues?status=all"),
    refetchOnMount: "always",
  });

  const changes = useQuery({
    queryKey: ["seo-changes"],
    queryFn: () => seoApi<{ ok: true; changes: ChangeRow[] }>("/api/seo/changes"),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["seo-issues"] });
    qc.invalidateQueries({ queryKey: ["seo-changes"] });
    qc.invalidateQueries({ queryKey: ["seo-overview"] });
  };

  const patch = useMutation({
    mutationFn: ({ id, action }: { id: string; action: "apply" | "ignore" | "reopen" | "resolve" }) =>
      seoApi<{ ok: true; changeId?: string }>(`/api/seo/issues/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ action }),
      }),
    onSuccess: (_d, v) => {
      toast.success(
        v.action === "apply"
          ? lang === "fa"
            ? "اصلاح اعمال شد — در تاریخچه تغییرات قابل بازگردانی است."
            : "Fix applied — reversible from the change history."
          : lang === "fa"
            ? "انجام شد."
            : "Done."
      );
      invalidate();
    },
    onError: (e: Error) => {
      if (e.message === "HIGH_RISK_NEVER_AUTOMATED")
        toast.error(lang === "fa" ? "این مورد هرگز خودکار اجرا نمی‌شود." : "This item is never automated.");
      else toast.error(t("s.error"));
    },
  });

  const rollback = useMutation({
    mutationFn: (changeId: string) =>
      seoApi<{ ok: true }>(`/api/seo/changes/rollback`, { method: "POST", body: JSON.stringify({ changeId }) }),
    onSuccess: () => {
      toast.success(lang === "fa" ? "بازگردانی شد." : "Rolled back.");
      invalidate();
    },
    onError: () => toast.error(t("s.error")),
  });

  const filtered = useMemo(() => {
    const all = issues.data?.issues ?? [];
    return filter === "all" ? all : all.filter((i) => i.status === filter);
  }, [issues.data, filter]);

  const appliedByIssue = useMemo(() => {
    const map = new Map<string, ChangeRow>();
    for (const c of changes.data?.changes ?? []) {
      if (c.status === "applied" && c.issueId && !map.has(c.issueId)) map.set(c.issueId, c);
    }
    return map;
  }, [changes.data]);

  const counts = useMemo(() => {
    const all = issues.data?.issues ?? [];
    return {
      all: all.length,
      open: all.filter((i) => i.status === "open").length,
      applied: all.filter((i) => i.status === "applied").length,
      resolved: all.filter((i) => i.status === "resolved").length,
      ignored: all.filter((i) => i.status === "ignored").length,
    };
  }, [issues.data]);

  const sevLabel = (s: string) =>
    s === "critical" ? t("s.critical") : s === "warning" ? t("s.warning") : t("s.opportunity");
  const statusLabel = (s: string) =>
    s === "open"
      ? t("s.st_open")
      : s === "applied"
        ? t("s.st_applied")
        : s === "resolved"
          ? t("s.st_resolved")
          : s === "ignored"
            ? t("s.st_ignored")
            : t("s.st_approved");
  const riskLabel = (r: string) =>
    r === "low" ? t("s.risk_low") : r === "medium" ? t("s.risk_medium") : t("s.risk_high");

  if (issues.isLoading) return <Loading label={t("s.loading")} />;

  return (
    <div className="grid grid-cols-1 gap-4 lg:gap-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5" role="tablist" aria-label={t("s.filter_all")}>
          {(["all", "open", "applied", "resolved", "ignored"] as Filter[]).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`cursor-pointer rounded-pill px-3 py-1.5 text-xs font-medium transition-colors ${
                filter === f ? "bg-brand-deep text-white" : "bg-white text-ink-soft hover:bg-surface"
              }`}
            >
              {f === "all" ? t("s.filter_all") : statusLabel(f)} ({counts[f]})
            </button>
          ))}
        </div>
        <a
          href="/api/seo/issues?format=csv&status=all"
          className="inline-flex items-center gap-1.5 rounded-pill bg-white px-3 py-1.5 text-xs font-medium text-ink shadow-sm transition-colors hover:bg-surface"
        >
          <Download className="size-3.5" aria-hidden />
          {t("s.download_csv")}
        </a>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={ListChecks} text={t("s.no_issues")} hint={t("s.no_issues_d")} />
      ) : (
        <div className="grid gap-3">
          {filtered.map((issue) => {
            const payload = parsePayload(issue.fixPayload);
            const fixable =
              issue.status !== "applied" &&
              issue.status !== "ignored" &&
              issue.risk !== "high" &&
              Boolean(payload.type) &&
              issueAuto(issue.code);
            const change = appliedByIssue.get(issue.id);
            return (
              <article key={issue.id} className="rounded-card border border-hairline bg-white p-4 sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <SevBadge sev={issue.severity} label={sevLabel(issue.severity)} />
                      <StatusBadge status={issue.status} label={statusLabel(issue.status)} />
                      <Badge kind="info">{t("s.rules_source")}</Badge>
                      {issue.pageUrl ? <Badge kind="info">{issue.pageUrl}</Badge> : null}
                    </div>
                    <h4 className="mt-2 font-medium text-ink" dir="auto">
                      {issue.title}
                    </h4>
                  </div>
                </div>
                <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                  <div className="rounded-card bg-surface p-3">
                    <p className="text-xs font-semibold text-ink-soft">{t("s.issue_why")}</p>
                    <p className="mt-1 text-ink" dir="auto">
                      {issue.why}
                    </p>
                  </div>
                  <div className="rounded-card bg-surface p-3">
                    <p className="text-xs font-semibold text-ink-soft">{t("s.issue_fix")}</p>
                    <p className="mt-1 text-ink" dir="auto">
                      {issue.fix}
                    </p>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                  <span className={`text-xs font-medium ${issue.risk === "high" ? "text-red-700" : issue.risk === "medium" ? "text-amber-700" : "text-emerald-700"}`}>
                    {riskLabel(issue.risk)}
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {issue.status === "applied" && change ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setRollbackChange(change)}
                        className="cursor-pointer rounded-pill"
                      >
                        <RotateCcw className="size-3.5" aria-hidden />
                        {t("s.rollback")}
                      </Button>
                    ) : null}
                    {fixable && issue.risk === "low" ? (
                      <Button
                        size="sm"
                        onClick={() => patch.mutate({ id: issue.id, action: "apply" })}
                        disabled={patch.isPending}
                        className="cursor-pointer rounded-pill bg-emerald-600 text-white hover:bg-emerald-700"
                      >
                        {t("s.apply_fix")}
                      </Button>
                    ) : null}
                    {fixable && issue.risk === "medium" ? (
                      <Button
                        size="sm"
                        onClick={() => setConfirmIssue(issue)}
                        className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
                      >
                        {t("s.apply_fix")}
                      </Button>
                    ) : null}
                    {issue.status === "open" || issue.status === "approved" ? (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => patch.mutate({ id: issue.id, action: "resolve" })}
                          className="cursor-pointer rounded-pill"
                        >
                          {t("s.resolve")}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => patch.mutate({ id: issue.id, action: "ignore" })}
                          className="cursor-pointer rounded-pill text-ink-soft"
                        >
                          {t("s.ignore")}
                        </Button>
                      </>
                    ) : issue.status === "ignored" || issue.status === "resolved" ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => patch.mutate({ id: issue.id, action: "reopen" })}
                        className="cursor-pointer rounded-pill"
                      >
                        {t("s.reopen")}
                      </Button>
                    ) : null}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {changes.data?.changes?.length ? (
        <SeoCard title={t("s.changes_log")} icon={RotateCcw} className="max-h-96 overflow-y-auto">
          <ul className="grid gap-2">
            {changes.data.changes.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-card border border-hairline p-3 text-xs">
                <div className="min-w-0">
                  <span className="font-medium text-ink" dir="ltr">
                    {c.targetRef}
                  </span>
                  <p className="mt-0.5 truncate text-ink-soft" dir="auto">
                    {c.oldValue || "—"} → {c.newValue || "—"}
                  </p>
                  <p className="mt-0.5 text-[10px] text-ink-soft">
                    {fmtDate(c.createdAt, lang)} · {c.reason}
                  </p>
                </div>
                {c.status === "applied" ? (
                  <Button variant="outline" size="sm" onClick={() => setRollbackChange(c)} className="cursor-pointer rounded-pill">
                    <RotateCcw className="size-3.5" aria-hidden />
                    {t("s.rollback")}
                  </Button>
                ) : (
                  <Badge kind={c.status === "rolled_back" ? "warning" : "info"}>{c.status}</Badge>
                )}
              </li>
            ))}
          </ul>
        </SeoCard>
      ) : null}

      <ApplyDialog
        open={Boolean(confirmIssue)}
        onClose={() => setConfirmIssue(null)}
        onConfirm={() => {
          if (confirmIssue) patch.mutate({ id: confirmIssue.id, action: "apply" });
          setConfirmIssue(null);
        }}
        title={t("s.apply_confirm_t")}
        desc={t("s.apply_confirm_d")}
        oldValue={confirmIssue ? parsePayload(confirmIssue.fixPayload).oldValue ?? "" : ""}
        newValue={confirmIssue ? parsePayload(confirmIssue.fixPayload).value ?? "" : ""}
        labels={{ old: t("s.old_value"), new: t("s.new_value"), confirm: t("s.confirm"), cancel: t("s.cancel") }}
      />

      <ConfirmDialog
        open={Boolean(rollbackChange)}
        onClose={() => setRollbackChange(null)}
        onConfirm={() => {
          if (rollbackChange) rollback.mutate(rollbackChange.id);
          setRollbackChange(null);
        }}
        title={t("s.rollback")}
        desc={rollbackChange ? `${rollbackChange.oldValue || "—"} ← ${rollbackChange.newValue}` : undefined}
        confirmLabel={t("s.confirm")}
        cancelLabel={t("s.cancel")}
      />
    </div>
  );
}

/** Mirrors audit-texts REGISTRY auto flag — kept in sync manually. */
function issueAuto(code: string): boolean {
  const AUTO_CODES = new Set([
    "MISSING_TITLE",
    "SHORT_TITLE",
    "LONG_TITLE",
    "MISSING_DESCRIPTION",
    "SHORT_DESCRIPTION",
    "LONG_DESCRIPTION",
    "OG_MISSING",
    "DUPLICATE_TITLE",
    "POST_TITLE_SHORT",
    "POST_EXCERPT_MISSING",
    "L10N_MISSING",
  ]);
  return AUTO_CODES.has(code);
}
