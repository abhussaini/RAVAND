# Changelog — Ravand Tech Website

## Release 3.0 — "z.ai integration + full repair" (2026-11-15)

This release makes every AI feature real, repairs the broken admin
workflows, and ships a cleaned codebase. Everything below was verified
in a real browser (agent-browser), not just compiled.

### New — z.ai is now the AI brain (real, not rule-based)

- `z-ai-web-dev-sdk` installed and wired through a shared server
  singleton (`src/lib/zai.ts`) with hard timeouts. Backend-only —
  never exposed to the browser.
- **Smart Assistant widget** (`/api/chat`): replies are now generated
  by the z.ai language model, grounded in LIVE site facts (services,
  portfolio, stats, contact settings pulled fresh from the database).
  Falls back transparently to the deterministic rule agent if the
  provider is unreachable — the widget never shows a raw error.
  Verified live in Dari, Pashto and English, with multi-turn context
  (the widget now sends conversation history) and visitor-language
  detection (a Dari question gets a Dari answer even in EN mode).
- **SEO Assistant**: keyword suggestions (`/api/seo/keywords/suggest`)
  and the content optimizer (`/api/seo/optimize`) now call z.ai first
  and fall back to the rule engine. The Integrations tab shows the
  honest live status of the AI provider ("z-ai-sdk — connected").
- Prompt-injection defence on every AI path: crawled content and
  visitor messages are treated as data, never instructions; all AI
  output is schema-validated, tag-stripped and length-capped.

### Fixed — admin panel defects

- **Image upload was dead**: the MediaPicker posted to
  `/api/admin/upload`, which did not exist (every upload 404'd).
  The endpoint now exists: admin-session + same-origin + rate-limit
  protected, 4 MB cap, PNG/JPG/WebP/GIF only, validated by magic
  bytes (a renamed text file is rejected), stored under
  `public/uploads/` with a random name. Verified end-to-end in the
  panel UI (upload → value set → file served with 200).
- **Success toast bug**: applying an SEO fix always said the generic
  "Done." because the handler compared an object to a string
  (`v === "apply"`). Now compares the action field correctly.

### Fixed — SEO assistant code defects (type-check level)

- `IssueStatus` referenced but never imported in `seo-api.ts`.
- `CheckRow` destructured a non-existent `unknown` prop.
- `ok` specified twice (spread overwrites) in the audit summary,
  the issues PATCH route and the rollback route — semantics kept,
  warnings gone.
- `loadPayload` now returns a proper discriminated union.

### Removed — unused files, images and code (transparent list)

Dead code (nothing imported them anywhere; full-repo grep verified):
- Site components (10): `announcement-bar`, `contact-section`,
  `faq-section`, `process-section`, `scroll-to-top`, `tech-marquee`,
  `why-us-section`, `whatsapp-float`, `theme-provider`, `ai-chat`
  (superseded by `smart-assistant`).
- Lib: `gemini.ts` (dead provider — superseded by z.ai integration).
- Hooks: `use-toast`, `use-mobile` (only consumers were removed
  components).
- UI library components not used by any page (41 files): alert,
  animated-wave-footer, aspect-ratio, avatar, badge, breadcrumb,
  calendar, card, carousel, chart, checkbox, collapsible, command,
  context-menu, drawer, dropdown-menu, form, hero-08 (+ utils),
  hover-card, input-otp, menubar, navigation-menu, pagination,
  popover, progress, radio-group, resizable, scroll-area, select,
  separator, sheet, sidebar, skeleton, slider, table, tabs, textarea,
  toast, toaster, toggle, toggle-group, tooltip.
- Dead config: `tailwind.config.ts` (Tailwind v4 uses `globals.css`),
  `src/components/theme-provider.tsx` (unreferenced).

Orphaned assets (not referenced by any code, DB row or manifest):
- `public/images/blog/*` (3), `public/images/projects/*` (6),
  `hero-studio.png/webp`, `hero-team.webp`, `logo-icon.webp`,
  `logo-r-sm.webp`, `logo-ravand.png`, `public/logo.svg`.

Data cleanup: QA-test rows deleted from `SeoChange` (rolled-back test
fixes). The admin keeps only real records.

The used set is verified before every deletion: `accordion`,
`button`, `input`, `label`, `switch`, `dialog`, `alert-dialog`,
`sonner` and all site components remain and work.

### Quality gates (all passing)

- `bun run lint` — clean.
- `tsc --noEmit` — 0 errors in the project (examples/skills demo
  folders excluded from the type scope).
- Browser-verified: login, overview counts, service edit + save,
  settings save, upload UI flow, SEO audit run, issues
  apply → rollback cycle, keyword AI suggestions, optimizer AI run,
  integrations status, all public pages (home/services/portfolio/
  blog/post/about/contact), smart assistant AI chat + scroll.

### Notes

- Admin password stays `ravand2024` locally (from `ADMIN_PASSWORD`
  in `.env`) — change it for any public deployment.
- The stale `public/download/ravand-tech-full.zip` was removed and
  replaced by this release's package.
