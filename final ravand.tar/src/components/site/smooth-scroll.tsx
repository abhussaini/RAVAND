"use client";

import { useEffect } from "react";
import { initLenis, startLenis, stopLenis } from "@/lib/lenis";
import { useUi } from "@/store/use-ui";

/**
 * Boots the Lenis smooth-scroll singleton and locks the scroll while the
 * intro loader is on screen or an overlay (menu / modal) is open.
 */
export function SmoothScroll() {
  const ready = useUi((s) => s.ready);
  const overlayOpen = useUi((s) => s.menuOpen || s.contactOpen);

  useEffect(() => {
    initLenis();
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const locked = !ready || overlayOpen;
    if (locked) {
      stopLenis();
      document.documentElement.style.overflow = "hidden";
    } else {
      startLenis();
      document.documentElement.style.removeProperty("overflow");
    }
  }, [ready, overlayOpen]);

  return null;
}
