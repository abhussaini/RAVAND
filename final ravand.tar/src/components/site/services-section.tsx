"use client";

import {
  ArrowUpRight,
  Bot,
  Globe,
  LifeBuoy,
  PenTool,
  ShoppingBag,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { useUi } from "@/store/use-ui";
import { Reveal, StackedLines } from "./reveal";
import { BlockSticker } from "./sticker";
import { Eyebrow } from "./ui-v2";

const ICONS: Record<string, LucideIcon> = {
  web: Globe,
  software: Bot,
  uiux: PenTool,
  shop: ShoppingBag,
  seo: TrendingUp,
  support: LifeBuoy,
};

const FALLBACK: Array<{ slug: string; title: string; desc: string }> = [
  { slug: "web", title: "services.web_t", desc: "services.web_d" },
  { slug: "software", title: "services.soft_t", desc: "services.soft_d" },
  { slug: "uiux", title: "services.ui_t", desc: "services.ui_d" },
  { slug: "shop", title: "services.shop_t", desc: "services.shop_d" },
  { slug: "seo", title: "services.seo_t", desc: "services.seo_d" },
  { slug: "support", title: "services.support_t", desc: "services.support_d" },
];

/**
 * Modern services grid — icon cards with hover lift, icon fill
 * and arrow slide. Every card opens the contact modal with the
 * service pre-selected. Content is DB-driven (admin panel) with
 * the trilingual dictionary as fallback.
 */
export function ServicesSection({ showHeader = true }: { showHeader?: boolean }) {
  const { t } = useT();
  const { content, pick } = useContent();
  const openContact = useUi((s) => s.openContact);

  const items = content?.services?.length
    ? content.services.map((s) => ({
        slug: s.slug,
        title: pick(s.title),
        desc: pick(s.desc),
        icon: ICONS[s.slug] ?? Globe,
      }))
    : FALLBACK.map((s) => ({ ...s, icon: ICONS[s.slug] ?? Globe, title: t(s.title), desc: t(s.desc) }));

  return (
    <section
      id="services"
      className={showHeader ? "bg-surface px-6 py-20 sm:px-10 sm:py-24" : "bg-surface px-6 pb-20 pt-3 sm:px-10 sm:pb-24"}
    >
      {/* header — text + sticker */}
      {showHeader && (
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between md:gap-10">
        <div className="max-w-2xl">
          <Eyebrow>{t("services.eyebrow")}</Eyebrow>
          <h2 className="font-display t-section mt-4 font-medium">
            <StackedLines lines={[t("v2.services.one")]} stagger={120} />
          </h2>
          <Reveal from={{ opacity: 0, y: 14 }} delayIn={0.2}>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-ink-soft sm:text-[0.95rem]">
              {t("services.desc")}
            </p>
          </Reveal>
        </div>
        <BlockSticker src="/stickers/st-services.svg" alt="" tone="light" delay={0.15} />
      </div>
      )}

      {/* cards */}
      <ul className={showHeader ? "mt-12 grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3" : "grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3"}>
        {items.map((s, i) => (
          <li key={s.slug}>
            <Reveal
              from={{ opacity: 0, y: 34 }}
              delayIn={(i % 3) * 0.09}

              className="h-full"
            >
              <button
                type="button"
                onClick={() => openContact(s.slug)}
                className="group flex h-full w-full cursor-pointer flex-col rounded-card border border-hairline bg-white p-6 text-start transition-[box-shadow,border-color,transform] duration-300 hover:border-brand/35 hover:shadow-[0_28px_56px_-30px_rgba(15,47,99,0.35)] hover:-translate-y-1.5 focus-visible:border-brand/50"
              >
                <span className="flex items-start justify-between">
                  <span
                    className="grid size-12 place-items-center rounded-xl bg-[#f4f4f4] text-[#0f2f63] transition-[background-color,color,transform] duration-300 group-hover:bg-brand-deep group-hover:text-white group-hover:-rotate-6"
                    aria-hidden
                  >
                    <s.icon className="size-5" strokeWidth={1.7} />
                  </span>
                  <span
                    dir="ltr"
                    aria-hidden
                    className="font-display text-sm font-medium text-ghost transition-colors duration-300 group-hover:text-brand/60"
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </span>

                <h3 className="font-display mt-5 text-lg font-medium leading-snug tracking-tight sm:text-xl">
                  {s.title}
                </h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-soft">{s.desc}</p>

                <span className="mt-5 flex items-center gap-1.5 text-sm font-medium text-brand">
                  {t("services.cta")}
                  <span
                    aria-hidden
                    className="inline-flex transition-transform duration-300 group-hover:translate-x-1"
                  >
                    <ArrowUpRight className="size-4 rtl:-scale-x-100" />
                  </span>
                </span>
              </button>
            </Reveal>
          </li>
        ))}
      </ul>
    </section>
  );
}
