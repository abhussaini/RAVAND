import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { parseL10n } from "@/app/api/content/route";
import { deny, guard, jsonError } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

const CreateSchema = z.object({
  keyword: z.string().trim().min(2).max(60),
  pageUrl: z.string().trim().max(200).default("/"),
  lang: z.enum(["fa", "ps", "en"]).default("en"),
  notes: z.string().trim().max(500).default(""),
});

/* GET /api/seo/keywords — list + real usage analysis (admin only).
   Usage = occurrences across the latest audited homepage text and all
   published posts (titles + bodies). Cannibalization flag = the same
   keyword targeted on several pages. */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    await ensureDb();
    const keywords = await db.seoKeyword.findMany({ orderBy: { createdAt: "desc" } });

    const [latestPage, posts] = await Promise.all([
      db.seoPageResult.findFirst({ orderBy: { id: "desc" } }),
      db.post.findMany({ where: { published: true } }),
    ]);

    const homepageText = (latestPage?.contentText ?? "").toLowerCase();
    const postTexts = posts.map((p) => {
      const t = parseL10n(p.title);
      const b = parseL10n(p.body);
      return { slug: p.slug, text: `${t.fa} ${t.ps} ${t.en} ${b.fa} ${b.ps} ${b.en}`.toLowerCase() };
    });

    const countIn = (text: string, kw: string) => {
      if (!kw || !text) return 0;
      let n = 0;
      let idx = text.indexOf(kw);
      while (idx !== -1 && n < 500) {
        n++;
        idx = text.indexOf(kw, idx + kw.length);
      }
      return n;
    };

    const enriched = keywords.map((k) => {
      const kw = k.keyword.toLowerCase();
      const homepage = countIn(homepageText, kw);
      const postsFound = postTexts.filter((p) => p.text.includes(kw)).map((p) => p.slug);
      const total = homepage + postsFound.length;
      return {
        ...k,
        usage: { homepage, posts: postsFound, total, density: homepageText ? +(homepage / Math.max(1, homepageText.split(/\s+/).length) * 100).toFixed(2) : 0 },
        cannibalization: keywords.filter((o) => o.keyword.toLowerCase() === kw).map((o) => o.pageUrl).filter((u) => u !== k.pageUrl),
      };
    });

    return NextResponse.json({ ok: true, keywords: enriched });
  } catch (error) {
    console.error("[seo/keywords] list failed:", error);
    return jsonError("SERVER_ERROR", 500, { detail: String(error).slice(0, 120) });
  }
}

/* POST /api/seo/keywords — add a target keyword. */
export async function POST(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-kw-create:${clientIp(req)}`, 30, 60_000);
  if (!rl.ok) return jsonError("RATE_LIMITED", 429);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");

  try {
    await ensureDb();
    const created = await db.seoKeyword.create({ data: parsed.data });
    return NextResponse.json({ ok: true, keyword: created }, { status: 201 });
  } catch (error) {
    if (String(error).includes("Unique")) return jsonError("DUPLICATE", 409);
    console.error("[seo/keywords] create failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
