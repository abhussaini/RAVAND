"use client";

import { useEffect, useState } from "react";
import { QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BarChart3,
  ExternalLink,
  Gauge,
  KeyRound,
  LayoutDashboard,
  ListChecks,
  Loader2,
  LogOut,
  PlugZap,
  Radar,
  Settings as SettingsIcon,
  Sparkles,
  Type,
} from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrandMark } from "@/components/site/ui-v2";
import { navigate } from "@/lib/router";
import { loadSeoLang, useSeoLang } from "./seo-lang";
import { useSeoStrings, type SeoLang } from "./seo-strings";
import { Loading, TabButton } from "./seo-ui";
import { OverviewTab } from "./seo-overview";
import { AuditTab } from "./seo-audit-tab";
import { IssuesTab } from "./seo-issues-tab";
import { GrowthTab } from "./seo-growth-tab";
import { PerformanceTab } from "./seo-performance-tab";
import { SettingsTab } from "./seo-settings-tab";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — dashboard shell at #/seo.
   Protected with the same signed admin session as the content panel.
   Dari (RTL) is the default dashboard language; English one tap away.
   ------------------------------------------------------------------ */

const TAB_KEYS = [
  "overview",
  "audit",
  "issues",
  "keywords",
  "optimizer",
  "performance",
  "reports",
  "integrations",
  "settings",
] as const;

type TabKey = (typeof TAB_KEYS)[number];

function LoginScreen({ t, dir }: { t: (k: string) => string; dir: "rtl" | "ltr" }) {
  const [pw, setPw] = useState("");
  const qc = useQueryClient();
  const login = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (!res.ok || !data.ok) throw new Error(data.error ?? "INVALID_PASSWORD");
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["seo-session"] }),
    onError: () => toast.error(t("s.wrong_pass")),
  });

  return (
    <div dir={dir} className="grid min-h-screen place-items-center bg-surface px-4">
      <Toaster richColors position={dir === "rtl" ? "bottom-left" : "bottom-right"} />
      <form
        onSubmit={(e) => {
          e.preventDefault();
          login.mutate();
        }}
        className="w-full max-w-sm rounded-card border border-hairline bg-white p-6 shadow-[0_8px_30px_rgba(15,47,99,0.08)]"
      >
        <div className="mb-5 flex flex-col items-center gap-2 text-center">
          <BrandMark className="size-12" />
          <h1 className="font-display text-xl font-bold text-brand-deep">{t("s.login_t")}</h1>
          <p className="text-xs text-ink-soft">{t("s.login_d")}</p>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="seo-pw">{t("s.password")}</Label>
          <Input
            id="seo-pw"
            type="password"
            autoComplete="current-password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            required
            minLength={1}
          />
        </div>
        <Button
          type="submit"
          disabled={login.isPending}
          className="mt-4 w-full cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
        >
          {login.isPending ? <Loader2 className="size-4 animate-spin" /> : t("s.sign_in")}
        </Button>
      </form>
    </div>
  );
}

/* Provider lives here (inside the dynamic SEO chunk) so react-query
   is not part of the public site bundle. */
export function SeoApp() {
  const [qc] = useState(
    () =>
      new QueryClient({
        defaultOptions: { queries: { staleTime: 30_000, retry: 1 } },
      })
  );
  return (
    <QueryClientProvider client={qc}>
      <SeoAppInner />
    </QueryClientProvider>
  );
}

function SeoAppInner() {
  const lang = useSeoLang((s) => s.lang);
  const setLang = useSeoLang((s) => s.setLang);
  const t = useSeoStrings(lang);
  const dir: "rtl" | "ltr" = lang === "fa" ? "rtl" : "ltr";
  const qc = useQueryClient();
  const [tab, setTab] = useState<TabKey>("overview");

  /* restore persisted dashboard language (default: Dari) */
  useEffect(() => {
    loadSeoLang();
  }, []);

  const session = useQuery({
    queryKey: ["seo-session"],
    queryFn: async (): Promise<{ ok: boolean; authed: boolean }> => {
      const res = await fetch("/api/admin/session");
      return res.json();
    },
    staleTime: 30_000,
  });

  const logout = useMutation({
    mutationFn: () => fetch("/api/admin/logout", { method: "POST" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["seo-session"] }),
  });

  if (session.isLoading) {
    return (
      <div className="grid min-h-screen place-items-center bg-surface" dir={dir}>
        <Loading label={t("s.loading")} />
      </div>
    );
  }

  if (!session.data?.authed) return <LoginScreen t={t} dir={dir} />;

  const tabProps = { lang: lang as SeoLang, t, dir };

  const tabs: { key: TabKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { key: "overview", label: t("s.tab_overview"), icon: LayoutDashboard },
    { key: "audit", label: t("s.tab_audit"), icon: Radar },
    { key: "issues", label: t("s.tab_issues"), icon: ListChecks },
    { key: "keywords", label: t("s.tab_keywords"), icon: KeyRound },
    { key: "optimizer", label: t("s.tab_optimizer"), icon: Type },
    { key: "performance", label: t("s.tab_performance"), icon: Gauge },
    { key: "reports", label: t("s.tab_reports"), icon: BarChart3 },
    { key: "integrations", label: t("s.tab_integrations"), icon: PlugZap },
    { key: "settings", label: t("s.tab_settings"), icon: SettingsIcon },
  ];

  return (
    <div dir={dir} className="min-h-screen bg-surface text-ink">
      <Toaster richColors position={dir === "rtl" ? "bottom-left" : "bottom-right"} />

      <header className="sticky top-0 z-40 border-b border-hairline bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex min-w-0 items-center gap-3">
            <BrandMark className="size-10 shrink-0" />
            <div className="min-w-0">
              <h1 className="flex items-center gap-1.5 truncate font-display text-base font-bold text-brand-deep sm:text-lg">
                <Sparkles className="size-4 shrink-0 text-brand" aria-hidden />
                {t("s.app_t")}
              </h1>
              <p className="hidden truncate text-xs text-ink-soft sm:block">{t("s.app_d")}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setLang(lang === "fa" ? "en" : "fa")}
              className="cursor-pointer rounded-pill bg-surface px-3 py-1.5 text-xs font-semibold text-ink transition-colors hover:bg-hairline"
            >
              {t("s.lang_toggle")}
            </button>
            <button
              type="button"
              onClick={() => navigate("/admin")}
              className="hidden cursor-pointer items-center gap-1 rounded-pill bg-surface px-3 py-1.5 text-xs font-medium text-ink transition-colors hover:bg-hairline sm:inline-flex"
            >
              <SettingsIcon className="size-3.5" aria-hidden />
              {t("s.admin_panel")}
            </button>
            <button
              type="button"
              onClick={() => navigate("/")}
              className="hidden cursor-pointer items-center gap-1 rounded-pill bg-surface px-3 py-1.5 text-xs font-medium text-ink transition-colors hover:bg-hairline sm:inline-flex"
            >
              <ExternalLink className="size-3.5" aria-hidden />
              {t("s.view_site")}
            </button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => logout.mutate()}
              className="cursor-pointer rounded-pill"
              aria-label={t("s.logout")}
            >
              <LogOut className="size-3.5" aria-hidden />
              <span className="sr-only">{t("s.logout")}</span>
            </Button>
          </div>
        </div>
        <nav
          className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 pb-3"
          aria-label={t("s.app_t")}
        >
          {tabs.map((tb) => (
            <TabButton key={tb.key} active={tab === tb.key} onClick={() => setTab(tb.key)}>
              <tb.icon className="size-4" aria-hidden />
              <span className="whitespace-nowrap">{tb.label}</span>
            </TabButton>
          ))}
        </nav>
      </header>

      <main className="mx-auto w-full max-w-7xl px-4 py-6">
        {tab === "overview" && <OverviewTab {...tabProps} goTab={(k) => setTab(k as TabKey)} />}
        {tab === "audit" && <AuditTab {...tabProps} />}
        {tab === "issues" && <IssuesTab {...tabProps} />}
        {(tab === "keywords" || tab === "optimizer") && <GrowthTab key={tab} {...tabProps} initialTab={tab} />}
        {tab === "performance" && <PerformanceTab key={tab} {...tabProps} initialTab="performance" />}
        {tab === "reports" && <PerformanceTab key={tab} {...tabProps} initialTab="reports" />}
        {(tab === "integrations" || tab === "settings") && <SettingsTab key={tab} {...tabProps} initialTab={tab} />}
      </main>
    </div>
  );
}
