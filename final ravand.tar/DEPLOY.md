# Ravand Tech — Deployment Guide

Complete, current guide for deploying the site to **Netlify** (or any Node host).

---

## 1. What powers the site

| Layer | Technology |
|---|---|
| Framework | Next.js 16 (App Router) + React 19 + TypeScript |
| Styling | Tailwind CSS 4 + shadcn/ui, three languages (English / دری / پښتو) with RTL |
| Database | **Supabase Postgres** via Prisma (serverless pooler) |
| AI (chat + SEO assistant) | Bundled z.ai SDK locally; any OpenAI-compatible API on Netlify |
| SEO scheduler | Netlify Scheduled Function (`netlify/functions/seo-scheduler.mjs`) |

---

## 2. One-time Supabase setup

1. Create the project at <https://supabase.com> (region close to your audience).
2. Run `supabase/schema.sql` once in **Supabase dashboard → SQL editor**.
   It creates the lead-mirror tables used by the REST fallback.
3. Get the connection string: **Supabase → Connect → Transaction pooler (port 6543)**.
   URL-encode the password (`$` → `%24`, `@` → `%40`, `#` → `%23`).

---

## 3. Environment variables

### Local development (`.env` — never commit)

```bash
DATABASE_URL=postgresql://postgres.<PROJECT-REF>:<DB-PASSWORD>@aws-0-<REGION>.pooler.supabase.com:6543/postgres?pgbouncer=true&connection_limit=1
DIRECT_URL=postgresql://postgres.<PROJECT-REF>:<DB-PASSWORD>@aws-0-<REGION>.pooler.supabase.com:5432/postgres
```

### Netlify (Site configuration → Environment variables)

| Variable | Required? | Purpose |
|---|---|---|
| `DATABASE_URL` | **Yes** | Supabase Postgres pooler URL (port **6543**) — all content, leads, SEO data |
| `ADMIN_PASSWORD` | **Yes — change it!** | Admin panel login (default fallback `ravand2024`) |
| `AI_API_KEY` | Recommended | Enables real AI replies on Netlify (OpenAI, DeepSeek, OpenRouter, Groq…) |
| `AI_BASE_URL` | With AI_API_KEY | e.g. `https://api.openai.com/v1` |
| `AI_MODEL` | Optional | e.g. `gpt-4o-mini` |
| `CRON_SECRET` | Optional | Protects `/api/seo/tasks/run` + daily scheduler |
| `PAGESPEED_API_KEY` | Optional | Reliable quota for the SEO speed tab |
| `SUPABASE_URL` / `SUPABASE_API_KEY` | Optional | Extra REST mirror for leads (insert-only RLS) |

> Without `AI_API_KEY` the chat and SEO assistant fall back to deterministic
> rule-based answers — the site never shows a raw provider error, but replies
> are simpler than the AI ones.

---

## 4. Deploy to Netlify

1. Push the repository to GitHub/GitLab.
2. Netlify → **Add new site → Import an existing project**.
3. Build settings are read from `netlify.toml`:
   - build command `bun run build:netlify` (runs `prisma generate && next build`)
   - plugin `@netlify/plugin-nextjs` (handles SSR, API routes, caching)
4. Add the environment variables from the table above.
5. Deploy. First deploy runs `postinstall` → `prisma generate` automatically.

### Local development

```bash
bun install        # installs deps, runs prisma generate
bun run dev        # http://localhost:3000
bun run lint       # ESLint
bun run db:push    # sync Prisma schema to Supabase
bun run db:seed    # optional seed content
```

### VPS / Docker (alternative)

```bash
bun run build      # standalone output
bun start          # NODE_ENV=production on port 3000
```

---

## 5. Post-deploy verification checklist

| Check | Where | Expected |
|---|---|---|
| Health probe | `/api/health` | `{"ok":true,"checks":{"database":"ok"}}` |
| Homepage | `/` | All sections render, no blank page |
| Contact form | `/#/contact` → submit | Green success state |
| Newsletter | footer form → submit | Success toast |
| AI assistant | floating chat widget | AI reply (or rule-based fallback) |
| Admin login | `/#/admin` | Dashboard loads |
| Messages tab | admin → Messages | Submitted test message listed |
| SEO assistant | admin → SEO Assistant | Tabs load, audit runs |
| Languages | menu → Dari / Pashto | RTL layout switches correctly |

Delete the test contact message afterwards (Messages → Delete).

---

## 6. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Contact form / admin fail after deploy | `DATABASE_URL` missing on host | Set it in Netlify env vars, redeploy |
| `/api/health` → `database:"error"` | Wrong URL / password not URL-encoded | Use the pooler string from Supabase → Connect |
| Chat gives short rule-based answers | `AI_API_KEY` unset on host | Add AI env vars (Netlify cannot run the bundled sandbox SDK) |
| Admin login rejected | Wrong `ADMIN_PASSWORD` on host | Set env var, redeploy |
| SEO audit times out | Free-tier function limit (10 s) | Use `PAGESPEED_API_KEY`; audits run via the scheduler instead |
| Scheduled tasks don't run | `CRON_SECRET` unset | Set it; also check Netlify → Functions → `seo-scheduler` logs |

Server logs (Netlify → Functions → API routes) show the precise reason for
every failure.

---

## 7. Data flow

```
Visitor form → /api/contact ──✔── Prisma → Supabase Postgres (durable)
                    │
                    └─✘ (DB unreachable) → Supabase REST mirror (insert-only)
```

Leads are never lost: even if the primary database is unreachable, the REST
mirror stores them, and they appear in the admin panel once connectivity is
restored.
