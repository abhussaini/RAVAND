-- ============================================================================
-- Ravand Tech — Supabase setup script (final, hosting-ready)
--
-- HOW TO USE (only needed for a BRAND-NEW Supabase project)
--   1. Open your Supabase project dashboard → SQL Editor → New query
--   2. Paste this whole file and run it once
--   3. Point the website at the database with DATABASE_URL
--      (Supabase → Connect → Poolers → transaction pooler, port 6543)
--      and deploy. The app detects the tables automatically and seeds
--      an empty database with the real site content on first request.
--
-- SECURITY MODEL (row level security is ENABLED on every table)
--   • public content tables (Service, Project, Post, Testimonial, Stat,
--     Setting) → anon: READ ONLY. Writes go through the app's own
--     Postgres connection (DATABASE_URL), never through the public key.
--   • ContactMessage / Subscriber → anon: INSERT ONLY. Leads can never
--     be read, edited or deleted through the public API key.
--   • SEO assistant tables → no anon policies at all: completely
--     invisible to the public REST API; the app manages them directly.
-- ============================================================================

-- ── Services — "what we do" cards ────────────────────────────────────────────
create table if not exists "Service" (
  "id"      text primary key,
  "slug"    text not null,
  "title"   text not null,                 -- trilingual JSON: {"fa":"..","ps":"..","en":".."}
  "desc"    text not null,                 -- trilingual JSON
  "sticker" text not null default '/stickers/st-services.svg',
  "order"   integer not null default 0,
  "active"  boolean not null default true
);
create unique index if not exists "Service_slug_key" on "Service"("slug");

-- ── Portfolio — "work we're proud of" ────────────────────────────────────────
create table if not exists "Project" (
  "id"      text primary key,
  "slug"    text not null,
  "title"   text not null,
  "cat"     text not null,
  "desc"    text not null default '{}',
  "sticker" text not null default '/stickers/st-portfolio.svg',
  "order"   integer not null default 0,
  "active"  boolean not null default true
);
create unique index if not exists "Project_slug_key" on "Project"("slug");

-- ── Blog posts ───────────────────────────────────────────────────────────────
create table if not exists "Post" (
  "id"        text primary key,
  "slug"      text not null,
  "title"     text not null,
  "cat"       text not null default '{}',
  "excerpt"   text not null default '{}',
  "body"      text not null default '{}',  -- paragraphs joined by blank lines
  "sticker"   text not null default '/stickers/st-blog.svg',
  "readMin"   integer not null default 6,
  "dateLabel" text not null default '{}',
  "published" boolean not null default true,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now()
);
create unique index if not exists "Post_slug_key" on "Post"("slug");

-- ── Testimonials ─────────────────────────────────────────────────────────────
create table if not exists "Testimonial" (
  "id"     text primary key,
  "name"   text not null,
  "role"   text not null,
  "quote"  text not null,
  "order"  integer not null default 0,
  "active" boolean not null default true
);

-- ── Stats — "by the numbers" band ────────────────────────────────────────────
create table if not exists "Stat" (
  "id"     text primary key,
  "value"  integer not null default 0,
  "suffix" text not null default '',
  "label"  text not null,
  "sub"    text not null default '{}',
  "order"  integer not null default 0,
  "active" boolean not null default true
);

-- ── Singleton site settings (row id = 'main') ────────────────────────────────
create table if not exists "Setting" (
  "id"        text primary key default 'main',
  "logoUrl"   text not null default '/images/logo-r.webp',
  "email"     text not null default 'hello@rawandtech.com',
  "phone1"    text not null default '+93777638600',
  "phone2"    text not null default '+93793268319',
  "whatsapp"  text not null default '93777638600',
  "instagram" text not null default 'https://instagram.com/rawandtech',
  "tagline"   text not null default '{}',
  "address"   text not null default '{}',
  "hours"     text not null default '{}'
);

-- ── Contact-form leads (INSERT only — never readable via the public key) ────
create table if not exists "ContactMessage" (
  "id"        text primary key,
  "name"      text not null,
  "email"     text not null,
  "phone"     text,
  "service"   text,
  "message"   text not null,
  "read"      boolean not null default false,
  "createdAt" timestamptz not null default now()
);

-- ── Newsletter subscribers (INSERT only) ─────────────────────────────────────
create table if not exists "Subscriber" (
  "id"        text primary key,
  "email"     text not null,
  "createdAt" timestamptz not null default now()
);
create unique index if not exists "Subscriber_email_key" on "Subscriber"("email");

-- ── Ravand AI SEO Assistant (managed by the app — no public access) ─────────
create table if not exists "SeoAudit" (
  "id"          text primary key,
  "trigger"     text not null default 'manual',
  "status"      text not null default 'running',
  "score"       integer not null default 0,
  "pages"       integer not null default 0,
  "critical"    integer not null default 0,
  "warning"     integer not null default 0,
  "opportunity" integer not null default 0,
  "summary"     text not null default '{}',
  "error"       text not null default '',
  "startedAt"   timestamptz not null default now(),
  "finishedAt"  timestamptz
);
create table if not exists "SeoPageResult" (
  "id"            text primary key,
  "auditId"       text not null,
  "url"           text not null,
  "status"        integer not null default 0,
  "loadMs"        integer not null default 0,
  "redirect"      boolean not null default false,
  "title"         text not null default '',
  "description"   text not null default '',
  "h1"            text not null default '',
  "headings"      text not null default '[]',
  "images"        integer not null default 0,
  "imagesNoAlt"   integer not null default 0,
  "internalLinks" integer not null default 0,
  "externalLinks" integer not null default 0,
  "canonical"     text not null default '',
  "metaRobots"    text not null default '',
  "og"            boolean not null default false,
  "twitter"       boolean not null default false,
  "jsonLd"        boolean not null default false,
  "lang"          text not null default '',
  "viewport"      boolean not null default false,
  "wordCount"     integer not null default 0,
  "contentText"   text not null default '',
  "issues"        text not null default '[]'
);
create index if not exists "SeoPageResult_auditId_idx" on "SeoPageResult"("auditId");
create table if not exists "SeoIssue" (
  "id"         text primary key,
  "auditId"    text,
  "pageUrl"    text not null default '',
  "code"       text not null,
  "severity"   text not null,
  "risk"       text not null default 'medium',
  "title"      text not null,
  "why"        text not null default '',
  "fix"        text not null default '',
  "status"     text not null default 'open',
  "source"     text not null default 'rules',
  "fixPayload" text not null default '{}',
  "createdAt"  timestamptz not null default now(),
  "resolvedAt" timestamptz
);
create index if not exists "SeoIssue_code_page_idx" on "SeoIssue"("code", "pageUrl");
create table if not exists "SeoKeyword" (
  "id"        text primary key,
  "keyword"   text not null,
  "pageUrl"   text not null default '/',
  "lang"      text not null default 'en',
  "notes"     text not null default '',
  "createdAt" timestamptz not null default now()
);
create unique index if not exists "SeoKeyword_keyword_pageUrl_key" on "SeoKeyword"("keyword", "pageUrl");
create table if not exists "SeoOverride" (
  "id"        text primary key,
  "path"      text not null default '/',
  "field"     text not null,
  "value"     text not null,
  "active"    boolean not null default true,
  "createdAt" timestamptz not null default now()
);
create unique index if not exists "SeoOverride_path_field_key" on "SeoOverride"("path", "field");
create table if not exists "SeoChange" (
  "id"         text primary key,
  "issueId"    text,
  "targetType" text not null,
  "targetRef"  text not null default '',
  "oldValue"   text not null default '',
  "newValue"   text not null default '',
  "reason"     text not null default '',
  "status"     text not null default 'applied',
  "createdAt"  timestamptz not null default now()
);
create table if not exists "SeoTaskRun" (
  "id"         text primary key,
  "task"       text not null,
  "status"     text not null,
  "trigger"    text not null default 'manual',
  "log"        text not null default '',
  "startedAt"  timestamptz not null default now(),
  "finishedAt" timestamptz
);
create table if not exists "SeoReport" (
  "id"        text primary key,
  "period"    text not null,
  "summary"   text not null default '{}',
  "createdAt" timestamptz not null default now()
);
create table if not exists "SeoSetting" (
  "id"      text primary key default 'main',
  "baseUrl" text not null default '',
  "psiData" text not null default '{}'
);

-- ============================================================================
-- Row Level Security
-- ============================================================================

-- public content tables: readable by anyone with the public key —
-- but NOT writable through it (the app uses its own Postgres URL)
do $$
declare t text;
begin
  foreach t in array array['Service', 'Project', 'Post', 'Testimonial', 'Stat', 'Setting']
  loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists "public read" on %I', t);
    execute format('drop policy if exists "sync insert" on %I', t);
    execute format('drop policy if exists "sync update" on %I', t);
    execute format('drop policy if exists "sync delete" on %I', t);
    execute format('create policy "public read" on %I for select to anon using (true)', t);
  end loop;
end $$;

-- leads: the public key may only CREATE rows — never read, edit or delete them
alter table "ContactMessage" enable row level security;
drop policy if exists "lead insert" on "ContactMessage";
create policy "lead insert" on "ContactMessage" for insert to anon with check (true);

alter table "Subscriber" enable row level security;
drop policy if exists "subscriber insert" on "Subscriber";
create policy "subscriber insert" on "Subscriber" for insert to anon with check (true);

-- SEO assistant tables: RLS on, zero anon policies → fully private.
-- (Created above with RLS enabled by the app's connection; enforced here too.)
do $$
declare t text;
begin
  foreach t in array array['SeoAudit','SeoPageResult','SeoIssue','SeoKeyword','SeoOverride','SeoChange','SeoTaskRun','SeoReport','SeoSetting']
  loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

-- ============================================================================
-- DONE. The website connects with DATABASE_URL (pooler, port 6543) and:
--   • seeds an empty database automatically on first request
--   • keeps the admin panel, contact form, newsletter and the SEO
--     assistant fully working on Netlify — no filesystem needed
-- ============================================================================
