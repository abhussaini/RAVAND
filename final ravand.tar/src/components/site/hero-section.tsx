"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useT } from "@/lib/i18n";
import { navigate } from "@/lib/router";
import { useUi } from "@/store/use-ui";
import { ArrowGlyph, CarouselDots, PillButton } from "./ui-v2";
import { SiteHeader } from "./site-header";

const SLIDES = [
  {
    img: "/stickers/hamsafar.svg",
    title: "hero.svc_web",
    sub: "hero.svc_web_s",
    preset: "web",
    alt: "Hamsafar Tours — hotel booking website by Ravand Tech",
  },
  {
    img: "/stickers/agentic-platform.svg",
    title: "hero.svc_it",
    sub: "hero.svc_it_s",
    preset: "software",
    alt: "Agentic Platform — automation software by Ravand Tech",
  },
  {
    img: "/stickers/ai-workspace.svg",
    title: "hero.svc_growth",
    sub: "hero.svc_growth_s",
    preset: "seo",
    alt: "AI Workspace — smart analytics product by Ravand Tech",
  },
] as const;

const AVATAR_DOTS = ["#5790e6", "#c2e029", "#0b6e97", "#ffffff"];

/* shared shell for the two hero proof cards — identical paddings,
   border, blur and sticker tile so they read as one system */
function HeroCardShell({
  children,
  onClick,
  label,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  label?: string;
}) {
  const cls =
    "flex w-full items-center gap-4 rounded-card border border-white/15 bg-white/10 p-4 text-start shadow-[0_18px_40px_-12px_rgba(15,47,99,0.55)] backdrop-blur-md transition-colors duration-300 hover:bg-white/15 sm:p-4.5";
  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        aria-label={label}
        className={cls + " cursor-pointer"}
      >
        {children}
      </button>
    );
  }
  return <article className={cls}>{children}</article>;
}

export function HeroSection() {
  const { t } = useT();
  const openContact = useUi((s) => s.openContact);

  /* service mini-slider (functional, manual dots + slow auto-advance) */
  const [si, setSi] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setSi((v) => (v + 1) % SLIDES.length), 5600);
    return () => window.clearInterval(id);
  }, []);

  const slide = SLIDES[si];

  return (
    <section
      id="hero"
      className="relative isolate flex min-h-[36rem] flex-col overflow-hidden rounded-card-lg bg-brand-deep text-white"
      style={{ height: "calc(100svh - 1rem)" }}
    >
      {/* ── brand scene: clean navy field with glow + engineering grid (no photo) ── */}
      <div className="absolute inset-0 -z-10" aria-hidden>
        {/* soft navy depth gradient */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to bottom, rgba(37,99,201,0.28), transparent 40%, rgba(9,30,68,0.6))",
          }}
        />
        {/* brand glows */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(52rem 30rem at 50% 0%, rgba(37,99,201,0.4), transparent 62%)," +
              "radial-gradient(38rem 22rem at 92% 88%, rgba(11,110,151,0.32), transparent 65%)," +
              "radial-gradient(30rem 18rem at 4% 92%, rgba(11,110,151,0.28), transparent 65%)",
          }}
        />
        {/* fine engineering grid */}
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,.7) 1px, transparent 1px)," +
              "linear-gradient(90deg, rgba(255,255,255,.7) 1px, transparent 1px)",
            backgroundSize: "56px 56px",
          }}
        />
      </div>

      <SiteHeader />

      {/* ── centered headline — modern standard hero ──
          Pure CSS entrance: text is painted with the first frame
          (no JS gate), the animation just settles it in place. */}
      <div className="relative z-10 mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center px-6 text-center sm:px-10">
        <span
          className="anim-fade-up inline-flex items-center gap-2.5 rounded-pill border border-white/20 bg-white/10 px-4 py-2 text-[0.72rem] font-medium uppercase tracking-[0.18em] text-white/85 backdrop-blur-sm"
          style={{ animationDelay: "0.08s" }}
        >
          <span aria-hidden className="size-1.5 rounded-pill bg-brand-light" />
          {t("hero.eyebrow")}
        </span>

        {/* one-line headline — accent part with a hand-drawn swash */}
        <h1
          id="hero-title"
          className="font-display mt-5 whitespace-nowrap text-[clamp(1.9rem,6.2vw,5rem)] font-medium leading-[1.08]"
        >
          <span className="block overflow-hidden pb-[0.16em] -mb-[0.16em]">
            <span className="anim-rise block" style={{ animationDelay: "0.16s" }}>
              {t("v2.hero.tag1")}{" "}
              <span className="relative inline-block text-brand-light">
                {t("v2.hero.tag2")}
                <svg
                  viewBox="0 0 220 14"
                  aria-hidden
                  preserveAspectRatio="none"
                  className="absolute inset-x-0 -bottom-[0.14em] h-[0.16em] w-full"
                >
                  <path
                    d="M4 10 C 60 3.5, 160 3.5, 216 9"
                    fill="none"
                    stroke="#c2e029"
                    strokeWidth="5"
                    strokeLinecap="round"
                    pathLength={1}
                    className="anim-swash"
                    style={{ animationDelay: "0.9s" }}
                  />
                </svg>
              </span>
            </span>
          </span>
        </h1>

        <p
          className="anim-fade-up mt-5 max-w-xl text-[0.95rem] leading-relaxed text-white/75 sm:text-base"
          style={{ animationDelay: "0.34s" }}
        >
          {t("hero.description")}
        </p>

        <div
          className="anim-fade-up mt-7 flex flex-wrap items-center justify-center gap-3"
          style={{ animationDelay: "0.44s" }}
        >
          <PillButton variant="light" onClick={() => openContact()}>
            {t("hero.cta_primary")}
          </PillButton>
          <PillButton
            variant="outline"
            onClick={() => navigate("/portfolio")}
            className="border-white/35 text-white hover:border-white hover:bg-white hover:text-brand-deep"
          >
            {t("hero.cta_secondary")}
          </PillButton>
        </div>
      </div>

      {/* ── bottom: two identical proof cards ── */}
      <div className="relative z-10 mx-auto w-full max-w-3xl px-6 pb-7 sm:px-10 sm:pb-10">
        <div className="grid gap-4 sm:grid-cols-2 sm:gap-5">
          {/* stats card — unique big rocket-growth sticker */}
          <div
            className="anim-fade-up min-w-0"
            style={{ animationDelay: "0.54s" }}
          >
            <HeroCardShell>
              <span className="relative grid size-[4.5rem] shrink-0 place-items-center overflow-hidden rounded-xl">
                <Image
                  src="/stickers/rocket-growth.svg"
                  alt="Ravand Tech — 40+ successful projects growth sticker"
                  fill
                  sizes="72px"
                  className="object-cover"
                />
              </span>
              <span className="flex min-w-0 flex-1 flex-col justify-center">
                <span dir="ltr" className="font-display text-2xl font-medium leading-none">
                  40+
                </span>
                <span className="mt-1.5 text-[0.82rem] font-medium leading-snug">
                  {t("stats.projects")}
                </span>
                <span aria-hidden className="mt-2.5 flex -space-x-2 rtl:space-x-reverse">
                  {AVATAR_DOTS.map((c) => (
                    <span
                      key={c}
                      className="size-5 rounded-pill border border-brand-deep/40"
                      style={{ background: c }}
                    />
                  ))}
                </span>
              </span>
            </HeroCardShell>
          </div>

          {/* service card — same shell, clickable, slow slider */}
          <div
            className="anim-fade-up min-w-0"
            style={{ animationDelay: "0.62s" }}
          >
            <div key={si} className="anim-slide-in">
              <HeroCardShell
                onClick={() => openContact(slide.preset)}
                label={t(slide.title)}
              >
                <span className="relative grid size-[4.5rem] shrink-0 place-items-center overflow-hidden rounded-xl">
                  <Image
                    src={slide.img}
                    alt={slide.alt}
                    fill
                    sizes="72px"
                    className="object-cover"
                  />
                </span>
                <span className="flex min-w-0 flex-1 flex-col justify-center">
                  <span className="font-display text-[1.02rem] font-medium leading-snug">
                    {t(slide.title)}
                  </span>
                  <span className="mt-1 truncate text-[0.78rem] leading-snug opacity-80">
                    {t(slide.sub)}
                  </span>
                  <span className="mt-2.5 flex items-center gap-1.5 text-[0.75rem] font-medium text-brand-light">
                    {t("services.cta")}
                    <ArrowGlyph className="size-3.5 rtl:-scale-x-100" />
                  </span>
                </span>
              </HeroCardShell>
            </div>
          </div>
        </div>

        {/* slider dots — shared control row, centered */}
        <div className="mt-4 flex justify-center">
          <CarouselDots
            count={SLIDES.length}
            active={si}
            onSelect={setSi}
            tone="light"
            label="Services"
          />
        </div>
      </div>
    </section>
  );
}
