"use client";

import { useState } from "react";
import {
  ArrowUpRight,
  Check,
  Clock,
  Instagram,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useContent } from "@/lib/content";
import { useT } from "@/lib/i18n";
import { navigate, navigateHomeSection } from "@/lib/router";
import { useUi } from "@/store/use-ui";
import { Reveal, StackedLines } from "./reveal";
import { BlockSticker } from "./sticker";
import { FacebookIcon, WhatsAppIcon } from "./icons";
import { BrandMark, BrandWordmark, Eyebrow, PillButton } from "./ui-v2";

const FALLBACK = {
  email: "hello@rawandtech.com",
  phone1: { display: "0777 638 600", href: "tel:+93777638600" },
  phone2: { display: "0793 268 319", href: "tel:+93793268319" },
  whatsapp: "93777638600",
  instagram: "https://instagram.com/rawandtech",
};

const QUICK_LINKS = [
  { key: "nav.home", to: "/" },
  { key: "nav.services", to: "/services" },
  { key: "nav.portfolio", to: "/portfolio" },
  { key: "nav.blog", to: "/blog" },
  { key: "nav.contact", to: "/contact" },
] as const;

const SERVICE_PRESETS = ["web", "software", "uiux", "shop", "seo", "support"] as const;
const SERVICE_LABELS = [
  "services.web_t",
  "services.soft_t",
  "services.ui_t",
  "services.shop_t",
  "services.seo_t",
  "services.support_t",
] as const;

/**
 * Standard modern footer — navy brand surface, CTA band with the
 * contact sticker, 4-column grid, newsletter (shadcn Input/Label/
 * Button wired to /api/subscribe) and a clean bottom bar.
 * Fully trilingual (fa / ps / en) and DB-driven via /api/content.
 */
export function SiteFooter() {
  const { t } = useT();
  const { content, pick } = useContent();
  const openContact = useUi((s) => s.openContact);
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "ok" | "err">("idle");

  const s = content?.settings;
  const EMAIL = s?.email || FALLBACK.email;
  const PHONES = [
    s?.phone1
      ? { display: s.phone1.replace("+93", "0"), href: `tel:${s.phone1}` }
      : FALLBACK.phone1,
    s?.phone2
      ? { display: s.phone2.replace("+93", "0"), href: `tel:${s.phone2}` }
      : FALLBACK.phone2,
  ];
  const SOCIALS = [
    { label: "WhatsApp", href: `https://wa.me/${s?.whatsapp || FALLBACK.whatsapp}`, icon: WhatsAppIcon },
    { label: "Instagram", href: s?.instagram || FALLBACK.instagram, icon: Instagram },
    { label: "Facebook", href: "https://facebook.com/rawandtech", icon: FacebookIcon },
    { label: "Email", href: `mailto:${EMAIL}`, icon: Mail },
  ];

  const onSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setState("err");
      return;
    }
    setState("sending");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error("subscribe failed");
      setState("ok");
      setEmail("");
    } catch {
      setState("err");
    }
  };

  return (
    <footer
      id="contact"
      className="relative overflow-hidden rounded-card-lg bg-brand-deep text-white"
    >
      <div className="relative z-10 px-6 pt-14 sm:px-10 sm:pt-16">
        {/* ── CTA band ── */}
        <div className="flex flex-col gap-8 border-b border-white/15 pb-12 sm:flex-row sm:items-end sm:justify-between sm:pb-14">
          <div>
            <Eyebrow tone="light">{t("contact.eyebrow")}</Eyebrow>
            <p className="font-display t-footer-cta mt-4 max-w-lg font-medium">
              <StackedLines lines={[t("v2.footer.cta.one")]} stagger={120} />
            </p>
          </div>
          <div className="flex items-end gap-5">
            <BlockSticker src="/stickers/st-contact.svg" alt="" tone="dark" size="sm" delay={0.1} />
            <Reveal from={{ opacity: 0, y: 20 }} delayIn={0.15}>
              <PillButton variant="light" onClick={() => openContact()}>
                {t("nav.cta")}
              </PillButton>
            </Reveal>
          </div>
        </div>

        {/* ── columns ── */}
        <div className="grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_0.9fr_1fr_1.2fr]">
          {/* brand */}
          <div className="max-w-xs">
            <span className="flex items-center gap-2">
              <BrandMark />
              <BrandWordmark className="text-lg" />
            </span>
            <p className="mt-4 text-sm leading-relaxed text-white/65">
              {pick(s?.tagline) || t("footer.tagline")}
            </p>
            <div className="mt-5 flex items-center gap-2.5">
              {SOCIALS.map((soc) => (
                <a
                  key={soc.label}
                  href={soc.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={soc.label}
                  className="grid size-10 place-items-center rounded-pill border border-white/20 text-white/80 transition-[color,background-color,border-color,transform] duration-300 hover:border-white hover:bg-white hover:text-brand-deep hover:-translate-y-[3px]"
                >
                  <soc.icon className="size-4.5" />
                </a>
              ))}
            </div>
          </div>

          {/* quick links — multi-page navigation */}
          <nav aria-label={t("footer.links_t")}>
            <h3 className="display-caps text-xs font-medium uppercase tracking-[0.2em] text-white/50">
              {t("footer.links_t")}
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-white/80">
              {QUICK_LINKS.map((l) => (
                <li key={l.to}>
                  <button
                    type="button"
                    onClick={() =>
                      l.to === "/" ? navigateHomeSection("#hero") : navigate(l.to)
                    }
                    className="group flex cursor-pointer items-center gap-2 transition-colors hover:text-white"
                  >
                    <span
                      aria-hidden
                      className="h-px w-0 bg-brand-light transition-all duration-300 group-hover:w-3"
                    />
                    {t(l.key)}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* services */}
          <nav aria-label={t("footer.services_t")}>
            <h3 className="display-caps text-xs font-medium uppercase tracking-[0.2em] text-white/50">
              {t("footer.services_t")}
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-white/80">
              {SERVICE_PRESETS.map((preset, i) => (
                <li key={preset}>
                  <button
                    type="button"
                    onClick={() => openContact(preset)}
                    className="group flex cursor-pointer items-center gap-2 text-start transition-colors hover:text-white"
                  >
                    <span
                      aria-hidden
                      className="h-px w-0 bg-brand-light transition-all duration-300 group-hover:w-3"
                    />
                    {t(SERVICE_LABELS[i])}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* contact info */}
          <div>
            <h3 className="display-caps text-xs font-medium uppercase tracking-[0.2em] text-white/50">
              {t("contact.info_t")}
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-white/80">
              <li>
                <a
                  href={`mailto:${EMAIL}`}
                  className="flex items-center gap-3 transition-colors hover:text-white"
                >
                  <Mail aria-hidden className="size-4 shrink-0 text-brand-light" strokeWidth={1.7} />
                  {/* ltr on the value only — keeps the icon on the correct
                      side and the row aligned in both LTR & RTL layouts */}
                  <span dir="ltr" className="min-w-0 break-all text-start">
                    {EMAIL}
                  </span>
                </a>
              </li>
              {PHONES.map((p) => (
                <li key={p.href}>
                  <a
                    href={p.href}
                    className="flex items-center gap-3 transition-colors hover:text-white"
                  >
                    <Phone aria-hidden className="size-4 shrink-0 text-brand-light" strokeWidth={1.7} />
                    <span dir="ltr" className="text-start">
                      {p.display}
                    </span>
                  </a>
                </li>
              ))}
              <li className="flex items-start gap-3 text-white/65">
                <MapPin aria-hidden className="mt-0.5 size-4 shrink-0 text-brand-light" strokeWidth={1.7} />
                <span className="text-start leading-relaxed">
                  {pick(s?.address) || t("contact.address")}
                </span>
              </li>
              <li className="flex items-start gap-3 text-white/65">
                <Clock aria-hidden className="mt-0.5 size-4 shrink-0 text-brand-light" strokeWidth={1.7} />
                <span className="text-start leading-relaxed">
                  {pick(s?.hours) || t("contact.hours")}
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* ── newsletter (shadcn Input / Label / Button) ── */}
        <div className="flex flex-col gap-5 border-t border-white/15 py-8 md:flex-row md:items-center md:justify-between">
          <div>
            <h3 className="font-display text-lg font-medium">{t("footer.news_t")}</h3>
            <p className="mt-1 text-sm text-white/60">{t("footer.news_d")}</p>
          </div>
          {state === "ok" ? (
            <p
              className="anim-fade-up inline-flex items-center gap-2 rounded-pill bg-white/10 px-5 py-3 text-sm font-medium text-white"
              role="status"
            >
              <span className="grid size-5 place-items-center rounded-pill bg-brand-light text-brand-deep">
                <Check className="size-3" strokeWidth={3} />
              </span>
              {t("footer.news_ok")}
            </p>
          ) : (
            <form onSubmit={onSubscribe} className="w-full max-w-md space-y-1.5" noValidate>
              <Label
                htmlFor="footer-email"
                className="display-caps text-[0.7rem] uppercase tracking-[0.18em] text-white/60"
              >
                {t("contact.email")}
              </Label>
              <div className="flex gap-2">
                <Input
                  id="footer-email"
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (state === "err") setState("idle");
                  }}
                  placeholder={t("footer.news_ph")}
                  aria-invalid={state === "err"}
                  className="h-11 min-w-0 flex-1 rounded-pill border-white/20 bg-white/10 text-white backdrop-blur-xs placeholder:text-white/40 focus-visible:border-brand-light focus-visible:ring-brand-light/40"
                />
                <Button
                  type="submit"
                  disabled={state === "sending"}
                  className="display-caps h-11 shrink-0 gap-2 rounded-pill bg-white px-5 text-sm font-medium uppercase tracking-wide text-brand-deep hover:bg-brand-light hover:text-white"
                >
                  {t("footer.subscribe")}
                  <Send aria-hidden className="size-3.5 rtl:-scale-x-100" />
                </Button>
              </div>
              {state === "err" && (
                <p role="alert" className="text-xs font-medium text-red-300">
                  {t("footer.news_err")}
                </p>
              )}
            </form>
          )}
        </div>

        {/* ── bottom bar ── */}
        <div className="flex flex-col items-center justify-between gap-3 border-t border-white/15 pb-8 pt-7 text-sm text-white/60 sm:flex-row">
          <p>
            © {new Date().getFullYear()} Ravand Tech. {t("footer.rights")}
          </p>
          <p className="font-medium">{t("footer.made")}</p>
          <nav aria-label="Legal" className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => navigate("/about")}
              className="cursor-pointer transition-colors hover:text-white"
            >
              {t("footer.privacy")}
            </button>
            <button
              type="button"
              onClick={() => navigate("/about")}
              className="inline-flex cursor-pointer items-center gap-1 transition-colors hover:text-white"
            >
              {t("footer.terms")}
              <ArrowUpRight aria-hidden className="size-3.5" />
            </button>
          </nav>
        </div>
      </div>
    </footer>
  );
}
