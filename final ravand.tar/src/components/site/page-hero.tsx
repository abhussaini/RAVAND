"use client";

import { ArrowLeft, ArrowRight } from "lucide-react";
import { useT } from "@/lib/i18n";
import { navigate } from "@/lib/router";
import { BlockSticker } from "./sticker";
import { SiteHeader } from "./site-header";

/**
 * Navy page band for sub-pages: transparent site header on top,
 * title + description with a section sticker opposite the text.
 */
export function PageHero({
  title,
  desc,
  sticker,
  backTo,
  backLabel,
}: {
  title: string;
  desc?: string;
  sticker?: string;
  backTo?: string;
  backLabel?: string;
}) {
  const { isRtl } = useT();
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  return (
    <section className="relative isolate overflow-hidden rounded-card-lg bg-brand-deep text-white">
      {/* glow backdrop (CSS only) */}
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(160deg, #0f2f63 0%, #123a79 48%, #0b2a58 100%), radial-gradient(42rem 22rem at 85% 20%, rgba(37,99,201,0.45), transparent 60%)",
        }}
      />
      <div
        aria-hidden
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.7) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.7) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
        }}
      />

      <div className="relative z-10">
        <SiteHeader />

        <div className="flex flex-col gap-8 px-6 pb-12 pt-10 sm:px-10 sm:pb-16 sm:pt-14 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            {backTo && (
              <button
                type="button"
                onClick={() => navigate(backTo)}
                className="anim-fade-up mb-6 inline-flex cursor-pointer items-center gap-2 text-xs font-medium text-white/70 transition-colors hover:text-white"
                style={{ animationDuration: "0.5s" }}
              >
                <BackIcon className="size-3.5 rtl:-scale-x-100" aria-hidden />
                {backLabel}
              </button>
            )}
            <h1 className="font-display t-section font-medium">
              <span className="block overflow-hidden pb-[0.12em] mb-[-0.12em]">
                <span className="anim-rise block" style={{ animationDuration: "0.8s" }}>
                  {title}
                </span>
              </span>
            </h1>
            {desc && (
              <p
                className="anim-fade-up mt-4 max-w-xl text-[0.95rem] leading-relaxed text-white/75 sm:text-base"
                style={{ animationDuration: "0.6s", animationDelay: "0.2s" }}
              >
                {desc}
              </p>
            )}
          </div>
          {sticker && (
            <BlockSticker src={sticker} alt="" tone="dark" size="lg" delay={0.3} />
          )}
        </div>
      </div>
    </section>
  );
}
