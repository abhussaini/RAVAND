import { NextResponse } from "next/server";
import { z } from "zod";
import { ADMIN_COOKIE, ADMIN_TOKEN, checkPassword } from "@/lib/admin-auth";
import { sameOrigin } from "@/lib/http";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

const LoginSchema = z.object({ password: z.string().min(1).max(200) });

/** POST /api/admin/login — password → httpOnly session cookie. */
export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return NextResponse.json({ ok: false, error: "BAD_ORIGIN" }, { status: 403 });
  }
  /* brute-force protection — 5 attempts per 5 minutes per IP */
  const rl = rateLimit(`admin-login:${clientIp(request)}`, 5, 5 * 60_000);
  if (!rl.ok) {
    return NextResponse.json(
      { ok: false, error: "RATE_LIMITED", retryAfter: rl.retryAfter },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } }
    );
  }

  try {
    const body = await request.json();
    const parsed = LoginSchema.safeParse(body);
    if (!parsed.success || !checkPassword(parsed.data.password)) {
      return NextResponse.json(
        { ok: false, error: "INVALID_PASSWORD" },
        { status: 401 }
      );
    }

    const res = NextResponse.json({ ok: true });
    res.cookies.set(ADMIN_COOKIE, ADMIN_TOKEN, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 14, // 14 days
      /* HTTPS in production (Netlify / VPS) — plain HTTP keeps working
         in local dev sandboxes */
      secure: (request.headers.get("x-forwarded-proto") ?? "").includes("https"),
    });
    return res;
  } catch {
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
