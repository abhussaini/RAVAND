/**
 * Ravand Tech — database seed (run: bun prisma/seed.ts)
 * Content lives in src/lib/seed-data.ts (shared with the production
 * auto-bootstrap, so a fresh Turso database is never blank).
 */
import { PrismaClient } from "@prisma/client";
import {
  J,
  SEED_SERVICES,
  SEED_PROJECTS,
  SEED_POSTS,
  SEED_TESTIMONIALS,
  SEED_STATS,
  SEED_SETTING,
} from "../src/lib/seed-data";

const db = new PrismaClient();

async function main() {
  // settings singleton
  await db.setting.upsert({
    where: { id: "main" },
    update: {},
    create: { ...SEED_SETTING },
  });

  for (const s of SEED_SERVICES)
    await db.service.upsert({ where: { slug: s.slug }, update: {}, create: { ...s, title: J(s.title), desc: J(s.desc) } });
  for (const p of SEED_PROJECTS)
    await db.project.upsert({ where: { slug: p.slug }, update: {}, create: { ...p, title: J(p.title), cat: J(p.cat), desc: J(p.desc) } });
  for (const p of SEED_POSTS)
    await db.post.upsert({ where: { slug: p.slug }, update: {}, create: { ...p, title: J(p.title), cat: J(p.cat), excerpt: J(p.excerpt), body: J(p.body), dateLabel: J(p.dateLabel) } });
  for (const t of SEED_TESTIMONIALS)
    await db.testimonial.create({ data: { ...t, role: J(t.role), quote: J(t.quote) } }).catch(() => null);
  for (const s of SEED_STATS) await db.stat.create({ data: { ...s, label: J(s.label), sub: J(s.sub) } }).catch(() => null);

  const counts = {
    services: await db.service.count(),
    projects: await db.project.count(),
    posts: await db.post.count(),
    testimonials: await db.testimonial.count(),
    stats: await db.stat.count(),
  };
  console.log("Seed complete:", counts);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
