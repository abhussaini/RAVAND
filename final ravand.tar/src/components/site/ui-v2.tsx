"use client";

import { useEffect, useRef } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { navigate } from "@/lib/router";
import { useBrand, useBrandSync } from "@/store/use-brand";

/* ── Brand mark — admin-managed logo (falls back to bundled asset) ── */
export function BrandMark({ className }: { className?: string }) {
  useBrandSync();
  const logoUrl = useBrand((s) => s.logoUrl);
  return (
    <Image
      src={logoUrl}
      alt=""
      width={512}
      height={512}
      className={cn("size-[1.4rem] shrink-0 object-contain", className)}
      aria-hidden
      priority
    />
  );
}

/* ── Brand wordmark ──────────────────────────────────────── */
export function BrandWordmark({ className }: { className?: string }) {
  return (
    <span
      dir="ltr"
      className={cn(
        "font-peyda display-caps inline-flex items-center gap-2 whitespace-nowrap text-[1rem] font-medium uppercase leading-none tracking-[0.2em] text-current",
        className
      )}
    >
      Ravand Tech
    </span>
  );
}

/* ── Secret admin access ───────────────────────────────────
   3 quick taps on the brand open the admin panel; a single tap
   (debounced) goes home like any standard logo link.           */
export function useBrandTap(onSingle?: () => void) {
  const count = useRef(0);
  const timer = useRef<number | null>(null);

  useEffect(
    () => () => {
      if (timer.current) window.clearTimeout(timer.current);
    },
    []
  );

  return () => {
    count.current += 1;
    if (timer.current) window.clearTimeout(timer.current);
    if (count.current >= 3) {
      count.current = 0;
      navigate("/admin");
      return;
    }
    timer.current = window.setTimeout(() => {
      if (count.current === 1) onSingle?.();
      count.current = 0;
    }, 420);
  };
}

/** Logo + wordmark lockup with the built-in secret admin tap. */
export function BrandLockup({
  markClassName,
  wordClassName,
  onSingle,
  className,
}: {
  markClassName?: string;
  wordClassName?: string;
  onSingle?: () => void;
  className?: string;
}) {
  const onTap = useBrandTap(onSingle);
  return (
    <button
      type="button"
      onClick={onTap}
      aria-label="Ravand Tech — home"
      className={cn("flex cursor-pointer items-center gap-2", className)}
    >
      <BrandMark className={markClassName} />
      <BrandWordmark className={wordClassName} />
    </button>
  );
}

/* ── Eyebrow ─────────────────────────────────────────────── */
export function Eyebrow({
  children,
  tone = "dark",
  className,
}: {
  children: React.ReactNode;
  tone?: "dark" | "light";
  className?: string;
}) {
  return (
    <span
      className={cn(
        "display-caps inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.22em]",
        tone === "dark" ? "text-ink-soft" : "text-white/70",
        className
      )}
    >
      <span
        aria-hidden
        className={cn(
          "size-1.5 rounded-pill",
          tone === "dark" ? "bg-brand" : "bg-brand-light"
        )}
      />
      {children}
    </span>
  );
}

/* ── Pill button ─────────────────────────────────────────── */
const ARROW_PATH = "M5 12h14M13 6l6 6-6 6";

export function ArrowGlyph({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className={cn("size-4", className)}
    >
      <path d={ARROW_PATH} />
    </svg>
  );
}

export function PillButton({
  children,
  variant = "solid",
  onClick,
  href,
  className,
  type,
  disabled,
}: {
  children: React.ReactNode;
  variant?: "light" | "solid" | "outline";
  onClick?: () => void;
  href?: string;
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  const styles = cn(
    "display-caps group/pill inline-flex cursor-pointer items-center justify-center gap-2 rounded-pill px-7 py-3.5 text-sm font-medium uppercase tracking-wide transition-colors duration-300",
    variant === "light" && "bg-white text-brand-deep hover:bg-brand-light hover:text-white",
    variant === "solid" && "bg-ink text-white hover:bg-brand-deep",
    variant === "outline" && "border border-current text-ink hover:bg-ink hover:text-white",
    disabled && "pointer-events-none opacity-60",
    className
  );
  const inner = (
    <>
      <span>{children}</span>
      <span
        aria-hidden
        className="inline-flex transition-transform duration-300 group-hover/pill:translate-x-1"
      >
        <ArrowGlyph />
      </span>
    </>
  );
  if (href) {
    return (
      <a href={href} onClick={onClick} className={styles}>
        {inner}
      </a>
    );
  }
  return (
    <button
      type={type ?? "button"}
      onClick={onClick}
      disabled={disabled}
      className={styles}
    >
      {inner}
    </button>
  );
}

/* ── Carousel dots ───────────────────────────────────────── */
export function CarouselDots({
  count,
  active,
  onSelect,
  tone = "dark",
  label,
}: {
  count: number;
  active: number;
  onSelect: (i: number) => void;
  tone?: "dark" | "light";
  label?: string;
}) {
  return (
    <div className="flex items-center gap-2" role="tablist" aria-label={label}>
      {Array.from({ length: count }).map((_, i) => (
        <button
          key={i}
          type="button"
          role="tab"
          aria-selected={i === active}
          aria-current={i === active}
          aria-label={`${i + 1} / ${count}`}
          onClick={() => onSelect(i)}
          className="cursor-pointer p-1.5"
        >
          <span
            className={cn(
              "block h-1.5 rounded-pill transition-all duration-300",
              i === active
                ? "w-5 " + (tone === "dark" ? "bg-ink" : "bg-white")
                : "w-1.5 " + (tone === "dark" ? "bg-ghost" : "bg-white/40")
            )}
          />
        </button>
      ))}
    </div>
  );
}
