import { db, ensureDb } from "@/lib/db";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — core configuration helpers.

   • Base URL resolution (never hardcodes a preview URL as canonical):
       1. SeoSetting.baseUrl  (owner sets it in the dashboard)
       2. SITE_URL env
       3. Netlify-injected URL env (production deploys only)
       4. http://localhost:3000 (sandbox/dev)
   • SSRF protection: every fetch target must match the approved
     base host; only http/https, no credentials, manual redirect
     following with per-hop re-validation.
   ------------------------------------------------------------------ */

export const DEV_BASE = "http://localhost:3000";

const stripSlash = (s: string) => s.replace(/\/+$/, "");

export async function getBaseUrl(): Promise<string> {
  try {
    await ensureDb();
    const s = await db.seoSetting.findUnique({ where: { id: "main" } });
    if (s?.baseUrl) return stripSlash(s.baseUrl);
  } catch {
    /* DB unavailable — fall through to env */
  }
  if (process.env.SITE_URL) return stripSlash(process.env.SITE_URL);
  if (process.env.NETLIFY === "true" && process.env.URL) return stripSlash(process.env.URL);
  return DEV_BASE;
}

/** Validate + normalize a base URL candidate. Returns null when unsafe. */
export function normalizeBase(raw: string): string | null {
  try {
    const u = new URL(raw.trim());
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    if (u.username || u.password) return null;
    return u.origin;
  } catch {
    return null;
  }
}

export function approvedHosts(base: string): Set<string> {
  const hosts = new Set<string>();
  try {
    hosts.add(new URL(base).hostname.toLowerCase());
  } catch {
    /* ignore */
  }
  /* dev sandbox always may talk to its own Next dev server */
  hosts.add("localhost");
  hosts.add("127.0.0.1");
  return hosts;
}

/** SSRF guard — approved hosts only. Returns null for anything else. */
export function safeUrl(raw: string, base: string, allowed: Set<string>): URL | null {
  try {
    const u = new URL(raw, base);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    if (u.username || u.password) return null;
    if (!allowed.has(u.hostname.toLowerCase())) return null;
    return u;
  } catch {
    return null;
  }
}

export interface FetchResult {
  finalUrl: string;
  status: number;
  redirected: boolean;
  ms: number;
  body: string | null;
  contentType: string;
  error?: string;
}

/**
 * Hardened fetch: manual redirects (each hop re-validated against the
 * approved host set), abort timeout, body capped at ~600 KB.
 */
export async function safeFetch(
  rawUrl: string,
  base: string,
  allowed: Set<string>,
  opts: { timeoutMs?: number; maxHops?: number; method?: "GET" | "HEAD" } = {}
): Promise<FetchResult> {
  const { timeoutMs = 8000, maxHops = 3, method = "GET" } = opts;
  const started = Date.now();
  let current: URL | null = safeUrl(rawUrl, base, allowed);

  for (let hop = 0; hop <= maxHops; hop++) {
    if (!current) {
      return {
        finalUrl: rawUrl,
        status: 0,
        redirected: false,
        ms: Date.now() - started,
        body: null,
        contentType: "",
        error: "BLOCKED_UNSAFE_URL",
      };
    }
    let res: Response;
    try {
      res = await fetch(current.toString(), {
        method: hop === 0 ? method : "GET",
        redirect: "manual",
        signal: AbortSignal.timeout(timeoutMs),
        headers: { "User-Agent": "RavandSeoAssistant/1.0 (+site audit)" },
        cache: "no-store",
      });
    } catch (e) {
      const msg = e instanceof Error && e.name === "TimeoutError" ? "TIMEOUT" : "NETWORK_ERROR";
      return {
        finalUrl: current.toString(),
        status: 0,
        redirected: hop > 0,
        ms: Date.now() - started,
        body: null,
        contentType: "",
        error: msg,
      };
    }

    /* follow redirects manually — every hop must stay on approved hosts */
    if (res.status >= 300 && res.status < 400) {
      const loc = res.headers.get("location");
      if (!loc) {
        return {
          finalUrl: current.toString(),
          status: res.status,
          redirected: hop > 0,
          ms: Date.now() - started,
          body: null,
          contentType: res.headers.get("content-type") ?? "",
        };
      }
      const next = safeUrl(loc, current.toString(), allowed);
      if (!next) {
        return {
          finalUrl: current.toString(),
          status: res.status,
          redirected: true,
          ms: Date.now() - started,
          body: null,
          contentType: "",
          error: "REDIRECT_TO_UNAPPROVED_HOST",
        };
      }
      current = next;
      continue;
    }

    let body: string | null = null;
    if (method === "GET") {
      try {
        body = (await res.text()).slice(0, 600_000);
      } catch {
        body = null;
      }
    }
    return {
      finalUrl: current.toString(),
      status: res.status,
      redirected: hop > 0,
      ms: Date.now() - started,
      body,
      contentType: res.headers.get("content-type") ?? "",
    };
  }

  return {
    finalUrl: rawUrl,
    status: 0,
    redirected: true,
    ms: Date.now() - started,
    body: null,
    contentType: "",
    error: "TOO_MANY_REDIRECTS",
  };
}

/** Only the known public routes of the hash-routed site. */
export const KNOWN_ROUTES = [
  "/",
  "/services",
  "/portfolio",
  "/blog",
  "/about",
  "/contact",
] as const;

export function routeFromHash(href: string): string | null {
  if (!href.startsWith("#")) return null;
  const path = href.slice(1) || "/";
  return path.startsWith("/") ? path : `/${path}`;
}
