"use client";

import Image from "next/image";
import { Check } from "lucide-react";
import { useT } from "@/lib/i18n";
import { PageHero } from "../page-hero";
import { SiteFooter } from "../site-footer";
import { ProcessStrip } from "../process-strip";
import { StatsBanner } from "../stats-banner";
import { Reveal } from "../reveal";
import { Eyebrow } from "../ui-v2";

const VALUES = [
  { t: "why.f1_t", d: "why.f1_d" },
  { t: "why.f2_t", d: "why.f2_d" },
  { t: "why.f3_t", d: "why.f3_d" },
  { t: "why.f4_t", d: "why.f4_d" },
  { t: "why.f5_t", d: "why.f5_d" },
  { t: "why.f6_t", d: "why.f6_d" },
] as const;

const CHECKS = ["why.check1", "why.check2", "why.check3", "why.check4"] as const;

/** About page — story, values, process, stats. */
export function AboutPage() {
  const { t } = useT();

  return (
    <>
      <main className="flex-1">
        <PageHero
          title={t("why.badge_t")}
          desc={t("why.badge_d")}
          sticker="/stickers/st-why.svg"
          backTo="/"
          backLabel={t("nav.home")}
        />

        {/* story + checks */}
        <section className="bg-white px-6 py-20 sm:px-10 sm:py-24">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <Reveal from={{ opacity: 0, y: 26 }}>
              <Eyebrow>{t("why.eyebrow")}</Eyebrow>
              <h2 className="font-display t-section mt-4 font-medium">{t("why.title")}</h2>
              <p className="mt-4 text-[0.95rem] leading-relaxed text-ink-soft sm:text-base">{t("why.desc")}</p>
              <ul className="mt-8 grid gap-3 sm:grid-cols-2">
                {CHECKS.map((c, i) => (
                  <Reveal key={c} from={{ opacity: 0, x: 14 }} delayIn={i * 0.07}>
                    <li className="flex items-center gap-3 rounded-xl bg-surface px-4 py-3 text-sm font-medium">
                      <span aria-hidden className="grid size-6 shrink-0 place-items-center rounded-pill bg-brand text-white">
                        <Check className="size-3.5" strokeWidth={3} />
                      </span>
                      {t(c)}
                    </li>
                  </Reveal>
                ))}
              </ul>
            </Reveal>
            <Reveal from={{ opacity: 0, scale: 0.94 }} delayIn={0.15} className="justify-self-center">
              <div
                className="anim-float-slow grid place-items-center rounded-card-lg bg-surface p-10"
              >
                <Image
                  src="/stickers/st-services.svg"
                  alt=""
                  width={260}
                  height={260}
                  className="size-56 object-contain sm:size-64"
                  sizes="256px"
                />
              </div>
            </Reveal>
          </div>

          {/* values grid */}
          <div className="mt-16">
            <ul className="grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3">
              {VALUES.map((v, i) => (
                <li key={v.t}>
                  <Reveal from={{ opacity: 0, y: 30 }} delayIn={(i % 3) * 0.08} className="h-full">
                    <article
                      className="h-full rounded-card border border-hairline bg-surface p-6 transition-[color,border-color,transform] duration-300 hover:border-brand/35 hover:-translate-y-1.5"
                    >
                      <span dir="ltr" aria-hidden className="font-display text-sm font-medium text-ghost">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <h3 className="font-display mt-2 text-base font-medium leading-snug sm:text-lg">{t(v.t)}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-ink-soft">{t(v.d)}</p>
                    </article>
                  </Reveal>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <ProcessStrip />
        <StatsBanner />
      </main>
      <SiteFooter />
    </>
  );
}
