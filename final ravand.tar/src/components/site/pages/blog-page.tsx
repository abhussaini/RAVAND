"use client";

import { useT } from "@/lib/i18n";
import { BlogSection } from "../blog-section";
import { PageHero } from "../page-hero";
import { SiteFooter } from "../site-footer";

/** Blog index — hero band + full post grid. */
export function BlogPage() {
  const { t } = useT();

  return (
    <>
      <main className="flex-1">
        <PageHero
          title={t("v2.blog.one")}
          desc={t("blog.desc")}
          sticker="/stickers/st-blog.svg"
          backTo="/"
          backLabel={t("nav.home")}
        />
        <BlogSection showHeader={false} eager={2} />
      </main>
      <SiteFooter />
    </>
  );
}
