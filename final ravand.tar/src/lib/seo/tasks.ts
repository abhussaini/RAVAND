import { db, ensureDb } from "@/lib/db";
import { getBaseUrl, approvedHosts, safeFetch } from "./config";
import { runAudit } from "./audit";
import { createReport } from "./reports";
import { issueText, type TextLang } from "./audit-texts";
import { cleanText } from "./assistant";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — automation engine.

   daily   → availability + robots + sitemap + key metadata checks
   weekly  → full audit + weekly report
   monthly → full audit + recurring-issue comparison + monthly report

   Execution model:
   • Runs in-process via POST /api/seo/tasks/run (admin or cron secret).
   • On Netlify, the scheduled function (netlify/functions/seo-scheduler)
     calls that endpoint once per day; due-ness is decided HERE by the
     last successful run, so missed schedules self-heal and no duplicate
     work happens.
   • Every run is logged in SeoTaskRun — failures are visible, never
     reported as completed.
   ------------------------------------------------------------------ */

const INTERVALS: Record<string, number> = {
  daily: 20 * 3600_000,
  weekly: 6 * 86_400_000,
  monthly: 27 * 86_400_000,
};

async function lastSuccess(task: string) {
  return db.seoTaskRun.findFirst({
    where: { task, status: "done" },
    orderBy: { startedAt: "desc" },
  });
}

async function quickCheck(lang: TextLang): Promise<string> {
  const base = await getBaseUrl();
  const allowed = approvedHosts(base);
  const log: Record<string, unknown> = { baseUrl: base };

  const home = await safeFetch(`${base}/`, base, allowed, { timeoutMs: 12_000 });
  log.home = { status: home.status, ms: home.ms };
  if (home.status !== 200 || !home.body) {
    await upsertSimple("SITE_UNREACHABLE", "", "critical", lang);
    return JSON.stringify({ ok: false, ...log });
  }

  const robots = await safeFetch(`${base}/robots.txt`, base, allowed, { timeoutMs: 6000 });
  const sitemap = await safeFetch(`${base}/sitemap.xml`, base, allowed, { timeoutMs: 8000 });
  log.robots = { status: robots.status };
  log.sitemap = { status: sitemap.status };

  const html = home.body;
  const hasTitle = /<title[^>]*>\s*\S/i.test(html);
  const hasDesc = /<meta[^>]+name\s*=\s*["']description["'][^>]+content\s*=\s*["']\s*\S/i.test(html);
  const noindex = /<meta[^>]+name\s*=\s*["']robots["'][^>]+content\s*=\s*["'][^"']*noindex/i.test(html);

  if (!hasTitle) await upsertSimple("MISSING_TITLE", "/", "critical", lang);
  if (!hasDesc) await upsertSimple("MISSING_DESCRIPTION", "/", "critical", lang);
  if (noindex) await upsertSimple("ROBOTS_NOINDEX", "/", "critical", lang);
  if (robots.status !== 200) await upsertSimple("ROBOTS_MISSING", "", "warning", lang);
  if (sitemap.status !== 200) await upsertSimple("SITEMAP_MISSING", "", "critical", lang);

  log.checks = { hasTitle, hasDesc, noindex };
  return JSON.stringify({ ok: true, ...log });
}

async function upsertSimple(code: string, pageUrl: string, severity: string, lang: TextLang) {
  const text = issueText(code, lang);
  const existing = await db.seoIssue.findFirst({ where: { code, pageUrl }, orderBy: { createdAt: "desc" } });
  if (existing && existing.status !== "ignored" && existing.status !== "resolved") {
    await db.seoIssue.update({
      where: { id: existing.id },
      data: { title: text.title, why: text.why, fix: text.fix },
    });
    return;
  }
  if (existing?.status === "ignored") return;
  await db.seoIssue.create({
    data: { pageUrl, code, severity, risk: "high", title: text.title, why: text.why, fix: text.fix, status: "open" },
  });
}

export async function runTask(
  task: "daily" | "weekly" | "monthly",
  trigger: "manual" | "schedule",
  lang: TextLang = "en"
): Promise<{ ok: boolean; runId: string; log: string }> {
  await ensureDb();
  const run = await db.seoTaskRun.create({
    data: { task, status: "running", trigger },
  });

  let ok = false;
  let log = "";
  try {
    if (task === "daily") {
      log = await quickCheck(lang);
      ok = JSON.parse(log).ok === true;
    } else {
      const outcome = await runAudit(task === "weekly" ? "weekly" : "monthly", lang);
      const reportId = outcome.status === "done" ? await createReport(task === "weekly" ? "weekly" : "monthly") : null;
      ok = outcome.status === "done";
      log = JSON.stringify({ ok, auditId: outcome.auditId, score: outcome.score, critical: outcome.critical, warning: outcome.warning, opportunity: outcome.opportunity, reportId, error: outcome.error ?? "" });
    }
  } catch (e) {
    ok = false;
    log = JSON.stringify({ ok: false, error: cleanText(e instanceof Error ? e.message : String(e), 300) });
  }

  await db.seoTaskRun.update({
    where: { id: run.id },
    data: { status: ok ? "done" : "failed", log: cleanText(log, 4000), finishedAt: new Date() },
  });
  return { ok, runId: run.id, log };
}

/** Run every task whose interval has elapsed (schedule trigger entry). */
export async function runDueTasks(
  trigger: "manual" | "schedule",
  lang: TextLang = "en"
): Promise<{ ran: { task: string; ok: boolean }[]; skipped: string[] }> {
  await ensureDb();
  const ran: { task: string; ok: boolean }[] = [];
  const skipped: string[] = [];
  for (const task of ["daily", "weekly", "monthly"] as const) {
    const last = await lastSuccess(task);
    if (last && Date.now() - last.startedAt.getTime() < INTERVALS[task]) {
      skipped.push(task);
      continue;
    }
    const r = await runTask(task, trigger, lang);
    ran.push({ task, ok: r.ok });
  }
  return { ran, skipped };
}

/** Due-ness preview for the dashboard (no execution). */
export async function taskStatuses(): Promise<
  { task: string; lastDone: string | null; nextDue: string | null; lastStatus: string | null }[]
> {
  await ensureDb();
  const out: { task: string; lastDone: string | null; nextDue: string | null; lastStatus: string | null }[] = [];
  for (const task of ["daily", "weekly", "monthly"] as const) {
    const lastDone = await lastSuccess(task);
    const lastAny = await db.seoTaskRun.findFirst({ where: { task }, orderBy: { startedAt: "desc" } });
    out.push({
      task,
      lastDone: lastDone?.startedAt.toISOString() ?? null,
      nextDue: lastDone ? new Date(lastDone.startedAt.getTime() + INTERVALS[task]).toISOString() : null,
      lastStatus: lastAny?.status ?? null,
    });
  }
  return out;
}
