import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { isAdmin } from "@/lib/admin-auth";
import { sameOrigin } from "@/lib/http";
import { ensureSupabaseSync, mirrorUpsert, resourceTable } from "@/lib/store";
import { isResource, readOnly, resourceSchemas, type ResourceKey } from "@/lib/admin-resources";

export const dynamic = "force-dynamic";

const deny = () =>
  NextResponse.json({ ok: false, error: "UNAUTHORIZED" }, { status: 401 });

type AnyModel = {
  findMany: (a?: Record<string, unknown>) => Promise<unknown[]>;
  create: (a: { data: Record<string, unknown> }) => Promise<Record<string, unknown>>;
};

/** Editable resources + read-only listings (subscribers, messages). */
type ListableKey = ResourceKey | "subscribers" | "messages";

function model(key: ListableKey): AnyModel {
  switch (key) {
    case "services":
      return db.service as unknown as AnyModel;
    case "projects":
      return db.project as unknown as AnyModel;
    case "posts":
      return db.post as unknown as AnyModel;
    case "testimonials":
      return db.testimonial as unknown as AnyModel;
    case "stats":
      return db.stat as unknown as AnyModel;
    case "subscribers":
      return db.subscriber as unknown as AnyModel;
    case "messages":
      return db.contactMessage as unknown as AnyModel;
  }
}

const LIST_ORDER: Record<ListableKey, Record<string, string>> = {
  services: { order: "asc" },
  projects: { order: "asc" },
  posts: { createdAt: "desc" },
  testimonials: { order: "asc" },
  stats: { order: "asc" },
  subscribers: { createdAt: "desc" },
  messages: { createdAt: "desc" },
};

/** GET /api/admin/[resource] — list (admin only). */
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ resource: string }> }
) {
  if (!(await isAdmin())) return deny();
  const { resource } = await params;
  if (!isResource(resource) && !readOnly.has(resource))
    return NextResponse.json({ ok: false, error: "NOT_FOUND" }, { status: 404 });
  try {
    await ensureDb();
    /* lazy Supabase mirror (runs at most once per process) */
    ensureSupabaseSync();
    const items = await model(resource as ListableKey).findMany({
      orderBy: LIST_ORDER[resource as ListableKey],
    });
    return NextResponse.json({ ok: true, items });
  } catch (error) {
    console.error(`[admin/${resource}] list failed:`, error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}

/** POST /api/admin/[resource] — create (admin only, editable resources). */
export async function POST(
  req: Request,
  { params }: { params: Promise<{ resource: string }> }
) {
  if (!(await isAdmin()) || !sameOrigin(req)) return deny();
  const { resource } = await params;
  if (!isResource(resource))
    return NextResponse.json({ ok: false, error: "NOT_FOUND" }, { status: 404 });

  try {
    await ensureDb();
    const body = await req.json();
    const parsed = resourceSchemas[resource].safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: "VALIDATION", issues: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }
    const created = await model(resource).create({ data: parsed.data as Record<string, unknown> });
    /* mirror the new row into Supabase (best-effort) */
    const table = resourceTable(resource);
    if (table) mirrorUpsert(table, created);
    return NextResponse.json({ ok: true, item: created }, { status: 201 });
  } catch (error) {
    const msg = String(error);
    if (msg.includes("Unique")) {
      return NextResponse.json({ ok: false, error: "DUPLICATE_SLUG" }, { status: 409 });
    }
    console.error(`[admin/${resource}] create failed:`, error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
