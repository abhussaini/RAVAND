import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

/** GET /api/admin/session — is the current visitor authenticated? */
export async function GET() {
  return NextResponse.json({ ok: true, authed: await isAdmin() });
}
