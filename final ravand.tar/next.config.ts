import type { NextConfig } from "next";

/* Security headers applied to every route (production hardening).
   CSP: inline styles are required by framer-motion/Next hydration;
   inline scripts are required by the App Router hydration payload —
   both stay same-origin, external script/image origins are blocked. */
const SECURITY_HEADERS = [
  { key: "X-Frame-Options", value: "DENY" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "X-DNS-Prefetch-Control", value: "on" },
  {
    key: "Permissions-Policy",
    value: "camera=(), microphone=(), geolocation=(), interest-cohort=()",
  },
  {
    key: "Strict-Transport-Security",
    value: "max-age=63072000; includeSubDomains; preload",
  },
  {
    key: "Content-Security-Policy",
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline'",
      /* fonts are self-hosted via next/font — no external origins needed */
      "style-src 'self' 'unsafe-inline'",
      "font-src 'self' data:",
      "img-src 'self' data: blob:",
      "connect-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
      "upgrade-insecure-requests",
    ].join("; "),
  },
];

/* On Netlify the official Next.js runtime performs its own packaging —
   `output: "standalone"` there causes deploy failures. Standalone is
   kept for VPS/Docker hosting. */
const isNetlify = process.env.NETLIFY === "true";

const nextConfig: NextConfig = {
  output: isNetlify ? undefined : "standalone",
  /* Full source maps for first-party JS — only downloaded with devtools
     open; resolves the "Missing source maps" Lighthouse audit. */
  productionBrowserSourceMaps: true,
  experimental: {
    /* smaller client bundles — per-icon imports instead of the barrel */
    optimizePackageImports: ["lucide-react"],
  },
  async headers() {
    return [
      { source: "/:path*", headers: SECURITY_HEADERS },
      /* efficient cache lifetimes — static assets are fingerprinted,
         so they can be cached immutably by every host (Lighthouse audit) */
      {
        source: "/_next/static/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }],
      },
      {
        source: "/stickers/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }],
      },
      {
        source: "/images/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }],
      },
      {
        source: "/icons/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }],
      },
      {
        source: "/manifest.webmanifest",
        headers: [{ key: "Cache-Control", value: "public, max-age=3600" }],
      },
    ];
  },
  images: {
    /* local, trusted SVG stickers — served through next/image sizing */
    dangerouslyAllowSVG: true,
    contentDispositionType: "attachment",
    contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
