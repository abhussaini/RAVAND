"use client";

import { useT } from "@/lib/i18n";
import { useUi } from "@/store/use-ui";
import { PortfolioGrid } from "../portfolio-section";
import { PageHero } from "../page-hero";
import { SiteFooter } from "../site-footer";
import { Reveal } from "../reveal";
import { PillButton } from "../ui-v2";
import { StatsBanner } from "../stats-banner";

/** Portfolio page — hero band, full work grid, stats, CTA. */
export function PortfolioPage() {
  const { t } = useT();
  const openContact = useUi((s) => s.openContact);

  return (
    <>
      <main className="flex-1">
        <PageHero
          title={t("portfolio.title")}
          desc={t("portfolio.desc")}
          sticker="/stickers/st-portfolio.svg"
          backTo="/"
          backLabel={t("nav.home")}
        />
        <PortfolioGrid />
        <StatsBanner />

        {/* CTA band */}
        <section className="bg-white px-6 pb-20 pt-16 sm:px-10 sm:pb-24">
          <Reveal from={{ opacity: 0, y: 24 }}>
            <div className="flex flex-col items-start justify-between gap-6 rounded-card-lg bg-surface px-8 py-12 sm:flex-row sm:items-center sm:px-12">
              <div>
                <h2 className="font-display t-section font-medium">{t("portfolio.cta_title")}</h2>
                <p className="mt-3 max-w-lg text-sm leading-relaxed text-ink-soft">{t("portfolio.cta_desc")}</p>
              </div>
              <PillButton variant="solid" onClick={() => openContact()}>
                {t("portfolio.cta_button")}
              </PillButton>
            </div>
          </Reveal>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
