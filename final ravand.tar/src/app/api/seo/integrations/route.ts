import { NextResponse } from "next/server";
import { deny, guard } from "@/lib/seo/guard";
import { integrationStatuses } from "@/lib/seo/integrations";

export const dynamic = "force-dynamic";

/* GET /api/seo/integrations — honest connection statuses + setup steps. */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  try {
    const integrations = await integrationStatuses();
    return NextResponse.json({ ok: true, integrations });
  } catch (error) {
    console.error("[seo/integrations] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
