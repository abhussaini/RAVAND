"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { cn } from "@/lib/utils";

/* ── Hydration-safe mounted flag ───────────────────────────
   false on the server AND during the hydration render, true
   after mount. Portals (document.body targets) must wait for
   this or React logs a hydration mismatch (#418). */
const emptySubscribe = () => () => {};
export function useMounted(): boolean {
  return useSyncExternalStore(emptySubscribe, () => true, () => false);
}

/* ── Shared motion tokens ──────────────────────────────────
   The whole site animates with pure CSS transitions and a
   tiny IntersectionObserver — no JS animation runtime. This
   keeps hydration cheap (TBT/LCP) while matching the design
   spec's expo-out feel. */

const REVEAL_TRANSITION =
  "opacity 0.55s ease, transform 0.9s cubic-bezier(0.16, 1, 0.3, 1)";

type FromState = { opacity?: number; y?: number; x?: number; scale?: number };

function hiddenStyle(from: Required<FromState>): React.CSSProperties {
  const t: string[] = [];
  if (from.x) t.push(`translate3d(${from.x}px,0,0)`);
  if (from.y) t.push(`translate3d(0,${from.y}px,0)`);
  if (from.scale !== 1) t.push(`scale(${from.scale})`);
  return {
    opacity: from.opacity,
    transform: t.length ? t.join(" ") : "none",
  };
}

/* ── In-view reveal (replaces framer whileInView) ────────── */
export function Reveal({
  children,
  className,
  from,
  delayIn = 0,
  once = true,
  amount = 0.25,
}: {
  children: React.ReactNode;
  className?: string;
  /** defaults to {opacity:0, y:28} */
  from?: FromState;
  delayIn?: number;
  once?: boolean;
  amount?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  const spec = {
    opacity: from?.opacity ?? 0,
    y: from?.y ?? 0,
    x: from?.x ?? 0,
    scale: from?.scale ?? 1,
  } as Required<FromState>;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setShown(true);
            if (once) io.disconnect();
          } else if (!once) {
            setShown(false);
          }
        }
      },
      { threshold: amount }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [once, amount]);

  return (
    <div
      ref={ref}
      className={className}
      style={
        shown
          ? { transition: REVEAL_TRANSITION, transitionDelay: `${delayIn}s` }
          : {
              ...hiddenStyle(spec),
              transition: REVEAL_TRANSITION,
              transitionDelay: `${delayIn}s`,
            }
      }
    >
      {children}
    </div>
  );
}

/* shared clip-box style: padding keeps descenders from being cut */
const CLIP_STYLE = { paddingBottom: "0.14em", marginBottom: "-0.14em" } as const;

/* ── Stacked lines clip-mask reveal ("StackedLines") ─────── */
export function StackedLines({
  lines,
  className,
  lineClassName,
  stagger = 120,
  baseDelay = 0,
  duration = 0.95,
  gated = false,
  open = true,
  once = true,
  amount = 0.2,
}: {
  lines: string[];
  className?: string;
  lineClassName?: string;
  stagger?: number;
  baseDelay?: number;
  duration?: number;
  gated?: boolean;
  open?: boolean;
  once?: boolean;
  amount?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    if (gated) return; /* parent drives `open` directly */
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setInView(true);
            if (once) io.disconnect();
          } else if (!once) {
            setInView(false);
          }
        }
      },
      { threshold: amount }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [gated, once, amount]);

  const visible = gated ? open : inView;

  return (
    <span ref={ref} className={cn("block", className)}>
      {lines.map((l, i) => (
        <span key={i} className="block overflow-hidden" style={CLIP_STYLE}>
          <span
            className={cn("block", lineClassName)}
            style={{
              transform: visible ? "translate3d(0,0,0)" : "translate3d(0,115%,0)",
              opacity: visible ? 1 : 0,
              transition: `transform ${duration}s cubic-bezier(0.16, 1, 0.3, 1), opacity ${duration}s ease`,
              transitionDelay: `${baseDelay / 1000 + (i * stagger) / 1000}s`,
            }}
          >
            {l || "\u00A0"}
          </span>
        </span>
      ))}
    </span>
  );
}

/* ── One-shot in-view hook (counters, custom reveals) ────── */
export function useInViewOnce<T extends Element>(amount = 0.3) {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setInView(true);
            io.disconnect();
          }
        }
      },
      { threshold: amount }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [amount]);
  return [ref, inView] as const;
}

/* ── Overlays stay mounted and toggle visibility via CSS classes —
   real enter/exit transitions with zero unmount cost. ────── */
