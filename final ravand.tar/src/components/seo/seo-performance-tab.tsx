"use client";

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { BarChart3, Download, FileText, Gauge, Loader2, Printer } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { fmtDate, seoApi, type PsiData, type ReportRow, type ReportSummaryData } from "./seo-api";
import { Badge, EmptyState, Loading, ScoreRing, SeoCard, type SeoTabProps } from "./seo-ui";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — Performance (G) + Reports (H) tabs.
   Performance shows ONLY real Google PSI results; failures are shown
   honestly. Reports are generated from stored audit data with CSV
   download + browser print for PDF.
   ------------------------------------------------------------------ */

const PSI_LABELS: Record<string, string> = {
  "largest-contentful-paint": "LCP",
  "cumulative-layout-shift": "CLS",
  "total-blocking-time": "TBT",
  "first-contentful-paint": "FCP",
  "speed-index": "SI",
  interactive: "TTI",
};

export function PerformanceTab({
  lang,
  t,
  initialTab,
}: Omit<SeoTabProps, "dir"> & { initialTab: "performance" | "reports" }) {
  const qc = useQueryClient();
  const [subTab, setSubTab] = useState<"performance" | "reports">(initialTab);
  const [strategy, setStrategy] = useState<"mobile" | "desktop">("mobile");
  const [psi, setPsi] = useState<PsiData | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  /* ---------- performance ---------- */
  const psiStatus = useQuery({
    queryKey: ["seo-settings-flags"],
    queryFn: () =>
      seoApi<{ ok: true; settings: { psiKey: boolean } }>("/api/seo/settings"),
  });

  const runPsi = useMutation({
    mutationFn: () => seoApi<{ ok: true; result: PsiData }>(`/api/seo/pagespeed?strategy=${strategy}`),
    onSuccess: (d) => {
      setPsi(d.result);
      if (!d.result.ok) toast.error(`${t("s.psi_error")}: ${d.result.error ?? ""}`);
    },
    onError: (e: Error) => {
      if (e.message === "RATE_LIMITED")
        toast.error(lang === "fa" ? "سقف درخواست پر است — کمی بعد تلاش کنید." : "Request quota reached — retry soon.");
      else toast.error(t("s.error"));
    },
  });

  /* ---------- reports ---------- */
  const reports = useQuery({
    queryKey: ["seo-reports"],
    queryFn: () => seoApi<{ ok: true; reports: ReportRow[] }>("/api/seo/reports"),
    refetchOnMount: "always",
    enabled: subTab === "reports",
  });

  const createReport = useMutation({
    mutationFn: (period: "weekly" | "monthly") =>
      seoApi<{ ok: true; id: string }>("/api/seo/reports", { method: "POST", body: JSON.stringify({ period }) }),
    onSuccess: () => {
      toast.success(t("s.rep_generate"));
      qc.invalidateQueries({ queryKey: ["seo-reports"] });
    },
    onError: (e: Error) => {
      if (e.message === "RATE_LIMITED") toast.error(t("s.error"));
      else toast.error(t("s.error"));
    },
  });

  return (
    <div className="grid grid-cols-1 gap-4 lg:gap-6">
      <div className="flex gap-1.5">
        {(
          [
            { key: "performance", label: t("s.tab_performance"), icon: Gauge },
            { key: "reports", label: t("s.tab_reports"), icon: BarChart3 },
          ] as const
        ).map((x) => (
          <button
            key={x.key}
            type="button"
            onClick={() => setSubTab(x.key)}
            className={`inline-flex cursor-pointer items-center gap-1.5 rounded-pill px-3.5 py-2 text-sm font-medium transition-colors ${
              subTab === x.key ? "bg-brand-deep text-white" : "bg-white text-ink-soft hover:bg-surface"
            }`}
          >
            <x.icon className="size-4" aria-hidden />
            {x.label}
          </button>
        ))}
      </div>

      {subTab === "performance" ? (
        <>
          <SeoCard
            title={t("s.psi_run")}
            icon={Gauge}
            action={
              <div className="flex items-center gap-1.5">
                {(["mobile", "desktop"] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setStrategy(st)}
                    className={`cursor-pointer rounded-pill px-3 py-1.5 text-xs font-medium transition-colors ${
                      strategy === st ? "bg-brand text-white" : "bg-surface text-ink-soft hover:bg-hairline"
                    }`}
                  >
                    {st === "mobile" ? t("s.psi_mobile") : t("s.psi_desktop")}
                  </button>
                ))}
                <Button
                  onClick={() => runPsi.mutate()}
                  disabled={runPsi.isPending}
                  className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
                >
                  {runPsi.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Gauge className="size-4" aria-hidden />}
                  {t("s.psi_run")}
                </Button>
              </div>
            }
          >
            <p className="text-sm text-ink-soft">
              {psiStatus.data?.settings.psiKey ? "PageSpeed Insights API ✓" : t("s.psi_nokey")}
            </p>

            {runPsi.isPending ? <Loading label={t("s.loading")} /> : null}

            {!runPsi.isPending && !psi ? (
              <EmptyState icon={Gauge} text={t("s.psi_nodata")} />
            ) : null}

            {!runPsi.isPending && psi && !psi.ok ? (
              <div className="mt-3 rounded-card bg-red-50 p-3 text-sm text-red-700">
                {t("s.psi_error")}: {psi.error}
                {psi.error === "QUOTA_EXCEEDED"
                  ? lang === "fa"
                    ? " — سقف رایگان گوگل پر شده؛ چند ساعت بعد یا با کلید API تلاش کنید."
                    : " — Google free quota reached; retry later or configure PAGESPEED_API_KEY."
                  : ""}
              </div>
            ) : null}

            {!runPsi.isPending && psi && psi.ok ? (
              <div className="mt-4 grid gap-4">
                <div className="flex flex-wrap items-center gap-6">
                  <ScoreRing score={psi.performance ?? 0} label="/100" />
                  <div className="text-xs text-ink-soft">
                    <p>
                      {psi.strategy === "mobile" ? t("s.psi_mobile") : t("s.psi_desktop")} · {fmtDate(new Date(psi.fetchedAt).toISOString(), lang)}
                    </p>
                    <p dir="ltr" className="mt-0.5">
                      {psi.url}
                    </p>
                  </div>
                </div>
                {psi.metrics && Object.keys(psi.metrics).length > 0 ? (
                  <div>
                    <h4 className="mb-2 text-sm font-semibold text-brand-deep">{t("s.psi_metrics")}</h4>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
                      {Object.entries(psi.metrics).map(([id, m]) => (
                        <div key={id} className="rounded-card border border-hairline bg-surface p-3 text-center">
                          <p className="text-[10px] font-medium text-ink-soft">{PSI_LABELS[id] ?? id}</p>
                          <p className="mt-1 font-display text-sm font-bold text-ink" dir="ltr">
                            {m.display}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : null}
                {psi.fieldData && Object.keys(psi.fieldData).length > 0 ? (
                  <div>
                    <h4 className="mb-2 text-sm font-semibold text-brand-deep">{t("s.psi_field")}</h4>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                      {Object.entries(psi.fieldData).map(([id, m]) => (
                        <div key={id} className="rounded-card border border-hairline p-3 text-center">
                          <p className="truncate text-[10px] font-medium text-ink-soft" dir="ltr">
                            {id}
                          </p>
                          <p className="mt-1 font-display text-sm font-bold text-ink" dir="ltr">
                            {m.display}
                          </p>
                          <p className="text-[10px] text-ink-soft">{m.percentile}%</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : null}
                {psi.opportunities && psi.opportunities.length > 0 ? (
                  <div>
                    <h4 className="mb-2 text-sm font-semibold text-brand-deep">{t("s.psi_opps")}</h4>
                    <ul className="grid gap-1.5">
                      {psi.opportunities.map((o) => (
                        <li key={o.id} className="flex items-center justify-between gap-2 rounded-card border border-hairline p-2.5 text-sm">
                          <span dir="auto">{o.title}</span>
                          <Badge kind="opportunity">{o.display || o.id}</Badge>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
              </div>
            ) : null}
          </SeoCard>
        </>
      ) : (
        <>
          <SeoCard
            title={t("s.rep_generate")}
            icon={BarChart3}
            action={
              <div className="flex gap-1.5">
                <Button
                  variant="outline"
                  onClick={() => createReport.mutate("weekly")}
                  disabled={createReport.isPending}
                  className="cursor-pointer rounded-pill"
                >
                  {t("s.rep_weekly")}
                </Button>
                <Button
                  onClick={() => createReport.mutate("monthly")}
                  disabled={createReport.isPending}
                  className="cursor-pointer rounded-pill bg-brand text-white hover:bg-brand-deep"
                >
                  {t("s.rep_monthly")}
                </Button>
              </div>
            }
          >
            <p className="text-sm text-ink-soft">
              {lang === "fa"
                ? "گزارش‌ها از داده‌های واقعی ارزیابی‌ها ساخته می‌شوند؛ خروجی CSV قابل دانلود و چاپ/PDF است."
                : "Reports are generated from real audit data; download as CSV or print to PDF."}
            </p>
          </SeoCard>

          {reports.isLoading ? (
            <Loading label={t("s.loading")} />
          ) : !reports.data?.reports?.length ? (
            <EmptyState icon={FileText} text={t("s.rep_empty")} />
          ) : (
            <div className="grid gap-3">
              {reports.data.reports.map((r) => {
                let summary: ReportSummaryData | null = null;
                try {
                  summary = JSON.parse(r.summary) as ReportSummaryData;
                } catch {
                  summary = null;
                }
                const isOpen = expanded === r.id;
                const plain = summary?.plain[lang === "fa" ? "fa" : "en"] ?? "";
                return (
                  <article key={r.id} className="rounded-card border border-hairline bg-white p-4 sm:p-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Badge kind={r.period === "weekly" ? "info" : "opportunity"}>
                          {r.period === "weekly" ? t("s.rep_weekly") : t("s.rep_monthly")}
                        </Badge>
                        <span className="text-sm text-ink-soft">{fmtDate(r.createdAt, lang)}</span>
                        {summary?.scoreLatest != null ? <Badge kind="info">{t("s.score")}: {summary.scoreLatest}</Badge> : null}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Button variant="ghost" size="sm" onClick={() => setExpanded(isOpen ? null : r.id)} className="cursor-pointer rounded-pill">
                          {isOpen ? t("s.close") : t("s.rep_plain")}
                        </Button>
                        <a
                          href={`/api/seo/reports/${r.id}?format=csv`}
                          className="inline-flex items-center gap-1 rounded-pill border border-hairline px-3 py-1.5 text-xs font-medium text-ink transition-colors hover:bg-surface"
                        >
                          <Download className="size-3.5" aria-hidden />
                          CSV
                        </a>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => window.print()}
                          className="cursor-pointer rounded-pill text-ink-soft"
                          aria-label={t("s.rep_print")}
                        >
                          <Printer className="size-4" aria-hidden />
                        </Button>
                      </div>
                    </div>

                    <p className="mt-3 rounded-card bg-surface p-3 text-sm text-ink" dir="auto">
                      {plain}
                    </p>

                    {isOpen && summary ? (
                      <div className="mt-3 grid gap-3 text-sm">
                        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                          <div className="rounded-card bg-surface p-3 text-center">
                            <p className="text-xs text-ink-soft">{t("s.critical")}</p>
                            <p className="font-display text-lg font-bold text-red-700">{summary.counts.critical}</p>
                          </div>
                          <div className="rounded-card bg-surface p-3 text-center">
                            <p className="text-xs text-ink-soft">{t("s.warning")}</p>
                            <p className="font-display text-lg font-bold text-amber-700">{summary.counts.warning}</p>
                          </div>
                          <div className="rounded-card bg-surface p-3 text-center">
                            <p className="text-xs text-ink-soft">{t("s.st_applied")}</p>
                            <p className="font-display text-lg font-bold text-emerald-700">{summary.counts.applied}</p>
                          </div>
                          <div className="rounded-card bg-surface p-3 text-center">
                            <p className="text-xs text-ink-soft">{t("s.st_resolved")}</p>
                            <p className="font-display text-lg font-bold text-emerald-700">{summary.counts.resolved}</p>
                          </div>
                        </div>
                        {summary.plan.length > 0 ? (
                          <div>
                            <h4 className="mb-1.5 text-sm font-semibold text-brand-deep">{t("s.rep_plan")}</h4>
                            <ol className="grid list-inside list-decimal gap-1 text-ink">
                              {summary.plan.map((p) => (
                                <li key={p.code + p.pageUrl} dir="auto" className="text-sm">
                                  {p.title} <span className="text-xs text-ink-soft">({p.pageUrl})</span>
                                </li>
                              ))}
                            </ol>
                          </div>
                        ) : null}
                        {summary.recurring.length > 0 ? (
                          <div>
                            <h4 className="mb-1.5 text-sm font-semibold text-brand-deep">{t("s.rep_recurring")}</h4>
                            <ul className="flex flex-wrap gap-1.5">
                              {summary.recurring.map((x) => (
                                <li key={x.code}>
                                  <Badge kind="warning">
                                    {x.code} × {x.seen}
                                  </Badge>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ) : null}
                      </div>
                    ) : null}
                  </article>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
