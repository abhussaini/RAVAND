import { NextResponse } from "next/server";
import { db, dbConfigError, ensureDb } from "@/lib/db";
import { sbTable, supabaseEnabled } from "@/lib/supabase";

export const dynamic = "force-dynamic";

/**
 * GET /api/health — hosting readiness probe.
 *
 * One URL the owner can open after deploying to verify, with no
 * secrets exposed:
 *   • database   — Supabase Postgres (via DATABASE_URL) reachable + seeded
 *   • supabase   — REST mirror configured and reachable (row counts)
 *   • admin      — whether ADMIN_PASSWORD was customised
 *   • ai         — whether a portable AI provider (AI_API_KEY) is set
 *
 * Each check degrades gracefully: the endpoint never throws, so it
 * works even while parts of the stack are broken (that is the point).
 */
async function checkDb(): Promise<"ok" | "error" | "unconfigured"> {
  const configError = dbConfigError();
  if (configError) return "unconfigured";
  try {
    await ensureDb();
    await Promise.race([
      db.setting.count(),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("timeout")), 8_000)
      ),
    ]);
    return "ok";
  } catch (error) {
    console.error("[/api/health] database check failed:", String(error).slice(0, 160));
    return "error";
  }
}

async function checkSupabase(): Promise<"ok" | "disabled" | "unreachable"> {
  if (!supabaseEnabled) return "disabled";
  const count = await Promise.race([
    sbTable.count("Service"),
    new Promise<null>((_, reject) =>
      setTimeout(() => reject(new Error("timeout")), 8_000)
    ).catch(() => null),
  ]);
  return count === null ? "unreachable" : "ok";
}

export async function GET() {
  const [database, supabase] = await Promise.all([checkDb(), checkSupabase()]);

  const adminPasswordCustomised = Boolean(process.env.ADMIN_PASSWORD);
  const aiConfigured = Boolean(process.env.AI_API_KEY && process.env.AI_BASE_URL);

  /* healthy = the durable Postgres store works */
  const healthy = database === "ok";

  return NextResponse.json(
    {
      ok: healthy,
      checks: { database, supabase, adminPasswordCustomised, aiConfigured },
      hints:
        database === "unconfigured"
          ? [
              "DATABASE_URL is not set. Add the Supabase pooler connection string (postgresql://postgres.<ref>:<pw>@aws-0-<region>.pooler.supabase.com:6543/postgres?pgbouncer=true&connection_limit=1) to the environment variables and redeploy.",
            ]
          : database === "error"
            ? ["DATABASE_URL is set but the database is unreachable — check the connection string, the pooler region and the database password."]
            : supabase === "unreachable"
              ? ["SUPABASE_URL/API_KEY set but unreachable — check the keys and that supabase/schema.sql was run."]
              : [],
      time: new Date().toISOString(),
    },
    { status: healthy ? 200 : 503 }
  );
}
