"use client";

import { useEffect, useRef, useState } from "react";
import { BrandMark, BrandWordmark } from "./ui-v2";
import { useUi } from "@/store/use-ui";

/* Brand moment plays ONCE per browser session (sessionStorage) and is
   kept snappy — it is a pure-CSS curtain that starts immediately and
   never waits for the window `load` event, so it cannot delay the
   hero (which paints and animates underneath it without JS). */
const SEEN_KEY = "rv-intro-seen";
const MIN_VISIBLE_MS = 900;
const EXIT_MS = 480;

/**
 * Navy intro curtain: wordmark + filling progress bar, then the curtain
 * slides up. Pure CSS animation + sessionStorage gate.
 */
export function IntroLoader() {
  const setReady = useUi((s) => s.setReady);
  const [exiting, setExiting] = useState(false);
  const [gone, setGone] = useState(false);
  const started = useRef(false);

  useEffect(() => {
    /* repeat visit in the same session → skip the curtain entirely
       (deferred one tick so the skip isn't a cascading sync render) */
    let skipTimer = 0;
    try {
      if (sessionStorage.getItem(SEEN_KEY)) {
        skipTimer = window.setTimeout(() => {
          setReady(true);
          setGone(true);
        }, 0);
        return () => window.clearTimeout(skipTimer);
      }
    } catch {
      /* storage unavailable — show the curtain */
    }

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const MIN = reduced ? 200 : MIN_VISIBLE_MS;
    const EXIT = reduced ? 0 : EXIT_MS;

    try {
      sessionStorage.setItem(SEEN_KEY, "1");
    } catch {
      /* ignore */
    }
    const timer = window.setTimeout(() => {
      setReady(true);
      setExiting(true);
      window.setTimeout(() => setGone(true), Math.max(EXIT, 50));
    }, MIN);

    return () => window.clearTimeout(timer);
  }, [setReady]);

  if (gone) return null;

  return (
    <div
      aria-hidden
      className="fixed inset-0 z-[200] flex flex-col items-center justify-center gap-8 bg-brand-deep text-white"
      style={{
        transform: exiting ? "translate3d(0,-105%,0)" : "translate3d(0,0,0)",
        transition: `transform ${EXIT_MS}ms cubic-bezier(0.65, 0, 0.35, 1)`,
        willChange: "transform",
      }}
    >
      <div
        className="anim-fade-up flex items-center gap-3"
        style={{ animationDuration: "0.6s" }}
      >
        <BrandMark className="size-7" />
        <BrandWordmark className="text-2xl tracking-[0.2em]" />
      </div>

      <div
        className="w-40 overflow-hidden rounded-pill bg-white/20"
        style={{ height: 1 }}
        role="progressbar"
        aria-label="Loading"
      >
        <div className="anim-bar h-full w-full bg-white" />
      </div>
    </div>
  );
}
