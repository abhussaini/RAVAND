"use client";

import { useEffect, useState } from "react";

/**
 * Hash-based client router — gives the site real multi-page
 * navigation (services / portfolio / blog / about / contact / admin)
 * while staying inside the sandbox's single "/" route.
 *
 *   #/            → home (one-pager)
 *   #/services    → services page
 *   #/portfolio   → portfolio page
 *   #/blog        → blog index
 *   #/blog/:slug  → post detail
 *   #/about       → about page
 *   #/contact     → contact page
 *   #/admin       → admin panel (CRUD dashboard)
 */

export interface RouteInfo {
  /** e.g. "/blog/post-slug" */
  path: string;
  /** path split into segments, first is the page name ("" for home) */
  parts: string[];
}

function parseHash(): RouteInfo {
  if (typeof window === "undefined") return { path: "/", parts: [""] };
  const raw = window.location.hash.replace(/^#/, "") || "/";
  const path = raw.startsWith("/") ? raw : `/${raw}`;
  const parts = path.split("/").filter(Boolean);
  return { path, parts };
}

export function useRoute(): RouteInfo {
  const [route, setRoute] = useState<RouteInfo>(() => parseHash());

  useEffect(() => {
    const onChange = () => setRoute(parseHash());
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  return route;
}

export function navigate(to: string) {
  const target = to.startsWith("/") ? to : `/${to}`;
  if (typeof window === "undefined") return;
  if (window.location.hash === `#${target}`) {
    // re-navigating to the same page — just scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" });
    return;
  }
  window.location.hash = `#${target}`;
}

/** Navigate home and then smooth-scroll to a section id (#services …) */
export function navigateHomeSection(sectionId: string) {
  const go = () => {
    window.setTimeout(() => {
      const el = document.querySelector(sectionId);
      el?.scrollIntoView({ behavior: "smooth" });
    }, 120);
  };
  if (typeof window === "undefined") return;
  if (window.location.hash && window.location.hash !== "#/" && window.location.hash !== "#") {
    window.location.hash = "#/";
    go();
  } else {
    const el = document.querySelector(sectionId);
    el?.scrollIntoView({ behavior: "smooth" });
  }
}
