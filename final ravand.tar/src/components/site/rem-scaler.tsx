"use client";

import { useEffect } from "react";

/**
 * Above the 1920px design width the root font-size scales up so the
 * rem-based layout keeps growing proportionally (below 1920 the CSS
 * media queries drive).
 */
export function RemScaler() {
  useEffect(() => {
    const FONT_BASE = 16;
    const BASE_W = 1920;
    const COEF = 0.6666;
    const apply = () => {
      const reduction = ((BASE_W - window.innerWidth) / BASE_W) * 100 * COEF;
      const size = FONT_BASE - (FONT_BASE * reduction) / 100;
      if (size > FONT_BASE) {
        document.documentElement.style.fontSize = `${size}px`;
      } else {
        document.documentElement.style.removeProperty("font-size");
      }
    };
    apply();
    window.addEventListener("resize", apply);
    return () => window.removeEventListener("resize", apply);
  }, []);
  return null;
}
