/* ------------------------------------------------------------------
   Ravand SEO Assistant — deterministic suggestion engine.

   Every recommendation is produced by transparent, reviewable rules
   over the crawled page data. No external service is involved, so
   results are reproducible, auditable and safe by construction.
   ------------------------------------------------------------------ */

/** Strip tags/control chars and cap length — applied to every string. */
export function cleanText(v: unknown, max: number): string {
  if (typeof v !== "string") return "";
  return v
    .replace(/<[^>]*>/g, " ")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}

/* ---------- content optimizer ---------- */

export interface OptimizerResult {
  titles: string[];
  descriptions: string[];
  headings: string[];
  sections: string[];
  internalLinks: string[];
  notes: string;
  source: "rules";
}

export interface OptimizerInput {
  url: string;
  keyword: string;
  lang: "fa" | "en";
  title: string;
  description: string;
  text: string;
  internalPages: { path: string; label: string }[];
}

const clamp = (arr: string[], n: number, max: number) =>
  arr.map((t) => cleanText(t, max)).filter(Boolean).slice(0, n);

export async function optimizeContent(input: OptimizerInput): Promise<OptimizerResult> {
  const kw = cleanText(input.keyword, 80);
  const baseTitle = cleanText(input.title, 60) || "Ravand Tech";
  const firstSentence = cleanText(input.text, 150);

  const titles = kw
    ? [`${kw} | Ravand Tech`, `${kw} در افغانستان — راوند تک`, `Professional ${kw} — Ravand Tech`]
    : [`${baseTitle} | Ravand Tech`];

  const descriptions = [
    firstSentence
      ? `${firstSentence.slice(0, 140)}`
      : kw
        ? `${kw} — modern, fast and secure solutions by Ravand Tech. Free consultation available.`
        : "Modern websites & IT solutions by Ravand Tech — from idea to market.",
  ];

  return {
    titles: clamp(titles, 3, 80),
    descriptions: clamp(descriptions, 2, 160),
    headings: kw
      ? [
          `Why choose Ravand Tech for ${kw}`,
          `Our ${kw} process`,
          `Pricing & timelines`,
          `Frequently asked questions`,
        ]
      : [],
    sections: ["Case studies", "FAQ", "Pricing guidance", "Client testimonials"],
    internalLinks: input.internalPages.slice(0, 3).map((p) => `${p.label} (#${p.path})`),
    notes:
      input.lang === "fa"
        ? "پیشنهادهای مبتنی بر قواعد فنی — عنوان‌ها، توضیحات و بخش‌های پیشنهادی بر اساس ساختار صفحه و کلمه هدف ساخته شده‌اند."
        : "Rule-based suggestions — titles, descriptions and section ideas are derived from the page structure and the target keyword.",
    source: "rules",
  };
}

/* ---------- keyword suggestions ---------- */

const EN_TAILS = [
  "in Afghanistan",
  "services",
  "company",
  "cost",
  "agency",
  "portfolio",
  "best",
  "checklist",
];

const FA_TAILS = [
  "در افغانستان",
  "خدمات",
  "شرکت",
  "قیمت",
  "بهترین",
  "راهنما",
  "چک‌لیست",
  "مشاوره",
];

export async function suggestKeywords(seed: string, lang: "fa" | "en"): Promise<string[]> {
  const s = cleanText(seed, 40);
  if (!s) return [];
  const tails = lang === "fa" ? FA_TAILS : EN_TAILS;
  const out = tails
    .map((tail) => cleanText(`${s} ${tail}`.trim(), 40))
    .filter((k) => k.length > 0 && k.toLowerCase() !== s.toLowerCase());
  return Array.from(new Set(out)).slice(0, 8);
}
