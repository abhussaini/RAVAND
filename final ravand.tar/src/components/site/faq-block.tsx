"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useT } from "@/lib/i18n";
import { Reveal } from "./reveal";
import { Eyebrow } from "./ui-v2";

const FAQS = [
  { q: "faq1_q", a: "faq1_a" },
  { q: "faq2_q", a: "faq2_a" },
  { q: "faq3_q", a: "faq3_a" },
  { q: "faq4_q", a: "faq4_a" },
  { q: "faq5_q", a: "faq5_a" },
] as const;

/** FAQ accordion — trilingual, uses shadcn Accordion. */
export function FaqBlock() {
  const { t } = useT();

  return (
    <section className="bg-surface px-6 py-20 sm:px-10 sm:py-24">
      <div className="mx-auto max-w-3xl">
        <div className="text-center">
          <Eyebrow className="justify-center">{t("faq.eyebrow")}</Eyebrow>
          <h2 className="font-display t-section mt-4 font-medium">{t("faq.title")}</h2>
          <Reveal from={{ opacity: 0, y: 14 }} delayIn={0.15}>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">{t("faq.desc")}</p>
          </Reveal>
        </div>

        <Reveal from={{ opacity: 0, y: 24 }} delayIn={0.1}>
          <Accordion type="single" collapsible className="mt-10 rounded-card border border-hairline bg-white px-6">
            {FAQS.map((f, i) => (
              <AccordionItem key={f.q} value={`faq-${i}`} className="last:border-b-0">
                <AccordionTrigger className="cursor-pointer py-5 text-start font-display text-base font-medium sm:text-lg">
                  {t(f.q)}
                </AccordionTrigger>
                <AccordionContent className="text-sm leading-relaxed text-ink-soft sm:text-[0.95rem]">
                  {t(f.a)}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  );
}
