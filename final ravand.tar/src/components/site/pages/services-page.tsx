"use client";

import { useT } from "@/lib/i18n";
import { useUi } from "@/store/use-ui";
import { ServicesSection } from "../services-section";
import { ProcessStrip } from "../process-strip";
import { FaqBlock } from "../faq-block";
import { PageHero } from "../page-hero";
import { SiteFooter } from "../site-footer";
import { Reveal } from "../reveal";
import { PillButton } from "../ui-v2";

/** Services page — hero band, full grid, process timeline, FAQ, CTA. */
export function ServicesPage() {
  const { t } = useT();
  const openContact = useUi((s) => s.openContact);

  return (
    <>
      <main className="flex-1">
        <PageHero
          title={t("services.title")}
          desc={t("services.desc")}
          sticker="/stickers/st-services.svg"
          backTo="/"
          backLabel={t("nav.home")}
        />
        <ServicesSection showHeader={false} />
        <ProcessStrip />
        <FaqBlock />

        {/* CTA band */}
        <section className="bg-white px-6 pb-20 sm:px-10 sm:pb-24">
          <Reveal from={{ opacity: 0, y: 24 }}>
            <div className="flex flex-col items-start justify-between gap-6 rounded-card-lg bg-brand-deep px-8 py-12 text-white sm:flex-row sm:items-center sm:px-12">
              <div>
                <h2 className="font-display t-section font-medium">{t("portfolio.cta_title")}</h2>
                <p className="mt-3 max-w-lg text-sm leading-relaxed text-white/70">{t("portfolio.cta_desc")}</p>
              </div>
              <PillButton variant="light" onClick={() => openContact()}>
                {t("portfolio.cta_button")}
              </PillButton>
            </div>
          </Reveal>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
