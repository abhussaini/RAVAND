import { db, ensureDb } from "@/lib/db";
import { getBaseUrl, approvedHosts, safeUrl } from "./config";
import { cleanText } from "./assistant";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — Google PageSpeed Insights proxy.

   • Runs server-side only; the API key (if any) never reaches the
     browser.
   • SSRF-guarded: only the approved site URL can be measured.
   • Results cached ~6h in SeoSetting.psiData to respect free quotas.
   • Scores are ONLY ever shown from the real API response — when the
     API fails, the caller gets an honest error.
   ------------------------------------------------------------------ */

const CACHE_MS = 6 * 3600_000;

interface PsiCache {
  url: string;
  strategy: string;
  fetchedAt: number;
  ok: boolean;
  error?: string;
  performance?: number; // 0-100
  metrics?: Record<string, { value: number; display: string }>;
  fieldData?: Record<string, { percentile: number; display: string }>;
  opportunities?: { id: string; title: string; display: string }[];
}

export async function fetchPageSpeed(
  strategy: "mobile" | "desktop"
): Promise<PsiCache> {
  await ensureDb();
  const base = await getBaseUrl();
  const allowed = approvedHosts(base);
  const target = safeUrl(base, base, allowed);
  if (!target) return { url: base, strategy, fetchedAt: Date.now(), ok: false, error: "BLOCKED_URL" };

  /* cache read */
  const setting = await db.seoSetting.findUnique({ where: { id: "main" } });
  if (setting?.psiData) {
    try {
      const cache = JSON.parse(setting.psiData) as Record<string, PsiCache>;
      const hit = cache[strategy];
      if (hit && Date.now() - hit.fetchedAt < CACHE_MS && hit.url === base) return hit;
    } catch {
      /* corrupt cache — refetch */
    }
  }

  const key = process.env.PAGESPEED_API_KEY;
  const endpoint = new URL("https://www.googleapis.com/pagespeedonline/v5/runPagespeed");
  endpoint.searchParams.set("url", target.toString());
  endpoint.searchParams.set("strategy", strategy);
  endpoint.searchParams.set("category", "performance");
  if (key) endpoint.searchParams.set("key", key);

  let result: PsiCache;
  try {
    const res = await fetch(endpoint.toString(), { signal: AbortSignal.timeout(55_000) });
    if (!res.ok) {
      const msg =
        res.status === 429
          ? "QUOTA_EXCEEDED"
          : res.status === 400
            ? "BAD_REQUEST"
            : `API_ERROR_${res.status}`;
      result = { url: base, strategy, fetchedAt: Date.now(), ok: false, error: msg };
    } else {
      const json = (await res.json()) as {
        lighthouseResult?: {
          categories?: { performance?: { score?: number } };
          audits?: Record<string, { displayValue?: string; numericValue?: number; title?: string; details?: { type?: string } }>;
        };
        loadingExperience?: {
          metrics?: Record<string, { percentile?: number; displayValue?: string }>;
        };
      };
      const lr = json.lighthouseResult;
      const perf = lr?.categories?.performance?.score;
      const metrics: Record<string, { value: number; display: string }> = {};
      const wanted = ["largest-contentful-paint", "cumulative-layout-shift", "total-blocking-time", "first-contentful-paint", "speed-index", "interactive"];
      for (const id of wanted) {
        const a = lr?.audits?.[id];
        if (a && (a.numericValue !== undefined || a.displayValue)) {
          metrics[id] = {
            value: Math.round(a.numericValue ?? 0),
            display: cleanText(a.displayValue ?? String(a.numericValue ?? ""), 40),
          };
        }
      }
      const fieldData: Record<string, { percentile: number; display: string }> = {};
      for (const [k, v] of Object.entries(json.loadingExperience?.metrics ?? {})) {
        if (v.percentile !== undefined && v.displayValue) {
          fieldData[k] = { percentile: v.percentile, display: cleanText(v.displayValue, 40) };
        }
      }
      const opportunities: { id: string; title: string; display: string }[] = [];
      for (const [id, a] of Object.entries(lr?.audits ?? {})) {
        const det = a.details;
        if (det && (det as { type?: string }).type === "opportunity" && a.numericValue && a.numericValue > 50) {
          opportunities.push({ id, title: cleanText(a.title ?? id, 90), display: cleanText(a.displayValue ?? "", 40) });
        }
        if (opportunities.length >= 6) break;
      }
      result = {
        url: base,
        strategy,
        fetchedAt: Date.now(),
        ok: perf !== undefined && perf !== null,
        performance: perf !== undefined && perf !== null ? Math.round(perf * 100) : undefined,
        metrics,
        fieldData,
        opportunities,
      };
    }
  } catch (e) {
    result = {
      url: base,
      strategy,
      fetchedAt: Date.now(),
      ok: false,
      error: e instanceof Error && e.name === "TimeoutError" ? "TIMEOUT" : "NETWORK_ERROR",
    };
  }

  /* cache write */
  let cache: Record<string, PsiCache> = {};
  if (setting?.psiData) {
    try {
      cache = JSON.parse(setting.psiData) as Record<string, PsiCache>;
    } catch {
      cache = {};
    }
  }
  cache[strategy] = result;
  await db.seoSetting.upsert({
    where: { id: "main" },
    update: { psiData: JSON.stringify(cache) },
    create: { psiData: JSON.stringify(cache) },
  });

  return result;
}
