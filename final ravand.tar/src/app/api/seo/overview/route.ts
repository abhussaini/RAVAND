import { NextResponse } from "next/server";
import { db, ensureDb } from "@/lib/db";
import { deny, guard } from "@/lib/seo/guard";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { taskStatuses } from "@/lib/seo/tasks";

export const dynamic = "force-dynamic";

/* GET /api/seo/overview — dashboard summary (admin only). */
export async function GET(req: Request) {
  if (!(await guard(req))) return deny();
  const rl = rateLimit(`seo-overview:${clientIp(req)}`, 60, 60_000);
  if (!rl.ok) return NextResponse.json({ ok: false, error: "RATE_LIMITED" }, { status: 429 });

  try {
    await ensureDb();
    const [latestAudit, auditsCount, issues, tasks, setting, changes] = await Promise.all([
      db.seoAudit.findFirst({ orderBy: { startedAt: "desc" } }),
      db.seoAudit.count(),
      db.seoIssue.findMany({ orderBy: { createdAt: "desc" } }),
      taskStatuses(),
      db.seoSetting.findUnique({ where: { id: "main" } }),
      db.seoChange.findMany({ orderBy: { createdAt: "desc" }, take: 6 }),
    ]);

    const openIssues = issues.filter((i) => i.status === "open" || i.status === "approved");
    const nextDues = tasks.filter((t) => t.nextDue).map((t) => t.nextDue as string);

    return NextResponse.json({
      ok: true,
      latestAudit: latestAudit && {
        id: latestAudit.id,
        status: latestAudit.status,
        score: latestAudit.score,
        pages: latestAudit.pages,
        critical: latestAudit.critical,
        warning: latestAudit.warning,
        opportunity: latestAudit.opportunity,
        trigger: latestAudit.trigger,
        startedAt: latestAudit.startedAt,
        finishedAt: latestAudit.finishedAt,
        error: latestAudit.error,
      },
      auditsCount,
      issues: {
        open: openIssues.length,
        critical: openIssues.filter((i) => i.severity === "critical").length,
        warning: openIssues.filter((i) => i.severity === "warning").length,
        opportunity: openIssues.filter((i) => i.severity === "opportunity").length,
        applied: issues.filter((i) => i.status === "applied").length,
        resolved: issues.filter((i) => i.status === "resolved").length,
        ignored: issues.filter((i) => i.status === "ignored").length,
      },
      keywords: await db.seoKeyword.count(),
      tasks,
      nextScheduled: nextDues.length ? nextDues.sort()[0] : null,
      recentChanges: changes,
      settings: {
        baseUrl: setting?.baseUrl ?? "",
        psiKey: Boolean(process.env.PAGESPEED_API_KEY),
        cronSecret: Boolean(process.env.CRON_SECRET),
        adminDefaultPassword: !process.env.ADMIN_PASSWORD,
      },
    });
  } catch (error) {
    console.error("[seo/overview] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
