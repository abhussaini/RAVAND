/* ------------------------------------------------------------------
   Ravand SEO Assistant — issue registry.

   Every audit finding maps to a stable code with severity, risk
   classification (per the safe auto-fix policy) and bilingual
   plain-language texts (fa = Dari/Persian, en = English; ps falls
   back to fa). {placeholders} are interpolated at audit time.
   ------------------------------------------------------------------ */

export type Sev = "critical" | "warning" | "opportunity";
export type Risk = "low" | "medium" | "high";
export type TextLang = "fa" | "en";

export interface IssueText {
  title: string;
  why: string;
  fix: string;
}

interface IssueDef {
  severity: Sev;
  risk: Risk;
  /** true when the fix can be applied through the safe auto-fix system */
  auto: boolean;
  fa: IssueText;
  en: IssueText;
}

export const REGISTRY: Record<string, IssueDef> = {
  SITE_UNREACHABLE: {
    severity: "critical",
    risk: "high",
    auto: false,
    fa: {
      title: "وب‌سایت در دسترس نیست",
      why: "خزنده سئو نتوانست صفحه اصلی را باز کند؛ اگر گوگل هم چنین وضعیتی را ببیند، سایت از نتایج جست‌وجو حذف می‌شود.",
      fix: "وضعیت سرور/هاست و اتصال دامنه را بررسی کنید و دوباره ارزیابی بگیرید.",
    },
    en: {
      title: "Website is unreachable",
      why: "The crawler could not open the homepage. If Google sees the same, the site can drop out of search results.",
      fix: "Check the hosting/server status and domain connectivity, then run the audit again.",
    },
  },
  HTTP_NOT_HTTPS: {
    severity: "critical",
    risk: "high",
    auto: false,
    fa: {
      title: "آدرس سایت با HTTPS نیست",
      why: "بدون HTTPS مرورگرها سایت را «ناامن» نشان می‌دهند و گوگل رتبه پایین‌تری می‌دهد.",
      fix: "گواهی SSL را از پنل هاست/Netlify فعال کنید و ترافیک HTTP را به HTTPS منتقل کنید.",
    },
    en: {
      title: "Site URL is not HTTPS",
      why: "Without HTTPS browsers flag the site as insecure and Google ranks it lower.",
      fix: "Enable an SSL certificate in your hosting/Netlify panel and redirect HTTP traffic to HTTPS.",
    },
  },
  MISSING_TITLE: {
    severity: "critical",
    risk: "medium",
    auto: true,
    fa: {
      title: "عنوان صفحه (Title) وجود ندارد",
      why: "عنوان مهم‌ترین سیگنال سئو است؛ بدون آن گوگل نمی‌داند صفحه درباره چیست.",
      fix: "عنوان پیشنهادی به‌صورت خودکار قابل ثبت است — با تأیید شما اعمال می‌شود.",
    },
    en: {
      title: "Page title is missing",
      why: "The title is the strongest SEO signal; without it Google cannot tell what the page is about.",
      fix: "A suggested title can be applied automatically after your approval.",
    },
  },
  SHORT_TITLE: {
    severity: "warning",
    risk: "medium",
    auto: true,
    fa: {
      title: "عنوان صفحه خیلی کوتاه است ({value} نویسه)",
      why: "عنوان زیر ۲۵ نویسه معمولاً کلمات کلیدی مهم را از دست می‌دهد.",
      fix: "عنوان بلندتر و توصیفی‌تر پیشنهاد می‌شود؛ با تأیید شما اعمال می‌شود.",
    },
    en: {
      title: "Page title is too short ({value} chars)",
      why: "Titles under 25 characters usually miss important keywords.",
      fix: "A longer, more descriptive title is suggested — applied after your approval.",
    },
  },
  LONG_TITLE: {
    severity: "warning",
    risk: "medium",
    auto: true,
    fa: {
      title: "عنوان صفحه خیلی بلند است ({value} نویسه)",
      why: "بخش انتهای عنوان‌های بلندتر از ~۶۰ نویسه در نتایج گوگل بریده می‌شود.",
      fix: "عنوان فشرده‌تر پیشنهاد می‌شود؛ با تأیید شما اعمال می‌شود.",
    },
    en: {
      title: "Page title is too long ({value} chars)",
      why: "Titles beyond ~60 characters get truncated in Google results.",
      fix: "A tighter title is suggested — applied after your approval.",
    },
  },
  MISSING_DESCRIPTION: {
    severity: "critical",
    risk: "low",
    auto: true,
    fa: {
      title: "توضیحات متا (Meta description) وجود ندارد",
      why: "توضیحات متا همان متن زیر عنوان سایت در گوگل است و روی نرخ کلیک تأثیر مستقیم دارد.",
      fix: "توضیحات پیشنهادی از محتوای واقعی صفحه ساخته شده و می‌تواند خودکار ثبت شود.",
    },
    en: {
      title: "Meta description is missing",
      why: "The meta description is the snippet shown under your result in Google and directly affects click rate.",
      fix: "A suggested description was generated from the real page content and can be applied automatically.",
    },
  },
  SHORT_DESCRIPTION: {
    severity: "warning",
    risk: "medium",
    auto: true,
    fa: {
      title: "توضیحات متا کوتاه است ({value} نویسه)",
      why: "توضیحات زیر ۵۰ نویسه فضای نتیجه گوگل را هدر می‌دهد.",
      fix: "توضیحات کامل‌تر پیشنهاد می‌شود؛ با تأیید شما اعمال می‌شود.",
    },
    en: {
      title: "Meta description is too short ({value} chars)",
      why: "Descriptions under 50 characters waste Google result space.",
      fix: "A fuller description is suggested — applied after your approval.",
    },
  },
  LONG_DESCRIPTION: {
    severity: "warning",
    risk: "medium",
    auto: true,
    fa: {
      title: "توضیحات متا بلند است ({value} نویسه)",
      why: "توضیحات بلندتر از ~۱۶۰ نویسه در گوگل بریده می‌شود.",
      fix: "توضیحات فشرده‌تر پیشنهاد می‌شود؛ با تأیید شما اعمال می‌شود.",
    },
    en: {
      title: "Meta description is too long ({value} chars)",
      why: "Descriptions beyond ~160 characters are truncated by Google.",
      fix: "A tighter description is suggested — applied after your approval.",
    },
  },
  H1_COUNT: {
    severity: "warning",
    risk: "high",
    auto: false,
    fa: {
      title: "تعداد H1 صفحه {count} است (باید دقیقاً ۱ باشد)",
      why: "H1 موضوع اصلی صفحه را مشخص می‌کند؛ چند H1 یا نبود آن، ساختار صفحه را برای موتور جست‌وجو مبهم می‌کند.",
      fix: "در کد صفحه (کامپوننت Hero) فقط یک H1 نگه دارید. این تغییر نیازمند ویرایش کد است و خودکار انجام نمی‌شود.",
    },
    en: {
      title: "Page has {count} H1 tags (exactly 1 expected)",
      why: "The H1 defines the main topic; multiple or zero H1s confuse search engines about the page structure.",
      fix: "Keep exactly one H1 in the page code (hero component). This needs a code edit and is never automated.",
    },
  },
  ROBOTS_NOINDEX: {
    severity: "critical",
    risk: "high",
    auto: false,
    fa: {
      title: "صفحه با meta robots «noindex» مسدود شده",
      why: "این تگ به گوگل می‌گوید صفحه را ایندکس نکند؛ سایت عملاً از جست‌وجو حذف می‌شود.",
      fix: "تگ noindex را از کد حذف کنید. تغییر قواعد ایندکس هرگز خودکار انجام نمی‌شود.",
    },
    en: {
      title: "Page is blocked with meta robots noindex",
      why: "This tag tells Google not to index the page — the site effectively disappears from search.",
      fix: "Remove the noindex tag from the code. Indexing rules are never changed automatically.",
    },
  },
  CANONICAL_PENDING: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "URL اصلی (Canonical) هنوز تنظیم نشده",
      why: "تا زمانی که دامنه نهایی تولیدی مشخص نشود، آدرس canonical موقتی ثبت نمی‌کنیم تا URL پیش‌نمایش به‌اشتباه canonical نشود.",
      fix: "در تب «تنظیمات» آدرس دامنه نهایی را ثبت کنید؛ سپس canonical در کد سایت تنظیم می‌شود.",
    },
    en: {
      title: "Canonical URL is pending configuration",
      why: "Until the final production domain is confirmed we deliberately do not set a temporary canonical, so a preview URL never becomes the permanent one.",
      fix: "Enter the final production domain in the Settings tab; the canonical will then be configured in the site code.",
    },
  },
  VIEWPORT_MISSING: {
    severity: "warning",
    risk: "high",
    auto: false,
    fa: {
      title: "تگ viewport برای موبایل وجود ندارد",
      why: "بدون viewport سایت در موبایل درست مقیاس نمی‌شود و رتبه موبایل را از دست می‌دهد.",
      fix: "تگ <meta name=viewport> در layout سایت اضافه شود (نیازمند ویرایش کد).",
    },
    en: {
      title: "Mobile viewport meta tag is missing",
      why: "Without a viewport tag the page does not scale on mobile and loses mobile ranking.",
      fix: "Add a <meta name=viewport> tag in the site layout (code edit required).",
    },
  },
  LANG_MISSING: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "ویژگی زبان (lang) روی تگ html نیست",
      why: "موتورها و صفحه‌خوان‌ها از lang برای تشخیص زبان صفحه استفاده می‌کنند (مهم برای دری/پشتو/انگلیسی).",
      fix: "ویژگی lang در layout سایت تنظیم شود (نیازمند ویرایش کد).",
    },
    en: {
      title: "Missing lang attribute on <html>",
      why: "Search engines and screen readers use lang to detect the page language (critical for Dari/Pashto/English).",
      fix: "Set the lang attribute in the site layout (code edit required).",
    },
  },
  IMAGES_MISSING_ALT: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "{count} تصویر بدون متن جایگزین (alt)",
      why: "alt هم برای دسترس‌پذیری لازم است هم برای اینکه گوگل موضوع تصویر را بفهمد (سئو تصاویر).",
      fix: "برای هر تصویر متن alt کوتاه و توصیفی بنویسید. alt خودکار فقط وقتی اضافه می‌شود که توصیف مطمئن موجود باشد.",
    },
    en: {
      title: "{count} images without alt text",
      why: "alt text is required for accessibility and helps Google understand images (image SEO).",
      fix: "Write short descriptive alt text per image. Alt is only auto-added when a reliable description exists.",
    },
  },
  OG_MISSING: {
    severity: "opportunity",
    risk: "low",
    auto: true,
    fa: {
      title: "تگ‌های Open Graph (اشتراک در شبکه‌های اجتماعی) ناقص است",
      why: "بدون OG، هنگام اشتراک لینک در واتساپ/فیسبوک پیش‌نمایش درستی نمایش داده نمی‌شود.",
      fix: "عنوان و توضیحات OG می‌تواند از مقادیر موجود خودکار ساخته شود.",
    },
    en: {
      title: "Open Graph (social share) tags are incomplete",
      why: "Without OG tags, sharing the link on WhatsApp/Facebook shows no proper preview.",
      fix: "OG title/description can be generated from existing metadata automatically.",
    },
  },
  TWITTER_MISSING: {
    severity: "opportunity",
    risk: "medium",
    auto: false,
    fa: {
      title: "تگ‌های Twitter Card وجود ندارند",
      why: "بدون Twitter Card پیش‌نمایش لینک در X/توییتر ساخته نمی‌شود.",
      fix: "تگ‌های twitter:card در metadata سایت اضافه شود (نیازمند ویرایش کد).",
    },
    en: {
      title: "Twitter Card tags are missing",
      why: "Without Twitter Cards, link previews on X/Twitter are not generated.",
      fix: "Add twitter:card tags to the site metadata (code edit required).",
    },
  },
  JSONLD_INVALID: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "داده ساختاریافته (JSON-LD) نامعتبر است",
      why: "JSON-LD خراب برای گوگل قابل خواندن نیست و رِیچ‌ریچ‌نتایج از دست می‌رود.",
      fix: "خطای JSON در بلوک اسکریپت ld+json برطرف شود (نیازمند ویرایش کد).",
    },
    en: {
      title: "Structured data (JSON-LD) is invalid",
      why: "Broken JSON-LD cannot be read by Google and rich results are lost.",
      fix: "Fix the JSON error in the ld+json script block (code edit required).",
    },
  },
  JSONLD_MISSING: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "داده ساختاریافته (JSON-LD) وجود ندارد",
      why: "Schema.org به گوگل کمک می‌کند نوع کسب‌وکار، خدمات و تماس را دقیق بفهمد.",
      fix: "بلوک JSON-LD سازمان در layout سایت اضافه شود (نیازمند ویرایش کد).",
    },
    en: {
      title: "Structured data (JSON-LD) is missing",
      why: "Schema.org helps Google understand your business type, services and contact details.",
      fix: "Add an Organization JSON-LD block to the site layout (code edit required).",
    },
  },
  THIN_CONTENT: {
    severity: "opportunity",
    risk: "high",
    auto: false,
    fa: {
      title: "محتوای صفحه کم است ({count} کلمه)",
      why: "صفحات با محتوای کم معمولاً رتبه خوبی نمی‌گیرند؛ گوگل به صفحات ارزشمند و کامل امتیاز می‌دهد.",
      fix: "بخش‌های مفید (توضیح خدمات، سوالات متداول، نمونه‌کار) اضافه کنید. انتشار انبوه محتوای هوش مصنوعی هرگز خودکار انجام نمی‌شود.",
    },
    en: {
      title: "Thin page content ({count} words)",
      why: "Pages with very little content rarely rank well; Google rewards complete, valuable pages.",
      fix: "Add useful sections (service details, FAQ, case studies). Bulk AI content publishing is never automated.",
    },
  },
  ROBOTS_MISSING: {
    severity: "warning",
    risk: "high",
    auto: false,
    fa: {
      title: "فایل robots.txt یافت نشد",
      why: "robots.txt به خزنده‌ها می‌گوید چه بخش‌هایی را بررسی کنند؛ نبود آن خزیدن را بهینه نمی‌کند.",
      fix: "فایل public/robots.txt در پروژه اضافه شود و پس از دیپلوی بررسی شود.",
    },
    en: {
      title: "robots.txt was not found",
      why: "robots.txt tells crawlers which areas to scan; without it crawling is not optimized.",
      fix: "Add a public/robots.txt file to the project and verify after deployment.",
    },
  },
  ROBOTS_NO_SITEMAP: {
    severity: "opportunity",
    risk: "low",
    auto: false,
    fa: {
      title: "آدرس sitemap در robots.txt نیست",
      why: "خط «Sitemap:» در robots.txt کشف نقشه سایت را برای همه موتورها ساده‌تر می‌کند.",
      fix: "خط Sitemap: https://…/sitemap.xml را به robots.txt اضافه کنید (نیازمند ویرایش فایل).",
    },
    en: {
      title: "Sitemap line missing in robots.txt",
      why: "A 'Sitemap:' line in robots.txt makes sitemap discovery easier for all engines.",
      fix: "Add 'Sitemap: https://…/sitemap.xml' to robots.txt (file edit required).",
    },
  },
  SITEMAP_MISSING: {
    severity: "critical",
    risk: "high",
    auto: false,
    fa: {
      title: "نقشه سایت (sitemap.xml) در دسترس نیست",
      why: "بدون نقشه سایت، کشف صفحات جدید توسط گوگل کند می‌شود.",
      fix: "خروجی /sitemap.xml سایت بررسی شود؛ در صورت نبود، فایل sitemap در پروژه اضافه شود.",
    },
    en: {
      title: "XML sitemap (sitemap.xml) is not reachable",
      why: "Without a sitemap, discovery of new pages by Google becomes slow.",
      fix: "Check the /sitemap.xml output; if missing, add a sitemap file to the project.",
    },
  },
  SITEMAP_HOST_MISMATCH: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "URLهای sitemap با دامنه اصلی تفاوت دارند",
      why: "URLهای sitemap باید دقیقاً با دامنه نهایی سایت یکی باشند وگرنه گوگل آن‌ها را نادیده می‌گیرد.",
      fix: "دامنه تولیدی را در تنظیمات ثبت کنید و پایه sitemap را با همان دامنه هم‌تراز کنید.",
    },
    en: {
      title: "Sitemap URLs do not match the production domain",
      why: "Sitemap URLs must exactly match the final domain, otherwise Google ignores them.",
      fix: "Register the production domain in Settings and align the sitemap base with it.",
    },
  },
  SPA_HASH_ROUTES: {
    severity: "opportunity",
    risk: "high",
    auto: false,
    fa: {
      title: "بخش‌های سایت با مسیر # (هاش) بارگذاری می‌شوند",
      why: "صفحات #/services، #/blog و… فقط با جاوااسکریپت رندر می‌شوند؛ گوگل بعد از ایندکس‌سازی ممکن است آن‌ها را جداگانه ایندکس نکند. محتوای اصلی حداقل باید در صفحه اصلی قابل مشاهده باشد.",
      fix: "محتوای مهم (خدمات، تماس) در HTML صفحه اصلی موجود است — نگه داشته شود. برای ایندکس جداگانه صفحات، در آینده تبدیل به مسیرهای واقعی (/services) توصیه می‌شود؛ این تصمیم نیازمند بازسازی مسیریابی است.",
    },
    en: {
      title: "Site sections load via # (hash) routes",
      why: "Pages like #/services and #/blog render only via JavaScript; Google may not index them as separate pages. Key content should at least be visible in the homepage HTML.",
      fix: "Important content (services, contact) exists in the homepage HTML — keep it. For separate indexing, migrating to real paths (/services) is recommended later; that is a routing-architecture decision.",
    },
  },
  DUPLICATE_TITLE: {
    severity: "warning",
    risk: "medium",
    auto: true,
    fa: {
      title: "عنوان تکراری: «{value}»",
      why: "صفحات/مقالات با عنوان یکسان با هم رقابت می‌کنند (خوراک‌خواری کلمات کلیدی) و رتبه هر دو کم می‌شود.",
      fix: "عنوان متمایز پیشنهاد می‌شود؛ برای مقالات با تأیید شما در پنل اعمال می‌شود.",
    },
    en: {
      title: "Duplicate title: “{value}”",
      why: "Pages/posts with identical titles compete with each other (keyword cannibalization) and both rank lower.",
      fix: "A differentiated title is suggested; for posts it can be applied in the panel after your approval.",
    },
  },
  POST_TITLE_SHORT: {
    severity: "warning",
    risk: "medium",
    auto: true,
    fa: {
      title: "عنوان مقاله کوتاه است ({value})",
      why: "عنوان مقاله باید شامل کلمه کلیدی هدف باشد و حداقل ~۲۰ نویسه طول داشته باشد.",
      fix: "عنوان پیشنهادی با هوش مصنوعی/قواعد ساخته می‌شود؛ با تأیید شما اعمال می‌شود.",
    },
    en: {
      title: "Post title is short ({value})",
      why: "A post title should contain the target keyword and be at least ~20 characters.",
      fix: "A suggested title is generated (rules/AI) and applied after your approval.",
    },
  },
  POST_EXCERPT_MISSING: {
    severity: "opportunity",
    risk: "medium",
    auto: true,
    fa: {
      title: "خلاصه مقاله «{value}» خالی است",
      why: "خلاصه در فهرست بلاگ و اشتراک‌گذاری‌ها نمایش داده می‌شود و نرخ کلیک را بالا می‌برد.",
      fix: "خلاصه پیشنهادی می‌تواند با تأیید شما ذخیره شود.",
    },
    en: {
      title: "Post excerpt is empty: “{value}”",
      why: "The excerpt appears in blog listings and shares, improving click-through.",
      fix: "A suggested excerpt can be saved after your approval.",
    },
  },
  POST_BODY_THIN: {
    severity: "opportunity",
    risk: "high",
    auto: false,
    fa: {
      title: "متن مقاله «{value}» کوتاه است",
      why: "مقالات بسیار کوتاه (زیر ~۴۰۰ نویسه) شانس رتبه‌گیری ندارند.",
      fix: "مقاله با بخش‌های تکمیلی (مقدمه، نکات، نتیجه) کامل شود؛ نوشتن/انتشار محتوا هرگز خودکار انجام نمی‌شود.",
    },
    en: {
      title: "Post body is thin: “{value}”",
      why: "Very short posts (under ~400 chars) have little chance to rank.",
      fix: "Complete the article with extra sections (intro, tips, conclusion). Content writing/publishing is never automated.",
    },
  },
  L10N_MISSING: {
    severity: "opportunity",
    risk: "medium",
    auto: true,
    fa: {
      title: "ترجمه «{field}» در «{value}» برای زبان {lang} خالی است",
      why: "بازدیدکنندگان دری/پشتو/انگلیسی باید همان محتوا را به زبان خود ببینند؛ ترجمه خالی اعتماد و سئوی چندزبانه را کم می‌کند.",
      fix: "ترجمه پیشنهادی می‌تواند با تأیید شما در پنل ذخیره شود.",
    },
    en: {
      title: "Missing {lang} translation of “{field}” in “{value}”",
      why: "Dari/Pashto/English visitors should see the same content in their language; empty translations hurt trust and multilingual SEO.",
      fix: "A suggested translation can be saved in the panel after your approval.",
    },
  },
  EXTERNAL_LINK_BROKEN: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "لینک خارجی خراب: {value}",
      why: "لینک‌های خراب تجربه کاربر و اعتماد را کم می‌کنند و سیگنال منفی برای سئو هستند.",
      fix: "لینک را اصلاح یا حذف کنید (در کد کامپوننت مربوط).",
    },
    en: {
      title: "Broken external link: {value}",
      why: "Dead links hurt user experience and trust, and send negative SEO signals.",
      fix: "Fix or remove the link in the related component code.",
    },
  },
  INTERNAL_ASSET_BROKEN: {
    severity: "critical",
    risk: "medium",
    auto: false,
    fa: {
      title: "فایل/آدرس داخلی یافت نشد: {value}",
      why: "تصویر یا مسیر داخلی ۴۰۴ می‌شود؛ هم تجربه کاربر خراب می‌شود هم خزنده انرژی خود را هدر می‌دهد.",
      fix: "فایل را در پوشه public اضافه یا آدرس را در کد اصلاح کنید.",
    },
    en: {
      title: "Internal file/URL not found: {value}",
      why: "An image or internal path returns 404 — bad for users and wasted crawl budget.",
      fix: "Add the file to the public folder or fix the path in the code.",
    },
  },
  UNKNOWN_ROUTE_LINK: {
    severity: "warning",
    risk: "medium",
    auto: false,
    fa: {
      title: "لینک به مسیر ناشناخته: {value}",
      why: "این لینک هش به صفحه‌ای اشاره می‌کند که وجود ندارد (مثلاً مقاله حذف‌شده) و برای کاربر ۴۰۴ نشان می‌دهد.",
      fix: "لینک را اصلاح کنید یا مقاله را در پنل مدیریت بازگردانید.",
    },
    en: {
      title: "Link to unknown route: {value}",
      why: "This hash link points to a page that does not exist (e.g. a deleted post) and shows users a 404-like view.",
      fix: "Fix the link or restore the post in the admin panel.",
    },
  },
  AI_SUGGESTION: {
    severity: "opportunity",
    risk: "medium",
    auto: false,
    fa: {
      title: "پیشنهاد هوش مصنوعی",
      why: "این پیشنهاد از تحلیل هوش مصنوعی روی محتوای واقعی سایت ساخته شده است.",
      fix: "پس از بررسی، به‌صورت دستی اعمال کنید؛ اعمال خودکار برای این مورد فعال نیست.",
    },
    en: {
      title: "AI suggestion",
      why: "This recommendation was generated by AI analysis of the real site content.",
      fix: "Review and apply manually; automatic application is disabled for this item.",
    },
  },
};

/** Interpolate {placeholders} in a registry text. */
export function fill(text: string, vars: Record<string, string | number> = {}): string {
  return text.replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? ""));
}

export function issueText(code: string, lang: TextLang, vars?: Record<string, string | number>): IssueText {
  const def = REGISTRY[code] ?? REGISTRY.AI_SUGGESTION;
  const t = lang === "en" ? def.en : def.fa;
  return {
    title: fill(t.title, vars),
    why: fill(t.why, vars),
    fix: fill(t.fix, vars),
  };
}

export function issueRisk(code: string): Risk {
  return (REGISTRY[code] ?? REGISTRY.AI_SUGGESTION).risk;
}

export function issueAuto(code: string): boolean {
  return (REGISTRY[code] ?? REGISTRY.AI_SUGGESTION).auto;
}

export function issueSeverity(code: string, fallback: Sev = "warning"): Sev {
  return REGISTRY[code]?.severity ?? fallback;
}
