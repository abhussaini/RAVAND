/* ------------------------------------------------------------------
   Ravand SEO Assistant — on-page HTML extraction.

   Dependency-free parsing tuned for this site's own HTML (the Next
   server shell) plus generic pages. Everything extracted is treated
   as UNTRUSTED input downstream (AI prompts, storage).
   ------------------------------------------------------------------ */

export interface HeadingInfo {
  tag: string; // "h1" | "h2" …
  text: string;
}

export interface LinkInfo {
  href: string;
  kind: "hash" | "internal" | "external";
}

export interface ImageInfo {
  src: string;
  alt: string;
}

export interface PageExtract {
  title: string;
  description: string;
  metaRobots: string;
  canonical: string;
  lang: string;
  viewport: boolean;
  og: boolean;
  twitter: boolean;
  headings: HeadingInfo[];
  h1Count: number;
  images: ImageInfo[];
  links: LinkInfo[];
  jsonLdTypes: string[];
  jsonLdValid: boolean;
  jsonLdError: string;
  wordCount: number;
  text: string; // first ~4000 chars, tags stripped
}

const stripTags = (html: string) =>
  html
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();

const attr = (tag: string, name: string): string => {
  const m =
    tag.match(new RegExp(`${name}\\s*=\\s*"([^"]*)"`, "i")) ??
    tag.match(new RegExp(`${name}\\s*=\\s*'([^']*)'`, "i"));
  if (!m) return "";
  /* unescape the HTML entities that appear inside attribute values */
  return m[1]
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;/g, "'")
    .trim();
};

function metaContent(html: string, key: string, by: "name" | "property"): string {
  const re =
    by === "name"
      ? new RegExp(`<meta[^>]+name\\s*=\\s*["']${key}["'][^>]*>`, "gi")
      : new RegExp(`<meta[^>]+property\\s*=\\s*["']${key}["'][^>]*>`, "gi");
  const m = re.exec(html);
  if (!m) return "";
  return attr(m[0], "content").trim();
}

function sameHost(url: string, base: string): boolean {
  try {
    return new URL(url, base).hostname.toLowerCase() === new URL(base).hostname.toLowerCase();
  } catch {
    return false;
  }
}

export function extractPage(html: string, baseUrl: string): PageExtract {
  const title = stripTags(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? "").slice(0, 300);
  const description = metaContent(html, "description", "name").slice(0, 400);
  const metaRobots = metaContent(html, "robots", "name").toLowerCase().slice(0, 120);
  const canonicalRaw = /<link[^>]+rel\s*=\s*["']canonical["'][^>]*>/i.exec(html)?.[0] ?? "";
  const canonical = attr(canonicalRaw, "href").trim();
  const htmlTag = /<html[^>]*>/i.exec(html)?.[0] ?? "";
  const lang = attr(htmlTag, "lang").toLowerCase();
  const viewport = /<meta[^>]+name\s*=\s*["']viewport["']/i.test(html);
  const og = /<meta[^>]+property\s*=\s*["']og:/i.test(html);
  const twitter = /<meta[^>]+(?:name|property)\s*=\s*["']twitter:/i.test(html);

  /* headings */
  const headings: HeadingInfo[] = [];
  const hRe = /<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi;
  let hm: RegExpExecArray | null;
  while ((hm = hRe.exec(html)) && headings.length < 80) {
    const text = stripTags(hm[2]).slice(0, 200);
    if (text) headings.push({ tag: `h${hm[1]}`, text });
  }
  const h1Count = headings.filter((h) => h.tag === "h1").length;

  /* images */
  const images: ImageInfo[] = [];
  const imgRe = /<img\b[^>]*>/gi;
  let im: RegExpExecArray | null;
  while ((im = imgRe.exec(html)) && images.length < 200) {
    const src = attr(im[0], "src") || attr(im[0], "srcset").split(" ")[0] || "";
    if (src) images.push({ src: src.slice(0, 400), alt: attr(im[0], "alt").slice(0, 300) });
  }

  /* links */
  const links: LinkInfo[] = [];
  const aRe = /<a\b[^>]*href\s*=\s*["']([^"'#]*#?[^"']*)["'][^>]*>/gi;
  let am: RegExpExecArray | null;
  const seen = new Set<string>();
  while ((am = aRe.exec(html)) && links.length < 300) {
    const href = am[1].trim();
    if (!href || href === "#" || seen.has(href)) continue;
    seen.add(href);
    if (href.startsWith("#")) links.push({ href, kind: "hash" });
    else if (/^https?:\/\//i.test(href))
      links.push({ href: href.slice(0, 500), kind: sameHost(href, baseUrl) ? "internal" : "external" });
    else links.push({ href, kind: "internal" }); // relative path (assets, /robots.txt …)
  }

  /* JSON-LD */
  const jsonLdTypes: string[] = [];
  let jsonLdValid = true;
  let jsonLdError = "";
  const ldRe = /<script[^>]+type\s*=\s*["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let lm: RegExpExecArray | null;
  let ldFound = false;
  while ((lm = ldRe.exec(html))) {
    ldFound = true;
    try {
      const parsed = JSON.parse(lm[1].trim()) as unknown;
      const collect = (node: unknown): void => {
        if (Array.isArray(node)) return node.forEach(collect);
        if (node && typeof node === "object") {
          const t = (node as { "@type"?: unknown })["@type"];
          if (typeof t === "string") jsonLdTypes.push(t);
          else if (Array.isArray(t)) t.forEach((x) => typeof x === "string" && jsonLdTypes.push(x));
          const g = (node as { "@graph"?: unknown })["@graph"];
          if (g) collect(g);
        }
      };
      collect(parsed);
    } catch (e) {
      jsonLdValid = false;
      jsonLdError = e instanceof Error ? e.message.slice(0, 120) : "invalid JSON-LD";
    }
  }
  if (!ldFound) jsonLdValid = jsonLdTypes.length > 0 ? jsonLdValid : jsonLdValid;

  /* visible text */
  const bodyHtml = /<body[^>]*>([\s\S]*?)<\/body>/i.exec(html)?.[1] ?? html;
  const text = stripTags(bodyHtml.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ")).slice(0, 4000);
  const wordCount = text ? text.split(/\s+/).length : 0;

  return {
    title,
    description,
    metaRobots,
    canonical,
    lang,
    viewport,
    og,
    twitter,
    headings,
    h1Count,
    images,
    links,
    jsonLdTypes,
    jsonLdValid,
    jsonLdError,
    wordCount,
    text,
  };
}

/** Parse robots.txt into a light validation result. */
export function parseRobots(body: string): {
  ok: boolean;
  hasSitemap: boolean;
  blocksApi: boolean;
  agentCount: number;
} {
  const lines = body.split(/\r?\n/).map((l) => l.trim());
  let agentCount = 0;
  let hasSitemap = false;
  let blocksApi = false;
  for (const line of lines) {
    if (/^user-agent\s*:/i.test(line)) agentCount++;
    if (/^sitemap\s*:/i.test(line)) hasSitemap = true;
    const dis = /^disallow\s*:\s*(.*)$/i.exec(line);
    if (dis && dis[1].trim() === "/api/") blocksApi = true;
  }
  return { ok: agentCount > 0, hasSitemap, blocksApi, agentCount };
}

/** Extract <loc> URLs from a sitemap XML document. */
export function parseSitemap(body: string): string[] {
  const locs: string[] = [];
  const re = /<loc>\s*([^<]+?)\s*<\/loc>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(body)) && locs.length < 100) locs.push(m[1]);
  return locs;
}
