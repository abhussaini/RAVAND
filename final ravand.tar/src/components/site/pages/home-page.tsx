"use client";

import { HeroSection } from "../hero-section";
import { TrustSection } from "../trust-section";
import { ServicesSection } from "../services-section";
import { PortfolioSection } from "../portfolio-section";
import { StatsBanner } from "../stats-banner";
import { BlogSection } from "../blog-section";
import { TestimonialsSection } from "../testimonials-section";
import { SiteFooter } from "../site-footer";

/** Home = the editorial one-pager (hero → why → services → work → stats → blog → testimonials → footer). */
export function HomePage() {
  return (
    <>
      <main className="flex-1">
        <HeroSection />
        <TrustSection />
        <ServicesSection />
        <PortfolioSection />
        <StatsBanner />
        <BlogSection />
        <TestimonialsSection />
      </main>
      <SiteFooter />
    </>
  );
}
