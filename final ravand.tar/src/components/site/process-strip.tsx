"use client";

import { useT } from "@/lib/i18n";
import { Reveal } from "./reveal";
import { Eyebrow } from "./ui-v2";

const STEPS = [
  { t: "process.s1_t", d: "process.s1_d" },
  { t: "process.s2_t", d: "process.s2_d" },
  { t: "process.s3_t", d: "process.s3_d" },
  { t: "process.s4_t", d: "process.s4_d" },
] as const;

/**
 * Numbered process timeline — transparent, professional, RTL-safe.
 */
export function ProcessStrip() {
  const { t } = useT();

  return (
    <section className="bg-white px-6 py-20 sm:px-10 sm:py-24">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div className="max-w-xl">
          <Eyebrow>{t("process.eyebrow")}</Eyebrow>
          <h2 className="font-display t-section mt-4 font-medium">{t("process.title")}</h2>
        </div>
        <Reveal from={{ opacity: 0, y: 14 }} delayIn={0.15}>
          <p className="max-w-sm text-sm leading-relaxed text-ink-soft md:pb-1 md:text-end">
            {t("process.desc")}
          </p>
        </Reveal>
      </div>

      <ol className="mt-12 grid gap-4 sm:gap-5 md:grid-cols-2 lg:grid-cols-4">
        {STEPS.map((s, i) => (
          <li key={s.t}>
            <Reveal
              from={{ opacity: 0, y: 30 }}
              delayIn={i * 0.1}

              className="h-full"
            >
              <article
                className="relative flex h-full flex-col rounded-card border border-hairline bg-surface p-6 transition-[color,border-color,transform] duration-300 hover:border-brand/35 hover:-translate-y-1.5"
              >
                <span
                  dir="ltr"
                  aria-hidden
                  className="font-display text-4xl font-medium text-ghost transition-colors duration-300 group-hover:text-brand/50"
                >
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="font-display mt-4 text-lg font-medium leading-snug">{t(s.t)}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-soft">{t(s.d)}</p>
                {i < STEPS.length - 1 && (
                  <span
                    aria-hidden
                    className="absolute -end-3 top-1/2 hidden h-px w-5 bg-hairline lg:block"
                  />
                )}
              </article>
            </Reveal>
          </li>
        ))}
      </ol>
    </section>
  );
}
