"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

export type Lang = "fa" | "ps" | "en";

export const langMeta: Record<Lang, { label: string; english: string; dir: "rtl" | "ltr" }> = {
  fa: { label: "فارسی", english: "Dari", dir: "rtl" },
  ps: { label: "پښتو", english: "Pashto", dir: "rtl" },
  en: { label: "English", english: "English", dir: "ltr" },
};

interface LangState {
  lang: Lang;
  setLang: (lang: Lang) => void;
}

export const useLang = create<LangState>()(
  persist(
    (set) => ({
      /* English is the FIRST display language on every visit; Dari &
         Pashto are one tap away. The choice persists for the whole
         browsing session (reloads, page changes) — sessionStorage, so
         a NEW visit always opens in English again. */
      lang: "en",
      setLang: (lang) => set({ lang }),
    }),
    {
      name: "ravand-lang",
      storage: createJSONStorage(() => sessionStorage),
      // Rehydrated manually in <LangSync /> after mount to avoid SSR mismatch
      skipHydration: true,
    }
  )
);
