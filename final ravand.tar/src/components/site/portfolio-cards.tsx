'use client';

import * as React from 'react';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Reveal } from '@/components/site/reveal';

/* ------------------------------------------------------------------
   Portfolio card grid — "work we're proud of".
   Cards-only, 3-column mini layout (the former Hero08 "mini"
   variant, reduced to the parts actually used by the site).
   ------------------------------------------------------------------ */

export interface CardCta {
  ctaEnabled?: boolean;
  text: string;
  link?: string;
  size?: 'default' | 'sm' | 'lg';
  onClick?: () => void;
}

export interface PortfolioCard {
  title: string;
  subtitle: string;
  image: string;
  imageAlt?: string;
  invert?: boolean;
  cta: CardCta;
}

/** Small call-to-action rendered inside a card. `invert` renders a
 *  glassy white button for cards sitting on colorful artwork. */
function CardCtaButton({ cta, invert }: { cta: CardCta; invert?: boolean }) {
  if (!cta?.ctaEnabled) return null;

  const classes = cn(
    'group/cta gap-2 rounded-pill px-5 font-medium',
    invert
      ? 'border-white/40 bg-white/15 text-white backdrop-blur-sm hover:bg-white hover:text-brand-deep'
      : 'border-brand/30 text-brand hover:bg-brand hover:text-white'
  );

  const inner = (
    <>
      {cta.text}
      <ArrowRight
        className="size-4 transition-transform duration-300 group-hover/cta:translate-x-1 rtl:-scale-x-100 rtl:group-hover/cta:-translate-x-1"
        aria-hidden
      />
    </>
  );

  if (cta.link) {
    return (
      <Button asChild size={cta.size ?? 'default'} className={classes}>
        <a href={cta.link}>{inner}</a>
      </Button>
    );
  }

  return (
    <Button size={cta.size ?? 'default'} className={classes} onClick={cta.onClick}>
      {inner}
    </Button>
  );
}

function FeatureCard({ card }: Readonly<{ card: PortfolioCard }>) {
  const titleClass = card.invert ? 'text-white' : 'text-foreground';
  const subtitleClass = card.invert ? 'text-white/80' : 'text-muted-foreground';

  return (
    <div
      className={cn(
        'relative isolate aspect-4/3 w-full overflow-hidden rounded-card outline outline-black/10 sm:aspect-16/10',
      )}
    >
      {card.image && (
        <img
          src={card.image}
          alt={card.imageAlt ?? ''}
          decoding="async"
          className="absolute inset-0 -z-10 size-full object-cover"
        />
      )}

      {card.invert && (
        <div
          aria-hidden
          className="absolute inset-0 -z-10 bg-linear-to-br from-black/40 via-black/15 to-transparent"
        />
      )}

      <div className={cn('flex h-full flex-col items-start p-4 sm:p-5')}>
        <h3
          className={cn(
            'font-semibold tracking-tight text-balance text-lg sm:text-xl',
            titleClass
          )}
        >
          {card.title}
        </h3>
        <p className={cn('mt-1 text-sm', subtitleClass)}>{card.subtitle}</p>
        {card.cta?.ctaEnabled && (
          <div className="mt-4">
            <CardCtaButton cta={card.cta} invert={card.invert} />
          </div>
        )}
      </div>
    </div>
  );
}

export function PortfolioCards({
  cards,
  animation = 'none',
}: Readonly<{ cards: PortfolioCard[]; animation?: 'none' | 'subtle' }>) {
  const [reduce, setReduce] = React.useState(false);
  React.useEffect(() => {
    setReduce(window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }, []);
  const animate = animation === 'subtle' && !reduce;

  if (!cards?.length) return null;

  return (
    <section className="bg-background relative isolate w-full overflow-hidden">
      <div className="relative z-10 mx-auto w-full max-w-6xl px-6 py-12 sm:py-16">
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 sm:gap-4 lg:grid-cols-3">
          {cards.map((card, i) => (
            <Reveal
              key={card.title}
              from={{ opacity: 0, y: 24 }}
              delayIn={animate ? 0.06 * i : 0}
              className="h-full"
            >
              <FeatureCard card={card} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
