"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";

/**
 * Site content — fetched once from /api/content (the database the
 * admin panel manages) and shared with every section. While the
 * request is loading (or if it fails) sections fall back to the
 * built-in trilingual dictionary, so the site always renders.
 */

export type L10n = { fa: string; ps: string; en: string };

export interface ContentService {
  id: string;
  slug: string;
  title: L10n;
  desc: L10n;
  sticker: string;
}
export interface ContentProject {
  id: string;
  slug: string;
  title: L10n;
  cat: L10n;
  desc: L10n;
  sticker: string;
}
export interface ContentPost {
  id: string;
  slug: string;
  title: L10n;
  cat: L10n;
  excerpt: L10n;
  body: L10n;
  sticker: string;
  readMin: number;
  dateLabel: L10n;
  createdAt: string;
}
export interface ContentTestimonial {
  id: string;
  name: string;
  role: L10n;
  quote: L10n;
}
export interface ContentStat {
  id: string;
  value: number;
  suffix: string;
  label: L10n;
  sub: L10n;
}
export interface ContentSettings {
  logoUrl: string;
  email: string;
  phone1: string;
  phone2: string;
  whatsapp: string;
  instagram: string;
  tagline: L10n;
  address: L10n;
  hours: L10n;
}

export interface SiteContent {
  services: ContentService[];
  projects: ContentProject[];
  posts: ContentPost[];
  testimonials: ContentTestimonial[];
  stats: ContentStat[];
  settings: ContentSettings | null;
}

interface ContentCtx {
  content: SiteContent | null;
  loading: boolean;
  /** pick active-language string from an L10n object */
  pick: (l: L10n | undefined | null) => string;
}

const Ctx = createContext<ContentCtx>({
  content: null,
  loading: true,
  pick: () => "",
});

async function fetchContent(): Promise<SiteContent> {
  const res = await fetch("/api/content", { cache: "no-store" });
  if (!res.ok) throw new Error("content fetch failed");
  const json = await res.json();
  if (!json?.ok) throw new Error("content unavailable");
  return json as SiteContent;
}

function pickL10nClient(l: L10n | undefined | null, lang: "fa" | "ps" | "en"): string {
  if (!l) return "";
  const order: Array<keyof L10n> = lang === "en" ? ["en", "fa", "ps"] : lang === "ps" ? ["ps", "fa", "en"] : ["fa", "ps", "en"];
  for (const k of order) if (l[k]?.trim()) return l[k];
  return "";
}

export function ContentProvider({
  lang,
  children,
}: {
  lang: "fa" | "ps" | "en";
  children: ReactNode;
}) {
  /* plain one-shot fetch — keeps react-query out of the public first-load
     bundle (it stays inside the admin/SEO dashboard chunks) */
  const [content, setContent] = useState<SiteContent | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    fetchContent()
      .then((c) => {
        if (!alive) return;
        setContent(c);
        setLoading(false);
      })
      .catch(() => {
        if (!alive) return;
        setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  const pick = (l: L10n | undefined | null) => pickL10nClient(l, lang);

  return (
    <Ctx.Provider value={{ content, loading, pick }}>
      {children}
    </Ctx.Provider>
  );
}

export function useContent() {
  return useContext(Ctx);
}
