import { NextResponse } from "next/server";
import { z } from "zod";
import { db, ensureDb } from "@/lib/db";
import { deny, guard, jsonError } from "@/lib/seo/guard";

export const dynamic = "force-dynamic";

const PatchSchema = z.object({
  keyword: z.string().trim().min(2).max(60).optional(),
  pageUrl: z.string().trim().max(200).optional(),
  lang: z.enum(["fa", "ps", "en"]).optional(),
  notes: z.string().trim().max(500).optional(),
});

/* PATCH /api/seo/keywords/[id] */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await guard(req))) return deny();
  const { id } = await params;
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("VALIDATION");
  }
  const parsed = PatchSchema.safeParse(body);
  if (!parsed.success) return jsonError("VALIDATION");

  try {
    await ensureDb();
    const updated = await db.seoKeyword.update({ where: { id }, data: parsed.data });
    return NextResponse.json({ ok: true, keyword: updated });
  } catch (error) {
    if (String(error).includes("Unique")) return jsonError("DUPLICATE", 409);
    console.error("[seo/keywords] patch failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}

/* DELETE /api/seo/keywords/[id] */
export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await guard(req))) return deny();
  const { id } = await params;
  try {
    await ensureDb();
    await db.seoKeyword.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("[seo/keywords] delete failed:", error);
    return jsonError("SERVER_ERROR", 500);
  }
}
