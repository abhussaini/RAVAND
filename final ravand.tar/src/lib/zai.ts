/* ------------------------------------------------------------------
   z.ai SDK — shared server-side singleton with a portable fallback.

   Imported ONLY from backend code (API routes). The module caches a
   single AI client for the whole process so every AI feature
   (customer chat, SEO assistant) shares one connection.

   Provider order:
     1. z.ai SDK (z-ai-web-dev-sdk) — bundled sandbox provider.
     2. Any OpenAI-compatible endpoint via AI_API_KEY + AI_BASE_URL
        (+ optional AI_MODEL) — works on Netlify/VPS production.
     3. Neither available → askZai() returns null and the caller
        falls back to its deterministic rule-based path — visitors
        never see a raw provider error.
   ------------------------------------------------------------------ */

type ZaiClient = {
  chat: {
    completions: {
      create: (a: {
        messages: { role: string; content: string }[];
        thinking?: { type: string };
        temperature?: number;
        max_tokens?: number;
      }) => Promise<{
        choices?: { message?: { content?: string }[] }[];
      }>;
    };
  };
};

let cached: ZaiClient | null = null;
let createPromise: Promise<ZaiClient | null> | null = null;
let zaiImportFailed = false;

/** Get (and memoize) the shared z.ai client — null when unavailable. */
async function getZai(): Promise<ZaiClient | null> {
  if (cached) return cached;
  if (zaiImportFailed) return null;
  if (!createPromise) {
    createPromise = (async () => {
      try {
        const mod = (await import("z-ai-web-dev-sdk")) as {
          default?: unknown;
          ZAI?: unknown;
        };
        const ZAI = (mod.ZAI ?? mod.default ?? mod) as {
          create: () => Promise<unknown>;
        };
        const client = (await ZAI.create()) as ZaiClient;
        cached = client;
        return client;
      } catch (error) {
        zaiImportFailed = true;
        console.error("[zai] init failed:", error);
        return null;
      }
    })();
  }
  return createPromise;
}

/** Portable OpenAI-compatible completion (Netlify / VPS production). */
async function openAiComplete(opts: {
  system: string;
  turns: { role: "user" | "assistant"; content: string }[];
  temperature?: number;
  maxTokens?: number;
  timeoutMs?: number;
}): Promise<string | null> {
  const key = process.env.AI_API_KEY;
  const base = (process.env.AI_BASE_URL || "").replace(/\/+$/, "");
  if (!key || !base) return null;

  try {
    const res = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: opts.system },
          ...opts.turns.map((t) => ({ role: t.role, content: t.content })),
        ],
        temperature: opts.temperature ?? 0.4,
        max_tokens: opts.maxTokens ?? 600,
      }),
      signal: AbortSignal.timeout(opts.timeoutMs ?? 25_000),
    });
    if (!res.ok) {
      console.error("[zai] openai-compatible failed:", res.status);
      return null;
    }
    const json = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    return json?.choices?.[0]?.message?.content?.trim() || null;
  } catch (error) {
    console.error("[zai] openai-compatible completion failed:", error);
    return null;
  }
}

/** Is an AI provider expected to be available? (honest status) */
export function zaiConfigured(): boolean {
  if (process.env.AI_API_KEY && process.env.AI_BASE_URL) return true;
  return !zaiImportFailed;
}

export interface ZaiTurn {
  role: "user" | "assistant";
  content: string;
}

/** One-shot completion — null on any failure (caller must fall back). */
export async function askZai(opts: {
  system: string;
  turns: ZaiTurn[];
  temperature?: number;
  maxTokens?: number;
  timeoutMs?: number;
}): Promise<string | null> {
  const client = await getZai();

  if (client) {
    const messages = [
      { role: "system", content: opts.system },
      ...opts.turns.map((t) => ({ role: t.role, content: t.content })),
    ];

    const run = client.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
      temperature: opts.temperature ?? 0.4,
      max_tokens: opts.maxTokens ?? 600,
    });

    /* hard timeout so a slow provider never blocks the HTTP response —
       the underlying request is left to settle on its own */
    let timer: ReturnType<typeof setTimeout> | undefined;
    const timeout = new Promise<never>((_, reject) => {
      timer = setTimeout(
        () => reject(new Error("ZAI_TIMEOUT")),
        opts.timeoutMs ?? 25_000
      );
    });

    let completion: { choices?: { message?: { content?: string } }[] };
    try {
      completion = await Promise.race([run, timeout]);
    } catch (error) {
      console.error("[zai] completion failed:", error);
      completion = {};
    } finally {
      clearTimeout(timer);
    }

    const text = completion?.choices?.[0]?.message?.content?.trim();
    if (text) return text;
    /* z.ai returned nothing — try the portable provider before giving up */
  }

  /* portable fallback — works on Netlify when the owner sets
     AI_API_KEY + AI_BASE_URL (+ optional AI_MODEL) */
  return openAiComplete({
    system: opts.system,
    turns: opts.turns,
    temperature: opts.temperature,
    maxTokens: opts.maxTokens,
    timeoutMs: opts.timeoutMs,
  });
}
