import { NextResponse } from "next/server";
import { db, ensureDb } from "@/lib/db";
import { isAdmin } from "@/lib/admin-auth";
import { sameOrigin } from "@/lib/http";
import { ensureSupabaseSync, mirrorUpsert } from "@/lib/store";
import { settingsSchema } from "@/lib/admin-resources";

export const dynamic = "force-dynamic";

const deny = () => NextResponse.json({ ok: false, error: "UNAUTHORIZED" }, { status: 401 });

/** GET /api/admin/settings — singleton row (admin only). */
export async function GET() {
  if (!(await isAdmin())) return deny();
  try {
    await ensureDb();
    ensureSupabaseSync();
    let row = await db.setting.findUnique({ where: { id: "main" } });
    if (!row) {
      row = await db.setting.create({ data: { id: "main" } });
    }
    return NextResponse.json({ ok: true, item: row });
  } catch (error) {
    console.error("[admin/settings] get failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}

/** PUT /api/admin/settings — update singleton (admin only). */
export async function PUT(req: Request) {
  if (!(await isAdmin()) || !sameOrigin(req)) return deny();
  try {
    await ensureDb();
    const body = await req.json();
    const parsed = settingsSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: "VALIDATION", issues: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }
    const item = await db.setting.upsert({
      where: { id: "main" },
      update: parsed.data,
      create: { id: "main", ...parsed.data },
    });
    /* keep the Supabase copy aligned (best-effort) */
    mirrorUpsert("Setting", item as unknown as Record<string, unknown>);
    return NextResponse.json({ ok: true, item });
  } catch (error) {
    console.error("[admin/settings] put failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}
