import crypto from "crypto";
import { cookies } from "next/headers";

/**
 * Lightweight admin auth — a signed token derived from the admin
 * password is stored in an httpOnly cookie. Password comes from
 * env (ADMIN_PASSWORD) with a sandbox default.
 */
export const ADMIN_COOKIE = "rv_admin";

function password(): string {
  return process.env.ADMIN_PASSWORD || "ravand2024";
}

function makeToken(): string {
  return crypto
    .createHash("sha256")
    .update(`${password()}::ravand-tech-admin-v1`)
    .digest("hex");
}

/** Constant-time comparison — prevents timing side-channel. */
export function checkPassword(input: string): boolean {
  const a = Buffer.from(crypto.createHash("sha256").update(input).digest("hex"));
  const b = Buffer.from(crypto.createHash("sha256").update(password()).digest("hex"));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  const value = store.get(ADMIN_COOKIE)?.value ?? "";
  const expected = Buffer.from(makeToken());
  const received = Buffer.from(value);
  return (
    received.length === expected.length && crypto.timingSafeEqual(received, expected)
  );
}

export const ADMIN_TOKEN = makeToken();
