import { timingSafeEqual } from "crypto";
import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin-auth";
import { sameOrigin } from "@/lib/http";

/* ------------------------------------------------------------------
   Ravand SEO Assistant — API guard helpers.
   Every /api/seo route is admin-only (same signed cookie as the site
   admin panel) except the scheduler entry, which additionally accepts
   a timing-safe CRON_SECRET header so Netlify Scheduled Functions or
   n8n can trigger it without a login session.
   ------------------------------------------------------------------ */

export const deny = () =>
  NextResponse.json({ ok: false, error: "UNAUTHORIZED" }, { status: 401 });

export async function guard(req: Request, opts: { allowCron?: boolean } = {}): Promise<boolean> {
  /* state-changing requests must originate from this site */
  if (req.method !== "GET" && !sameOrigin(req)) return false;
  if (await isAdmin()) return true;
  if (opts.allowCron) {
    const secret = process.env.CRON_SECRET;
    const provided = req.headers.get("x-cron-secret") ?? "";
    if (secret && provided) {
      const a = Buffer.from(provided);
      const b = Buffer.from(secret);
      if (a.length === b.length && timingSafeEqual(a, b)) return true;
    }
  }
  return false;
}

export function jsonError(error: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ ok: false, error, ...extra }, { status });
}
