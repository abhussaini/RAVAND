"use client";

import type { ReactNode } from "react";
import { Reveal } from "./reveal";
import { cn } from "@/lib/utils";

/** Section heading — eyebrow pill + title + description, centered or start-aligned */
export function SectionHeading({
  eyebrow,
  title,
  desc,
  align = "center",
  dark = false,
}: {
  eyebrow: string;
  title: string;
  desc?: string;
  align?: "center" | "start";
  dark?: boolean;
}) {
  return (
    <Reveal
      className={cn(
        "flex flex-col gap-3",
        align === "center" ? "items-center text-center" : "items-start text-start"
      )}
    >
      <span
        className={cn(
          "inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-xs font-bold tracking-wide",
          dark
            ? "border-white/15 bg-white/10 text-white/90"
            : "border-primary/20 bg-secondary text-primary"
        )}
      >
        <span
          className={cn(
            "size-1.5 rounded-full",
            dark ? "bg-teal-300" : "bg-primary"
          )}
          aria-hidden
        />
        {eyebrow}
      </span>
      <h2
        className={cn(
          "text-balance text-2xl font-black leading-snug tracking-tight sm:text-3xl lg:text-4xl",
          dark ? "text-white" : "text-foreground"
        )}
      >
        {title}
      </h2>
      {desc ? (
        <p
          className={cn(
            "max-w-2xl text-pretty text-sm leading-7 sm:text-base sm:leading-8",
            dark ? "text-white/70" : "text-muted-foreground"
          )}
        >
          {desc}
        </p>
      ) : null}
    </Reveal>
  );
}
