import { NextResponse } from "next/server";
import { db, ensureDb } from "@/lib/db";
import { ensureSupabaseSync } from "@/lib/store";

export const dynamic = "force-dynamic";

/* ---------- L10n helpers — stored as JSON string, sent as object ---------- */
export type L10n = { fa: string; ps: string; en: string };

export function parseL10n(raw: string | null | undefined): L10n {
  const empty = { fa: "", ps: "", en: "" };
  if (!raw) return empty;
  try {
    const o = JSON.parse(raw);
    if (o && typeof o === "object") return { ...empty, ...o };
    return { fa: String(o), ps: String(o), en: String(o) };
  } catch {
    return { fa: raw, ps: raw, en: raw };
  }
}

const pick = (l: L10n, lang: "fa" | "ps" | "en") => l[lang] || l.fa || l.en || l.ps || "";

/**
 * GET /api/content — all public site content in one payload.
 * Every L10n field is returned as {fa, ps, en} so the client picks
 * the active language (fa default, falls back through the chain).
 */
export async function GET() {
  try {
    await ensureDb();
    /* lazy Supabase mirror — runs at most once per process, retried
       with a cooldown until the remote tables exist */
    ensureSupabaseSync();
    const [services, projects, posts, testimonials, stats, settings] =
      await Promise.all([
        db.service.findMany({ where: { active: true }, orderBy: { order: "asc" } }),
        db.project.findMany({ where: { active: true }, orderBy: { order: "asc" } }),
        db.post.findMany({
          where: { published: true },
          orderBy: { createdAt: "desc" },
          take: 24,
        }),
        db.testimonial.findMany({ where: { active: true }, orderBy: { order: "asc" } }),
        db.stat.findMany({ where: { active: true }, orderBy: { order: "asc" } }),
        db.setting.findUnique({ where: { id: "main" } }),
      ]);

    return NextResponse.json({
      ok: true,
      services: services.map((s) => ({
        id: s.id,
        slug: s.slug,
        title: parseL10n(s.title),
        desc: parseL10n(s.desc),
        sticker: s.sticker,
      })),
      projects: projects.map((p) => ({
        id: p.id,
        slug: p.slug,
        title: parseL10n(p.title),
        cat: parseL10n(p.cat),
        desc: parseL10n(p.desc),
        sticker: p.sticker,
      })),
      posts: posts.map((p) => ({
        id: p.id,
        slug: p.slug,
        title: parseL10n(p.title),
        cat: parseL10n(p.cat),
        excerpt: parseL10n(p.excerpt),
        body: parseL10n(p.body),
        sticker: p.sticker,
        readMin: p.readMin,
        dateLabel: parseL10n(p.dateLabel),
        createdAt: p.createdAt,
      })),
      testimonials: testimonials.map((t) => ({
        id: t.id,
        name: t.name,
        role: parseL10n(t.role),
        quote: parseL10n(t.quote),
      })),
      stats: stats.map((s) => ({
        id: s.id,
        value: s.value,
        suffix: s.suffix,
        label: parseL10n(s.label),
        sub: parseL10n(s.sub),
      })),
      settings: settings
        ? {
            logoUrl: settings.logoUrl,
            email: settings.email,
            phone1: settings.phone1,
            phone2: settings.phone2,
            whatsapp: settings.whatsapp,
            instagram: settings.instagram,
            tagline: parseL10n(settings.tagline),
            address: parseL10n(settings.address),
            hours: parseL10n(settings.hours),
          }
        : null,
    });
  } catch (error) {
    console.error("[/api/content] failed:", error);
    return NextResponse.json({ ok: false, error: "SERVER_ERROR" }, { status: 500 });
  }
}

export { pick as pickL10n };
